import sys
import os
import subprocess
import webbrowser
import urllib.request
import time
import threading
import tkinter as tk
from tkinter import ttk, messagebox

APP_DIR = os.path.dirname(os.path.abspath(__file__))
SERVER_SCRIPT = os.path.join(APP_DIR, "server", "serve.js")
URL = "http://localhost:3000"

def is_server_running():
    try:
        req = urllib.request.Request(URL, headers={'User-Agent': 'LauncherCheck'})
        with urllib.request.urlopen(req, timeout=1.5) as response:
            return response.status == 200
    except Exception:
        return False

def start_server():
    if is_server_running():
        return True
    try:
        # CREATE_NO_WINDOW flag on Windows
        creationflags = 0x08000000 if os.name == 'nt' else 0
        subprocess.Popen(
            ["node", SERVER_SCRIPT],
            cwd=APP_DIR,
            creationflags=creationflags,
            stdout=subprocess.DEVNULL,
            stderr=subprocess.DEVNULL
        )
        for _ in range(10):
            time.sleep(0.5)
            if is_server_running():
                return True
        return False
    except Exception as e:
        print(f"Error starting server: {e}")
        return False

class WebLauncherApp:
    def __init__(self, root):
        self.root = root
        self.root.title("Đại Số Tuyến Tính & Đại Cương - Web Launcher")
        self.root.geometry("480x360")
        self.root.resizable(False, False)
        self.root.configure(bg="#0f172a")

        # Center on screen
        self.center_window()

        # Header Frame
        header = tk.Frame(root, bg="#0f172a")
        header.pack(fill="x", pady=(24, 8), padx=20)

        badge = tk.Label(
            header,
            text="⚡ TRI THỨC TOÁN HỌC & WEB FONTS",
            font=("Segoe UI", 9, "bold"),
            fg="#38bdf8",
            bg="#1e293b",
            padx=10,
            pady=4
        )
        badge.pack()

        title = tk.Label(
            header,
            text="Chuyên Khảo Đại Số\nĐại Cương & Tuyến Tính",
            font=("Segoe UI", 16, "bold"),
            fg="#f8fafc",
            bg="#0f172a",
            justify="center"
        )
        title.pack(pady=(10, 4))

        subtitle = tk.Label(
            header,
            text="Nền tảng tra cứu 33 trang lý thuyết, nghiệm & bẫy đại số",
            font=("Segoe UI", 9),
            fg="#94a3b8",
            bg="#0f172a"
        )
        subtitle.pack()

        # Status Badge
        self.status_var = tk.StringVar(value="⏳ Đang kiểm tra máy chủ...")
        self.status_label = tk.Label(
            root,
            textvariable=self.status_var,
            font=("Segoe UI", 9, "bold"),
            fg="#e2e8f0",
            bg="#334155",
            padx=12,
            pady=5
        )
        self.status_label.pack(pady=(12, 16))

        # Main 1-Button Frame
        btn_frame = tk.Frame(root, bg="#0f172a")
        btn_frame.pack(pady=4)

        self.launch_btn = tk.Button(
            btn_frame,
            text="🚀  MỞ TRANG WEB NGAY",
            font=("Segoe UI", 13, "bold"),
            fg="#ffffff",
            bg="#4f46e5",
            activebackground="#4338ca",
            activeforeground="#ffffff",
            relief="flat",
            cursor="hand2",
            padx=28,
            pady=14,
            command=self.on_launch_clicked
        )
        self.launch_btn.pack()

        # Hover effects
        self.launch_btn.bind("<Enter>", lambda e: self.launch_btn.config(bg="#6366f1"))
        self.launch_btn.bind("<Leave>", lambda e: self.launch_btn.config(bg="#4f46e5"))

        # Footer
        footer = tk.Label(
            root,
            text="Cổng cục bộ: http://localhost:3000 • Hỗ trợ hoàn toàn offline",
            font=("Segoe UI", 8),
            fg="#64748b",
            bg="#0f172a"
        )
        footer.pack(side="bottom", pady=16)

        # Background status check
        threading.Thread(target=self.initial_check, daemon=True).start()

    def center_window(self):
        self.root.update_idletasks()
        w = 480
        h = 360
        x = (self.root.winfo_screenwidth() // 2) - (w // 2)
        y = (self.root.winfo_screenheight() // 2) - (h // 2)
        self.root.geometry(f"{w}x{h}+{x}+{y}")

    def initial_check(self):
        if is_server_running():
            self.root.after(0, lambda: self.update_status("🟢 Máy chủ đang chạy sẵn sàng", "#10b981", "#064e3b"))
        else:
            self.root.after(0, lambda: self.update_status("⚪ Máy chủ chưa bật (bấm nút để tự khởi động)", "#f59e0b", "#451a03"))

    def update_status(self, text, fg_color, bg_color):
        self.status_var.set(text)
        self.status_label.config(fg=fg_color, bg=bg_color)

    def on_launch_clicked(self):
        self.launch_btn.config(state="disabled", text="⏳ Đang mở trang web...")
        threading.Thread(target=self.do_launch, daemon=True).start()

    def do_launch(self):
        if not is_server_running():
            self.root.after(0, lambda: self.update_status("🔄 Đang khởi động máy chủ Node.js...", "#38bdf8", "#082f49"))
            success = start_server()
            if not success:
                self.root.after(0, lambda: self.update_status("❌ Không thể khởi động máy chủ", "#ef4444", "#450a0a"))
                self.root.after(0, lambda: messagebox.showerror("Lỗi", "Không thể khởi động máy chủ Node.js tại cổng 3000."))
                self.root.after(0, lambda: self.launch_btn.config(state="normal", text="🚀  MỞ TRANG WEB NGAY"))
                return

        webbrowser.open(URL)
        self.root.after(0, lambda: self.update_status("✅ Đã mở trang web tại http://localhost:3000", "#10b981", "#064e3b"))
        self.root.after(0, lambda: self.launch_btn.config(state="normal", text="🌐  MỞ LẠI TRÊN TRÌNH DUYỆT"))

if __name__ == "__main__":
    root = tk.Tk()
    app = WebLauncherApp(root)
    root.mainloop()
