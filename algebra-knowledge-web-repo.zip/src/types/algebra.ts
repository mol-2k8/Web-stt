export type TopicFilter = 'all' | 'theory' | 'pitfall' | 'example';

export interface Formula {
  id: string;
  label?: string;
  latex: string;
  explanation?: string;
  block?: boolean;
}

export interface Example {
  id: string;
  title: string;
  problem: string;
  solutionSteps: string[];
  tip?: string;
  difficulty?: 'Cơ bản' | 'Trung bình' | 'Nâng cao';
}

export interface Pitfall {
  id: string;
  name: string;
  fallacy: string;
  mechanism: string;
  counterexample: string;
  standardRule: string;
  category?: string;
}

export interface MasterTable {
  id: string;
  title: string;
  description?: string;
  headers: string[];
  rows: string[][];
}

export interface Section {
  id: string;
  title: string;
  pageRange: string;
  theoryContent: string;
  formulas: Formula[];
  examples: Example[];
  pitfalls: Pitfall[];
  masterTables?: MasterTable[];
}

export interface Chapter {
  id: string;
  number: number;
  title: string;
  description: string;
  sections: Section[];
  badge?: string;
}

export interface SearchItem {
  id: string;
  title: string;
  category: 'Chương' | 'Mục' | 'Lý thuyết' | 'Ví dụ' | 'Bẫy ngộ nhận' | 'Bảng tổng hợp';
  chapterId: string;
  sectionId?: string;
  snippet: string;
  targetId?: string;
}
