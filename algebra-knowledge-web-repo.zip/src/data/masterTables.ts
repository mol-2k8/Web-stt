import { MasterTable } from '../types/algebra';

export const dualityTable: MasterTable = {
  id: 'table-duality',
  title: 'Bảng đối ngẫu giữa Ảnh thuận f(·) và Tạo ảnh ngược f⁻¹(·)',
  description: 'Trích xuất nguyên văn Trang 5: So sánh tính bảo toàn cấu trúc đại số Boole của toán tử tạo ảnh ngược so với ảnh thuận.',
  headers: [
    'Phép toán tập hợp',
    'Ảnh thuận $f(\\cdot)$ trên các tập con $A, B \\subset X$',
    'Tạo ảnh ngược $f^{-1}(\\cdot)$ trên các tập con $C, D \\subset Y$',
    'Điều kiện để ảnh thuận đạt dấu đẳng thức',
  ],
  rows: [
    [
      'Phép hợp',
      '$f(A \\cup B) = f(A) \\cup f(B)$',
      '$f^{-1}(C \\cup D) = f^{-1}(C) \\cup f^{-1}(D)$',
      'Luôn đúng với mọi ánh xạ bất kỳ',
    ],
    [
      'Phép giao',
      '$f(A \\cap B) \\subset f(A) \\cap f(B)$',
      '$f^{-1}(C \\cap D) = f^{-1}(C) \\cap f^{-1}(D)$',
      '$f$ là đơn ánh',
    ],
    [
      'Phép hiệu',
      '$f(A) \\setminus f(B) \\subset f(A \\setminus B)$',
      '$f^{-1}(C \\setminus D) = f^{-1}(C) \\setminus f^{-1}(D)$',
      '$f$ là đơn ánh',
    ],
    [
      'Tác động liên tiếp',
      '$A \\subset f^{-1}(f(A))$',
      '$f(f^{-1}(C)) \\subset C$',
      '$A = f^{-1}(f(A)) \\iff f$ đơn ánh; $f(f^{-1}(C)) = C \\iff f$ toàn ánh',
    ],
  ],
};

export const algebraicHierarchyTable: MasterTable = {
  id: 'table-algebraic-hierarchy',
  title: 'Bảng phân cấp tổng hợp các cấu trúc đại số (6 tầng cấu trúc)',
  description: 'Trích xuất nguyên văn Trang 13: Hệ thống phân tầng 6 bậc cấu trúc đại số trừu tượng từ Nửa nhóm đến Trường số đóng kín.',
  headers: [
    'Cấu trúc đại số',
    'Ký hiệu',
    'Tiên đề phép toán thứ nhất',
    'Tiên đề phép toán thứ hai',
    'Ví dụ chuẩn mực',
  ],
  rows: [
    [
      'Nửa nhóm (Semigroup)',
      '$(X, *)$',
      'Đóng kín + Kết hợp',
      'Không có',
      '$(\\mathbb{N}^*, +), (M_n(\\mathbb{R}), \\cdot)$',
    ],
    [
      'Nhóm (Group)',
      '$(G, *)$',
      'Kết hợp + Trung hòa $e$ + Nghịch đảo $a^{-1}$',
      'Không có',
      '$(GL_n(\\mathbb{R}), \\cdot)$, Nhóm đối xứng $S_3$',
    ],
    [
      'Nhóm Abel',
      '$(G, +)$',
      'Tiên đề Nhóm + Giao hoán',
      'Không có',
      '$(\\mathbb{Z}, +), (\\mathbb{R}, +), (\\mathbb{R}^*, \\cdot)$',
    ],
    [
      'Vành (Ring)',
      '$(R, +, \\cdot)$',
      'Là một Nhóm Abel (trung hòa 0)',
      'Kết hợp + Phân phối 2 phía đối với $(+)$',
      '$(2\\mathbb{Z}, +, \\cdot), (M_n(\\mathbb{R}), +, \\cdot)$',
    ],
    [
      'Vành giao hoán có đơn vị',
      '$(R, +, \\cdot)$',
      'Là một Nhóm Abel (trung hòa 0)',
      'Kết hợp + Giao hoán + Đơn vị 1 + Phân phối',
      '$(\\mathbb{Z}, +, \\cdot), \\mathbb{Z}[\\sqrt{2}], (\\mathbb{Z}_6, +, \\cdot)$',
    ],
    [
      'Trường (Field)',
      '$(K, +, \\cdot)$',
      'Là một Nhóm Abel (trung hòa 0)',
      '$(K \\setminus \\{0\\}, \\cdot)$ là Nhóm Abel (đơn vị 1) + Phân phối',
      '$\\mathbb{Q}, \\mathbb{R}, \\mathbb{C}, \\mathbb{Q}[\\sqrt{3}], \\mathbb{Z}_p$ ($p$ nguyên tố)',
    ],
  ],
};

export const kroneckerCapelliTable: MasterTable = {
  id: 'table-kronecker-capelli',
  title: 'Ma trận phân loại nghiệm theo định lý Kronecker - Capelli',
  description: 'Trích xuất nguyên văn Trang 28: Mối tương quan giữa hạng ma trận hệ số và ma trận mở rộng với số bậc tự do của hệ phương trình.',
  headers: [
    'Trạng thái tương quan hạng',
    'Điều kiện tương thích',
    'Trạng thái nghiệm',
    'Số bậc tự do của nghiệm',
  ],
  rows: [
    [
      '$\\text{rank}(A) < \\text{rank}([A \\mid b])$',
      'Hệ không tương thích (mâu thuẫn)',
      'Vô nghiệm ($S = \\emptyset$)',
      'Không xác định',
    ],
    [
      '$\\text{rank}(A) = \\text{rank}([A \\mid b]) = r = n$',
      'Hệ tương thích',
      'Nghiệm duy nhất',
      '$0$ ẩn tự do (Nghiệm $X_0 = A^{-1}b$)',
    ],
    [
      '$\\text{rank}(A) = \\text{rank}([A \\mid b]) = r < n$',
      'Hệ tương thích',
      'Vô số nghiệm',
      '$n - r$ ẩn tự do (Đa tạp affine $X_0 + \\ker(A)$)',
    ],
  ],
};

export const cognitiveTrapsTable: MasterTable = {
  id: 'table-cognitive-traps',
  title: 'Ma trận bẫy nhận thức và khắc phục sai lầm thường gặp (12 phạm trù)',
  description: 'Trích xuất nguyên văn Trang 31 - 32: Bảng đối chuẩn 12 điểm nghẽn tư duy cốt lõi trong đại số đại cương và tuyến tính.',
  headers: [
    'Phạm trù kiến thức',
    'Sai lầm phổ biến',
    'Cơ chế phát sinh sai sót',
    'Quy tắc chuẩn hóa chính xác',
  ],
  rows: [
    [
      'Tập hợp & Quan hệ',
      'Đồng nhất phần tử tối đại với phần tử lớn nhất; quên nhân $2^n$ khi đếm quan hệ phản đối xứng.',
      'Không phân biệt thứ tự bộ phận và thứ tự toàn phần; bỏ sót các cặp trên đường chéo $(x, x)$.',
      'Tối đại có thể có nhiều, lớn nhất chỉ có tối đa 1; số quan hệ phản đối xứng là $2^n \\cdot 3^{\\frac{n(n-1)}{2}}$.',
    ],
    [
      'Đếm số toàn ánh',
      'Đồng nhất số toàn ánh với $n^m$ hoặc số chỉnh hợp $A_n^m$.',
      'Không loại trừ các ánh xạ có tập ảnh thực tế là tập con thực sự của miền đích.',
      'Áp dụng nguyên lý bù trừ: $\\sum_{k=0}^n (-1)^k \\binom{n}{k} (n-k)^m = n! S(m, n)$.',
    ],
    [
      'Ánh xạ hợp',
      'Suy diễn $g \\circ f$ đơn ánh thì cả $f$ và $g$ đều đơn ánh.',
      'Nhầm lẫn giữa tính chất của ánh xạ thành phần tác động trước và tác động sau.',
      '$g \\circ f$ đơn ánh chỉ suy ra $f$ đơn ánh; $g \\circ f$ toàn ánh chỉ suy ra $g$ toàn ánh.',
    ],
    [
      'Nhóm - Vành - Trường',
      'Cho rằng $\\mathbb{Z}$ hoặc $\\mathbb{Z}[\\sqrt{2}]$ là trường; quên khoét điểm làm mẫu số bằng 0 trong nhóm.',
      'Không kiểm tra sự tồn tại nghịch đảo phép nhân cho mọi phần tử khác 0.',
      '$\\mathbb{Z}$ và $\\mathbb{Z}[\\sqrt{2}]$ chỉ là vành giao hoán có đơn vị; $\\mathbb{Q}[\\sqrt{2}]$ và $\\mathbb{Z}_p$ ($p$ nguyên tố) mới là trường.',
    ],
    [
      'Hệ thức Viète',
      'Nhầm dấu tích nghiệm $z_1 z_2 z_3 = d/a$ thay vì $-d/a$; ngộ nhận $|z|^2 = z^2$.',
      'Không duy trì quy luật đan dấu luân phiên $(-1)^k$; áp dụng nhầm tính chất số thực cho số phức.',
      'Với bậc ba: $\\sigma_1 = -b/a, \\sigma_2 = c/a, \\sigma_3 = -d/a$; trên $\\mathbb{C}$ luôn có $|z|^2 = z \\cdot \\bar{z} \\neq z^2$.',
    ],
    [
      'Biểu thức đối xứng',
      'Quy đồng trực tiếp $\\sum z_i^{-2}$ dẫn đến sai dấu ở các hạng tử chéo.',
      'Khai triển mẫu số chung và nhân tử đối xứng bậc cao dễ nhầm lẫn dấu âm.',
      'Đổi biến $w = 1/z$, nghịch đảo thứ tự hệ số của đa thức và áp dụng Viète bậc 1 và 2.',
    ],
    [
      'Căn bậc $n$ đơn vị',
      'Cho rằng tích $\\prod (1 - \\varepsilon_k)$ bằng 1 hoặc triệt tiêu.',
      'Bỏ qua việc thế $z = 1$ vào khai triển hình học của đa thức $(z^n - 1)/(z - 1)$.',
      'Tích $\\prod (1 - \\varepsilon_k)$ từ 1 đến $n-1$ bằng $n$; tổng $\\sum \\varepsilon_k^m = 0$ khi $n$ không chia hết $m$.',
    ],
    [
      'Định thức nhân số',
      'Nhầm lẫn công thức thành $\\det(kA) = k \\det(A)$.',
      'Quên tính chất đa tuyến tính của định thức trên toàn bộ $n$ hàng độc lập.',
      '$\\det(kA) = k^n \\det(A)$ với mọi ma trận vuông cấp $n$.',
    ],
    [
      'Ma trận phụ hợp',
      'Viết công thức biến đổi vô hướng thành $(kA)^* = k^n A^*$ hoặc $\\det(A)=0$ suy ra $A^* = O$.',
      'Nhầm số chiều ma trận toàn phần $n$ với cấp của định thức con bù $n-1$.',
      '$(kA)^* = k^{n-1} A^*$ và $\\det(A^*) = (\\det A)^{n-1}$; $A^* = O$ khi và chỉ khi $\\text{rank}(A) \\le n - 2$.',
    ],
    [
      'Biến đổi sơ cấp',
      'Tùy tiện đổi hàng và cột mà không bảo toàn dấu của định thức; nhân nhầm phía ma trận sơ cấp.',
      'Không phân biệt biến đổi hàng (nhân trái ma trận sơ cấp) và cột (nhân phải ma trận sơ cấp).',
      '$h_i \\leftrightarrow h_j$ làm det đổi dấu; $k \\cdot h_i$ làm det nhân $k$; $h_i + c \\cdot h_j$ giữ nguyên det.',
    ],
    [
      'Nhị thức ma trận',
      'Áp dụng nhị thức $(A + B)^m = \\sum \\binom{m}{k} A^{m-k} B^k$ khi $AB \\neq BA$.',
      'Áp dụng công thức đại số giao hoán cho cấu trúc vành không giao hoán.',
      'Chỉ áp dụng khi $AB = BA$; phân rã ma trận về dạng giao hoán $A = \\lambda I + N$.',
    ],
    [
      'Biện luận hệ số',
      'Kết luận $\\det(A) = 0$ đồng nghĩa với việc hệ phương trình vô số nghiệm.',
      'Bỏ qua ma trận mở rộng $[A \\mid b]$, không kiểm tra điều kiện không tương thích $\\text{rank}(A) < \\text{rank}([A \\mid b])$.',
      '$\\det(A) \\neq 0$: nghiệm duy nhất. $\\det(A) = 0$: lập ma trận bậc thang để phân định vô nghiệm hay vô số nghiệm.',
    ],
  ],
};

export const masterTables = [
  dualityTable,
  algebraicHierarchyTable,
  kroneckerCapelliTable,
  cognitiveTrapsTable,
];
