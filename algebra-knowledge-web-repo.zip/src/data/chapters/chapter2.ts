import { Chapter } from '../../types/algebra';
import { allExamples } from '../examples';
import { allPitfalls } from '../pitfalls';
import { algebraicHierarchyTable } from '../masterTables';

export const chapter2: Chapter = {
  id: 'ch2',
  number: 2,
  title: 'Cấu trúc đại số: Nửa nhóm, Nhóm, Vành và Trường',
  description:
    'Hệ thống phân tầng 6 bậc cấu trúc đại số trừu tượng từ phép toán hai ngôi đơn lẻ đến trường số đóng kín: Nửa nhóm, Vị nhóm, Nhóm Abel, Vành, Miền nguyên và Trường thặng dư.',
  badge: 'Trang 7–13',
  sections: [
    {
      id: 'sec-2-1',
      title: '2.1 Phép toán hai ngôi, Tính đóng, Nửa nhóm và Vị nhóm (Monoid)',
      pageRange: 'Tr. 7–8',
      theoryContent:
        'Một phép toán hai ngôi trên tập hợp $X$ là một ánh xạ $*: X \\times X \\to X$. Tiên đề cơ bản nhất là tính đóng kín: với mọi $a, b \\in X$ thì $a * b \\in X$. Một tập hợp $X$ cùng với phép toán hai ngôi có tính kết hợp $((a * b) * c = a * (b * c))$ được gọi là một Nửa nhóm (Semigroup). Nếu nửa nhóm có phần tử trung hòa hai phía $(\\exists e \\in X: a * e = e * a = a, \\forall a)$, nó được gọi là một Vị nhóm (Monoid).',
      formulas: [
        {
          id: 'form-2-1-1',
          label: 'Tính đóng và Tính kết hợp',
          latex: '\\forall a, b, c \\in X: a * b \\in X \\quad \\text{và} \\quad (a * b) * c = a * (b * c)',
          explanation: 'Hai tiên đề nền tảng xác lập cấu trúc Nửa nhóm (Semigroup).',
          block: true,
        },
        {
          id: 'form-2-1-2',
          label: 'Phần tử trung hòa hai phía (Neutral Element)',
          latex: '\\exists ! e \\in X: \\forall a \\in X, \\quad a * e = e * a = a',
          explanation: 'Phần tử trung hòa nếu tồn tại thì luôn duy nhất và bắt buộc phải thỏa mãn cả hai phía.',
          block: true,
        },
      ],
      examples: [allExamples[8]], // ex-9
      pitfalls: [allPitfalls[10], allPitfalls[11]], // pit-11, pit-12
    },
    {
      id: 'sec-2-2',
      title: '2.2 Cấu trúc Nhóm, Nhóm Abel và Tiêu chuẩn nhận biết nhóm con',
      pageRange: 'Tr. 8–10',
      theoryContent:
        'Một Nhóm $(G, *)$ là một vị nhóm mà mọi phần tử đều có phần tử nghịch đảo hai phía: $\\forall a \\in G, \\exists a^{-1} \\in G: a * a^{-1} = a^{-1} * a = e$. Nếu phép toán có thêm tính giao hoán ($a * b = b * a$), nhóm được gọi là Nhóm Abel (nhóm giao hoán). Trong nhóm bất kỳ, luật giản ước hai phía luôn có hiệu lực: $a * x = a * y \\implies x = y$. Nghịch đảo của một tích luôn đảo ngược thứ tự: $(a * b)^{-1} = b^{-1} * a^{-1}$.',
      formulas: [
        {
          id: 'form-2-2-1',
          label: 'Tiêu chuẩn nhận biết nhóm con (Subgroup Criterion)',
          latex: 'H \\le G \\iff H \\neq \\emptyset \\quad \\text{và} \\quad \\forall x, y \\in H \\implies x * y^{-1} \\in H',
          explanation: 'Điều kiện cần và đủ để tập con $H$ của nhóm $G$ lập thành một nhóm con.',
          block: true,
        },
        {
          id: 'form-2-2-2',
          label: 'Đảo thứ tự nghịch đảo của tích',
          latex: '(a * b)^{-1} = b^{-1} * a^{-1}, \\quad ((a)^{-1})^{-1} = a',
          explanation: 'Thứ tự các nhân tử nghịch đảo bị đảo chiều trong nhóm không giao hoán.',
          block: true,
        },
      ],
      examples: [allExamples[9], allExamples[10]], // ex-10, ex-11
      pitfalls: [allPitfalls[12], allPitfalls[13]], // pit-13, pit-14
    },
    {
      id: 'sec-2-3',
      title: '2.3 Cấu trúc Vành, Miền nguyên, Ước của không và Tiêu chuẩn vành con',
      pageRange: 'Tr. 10–11',
      theoryContent:
        'Một Vành $(R, +, \\cdot)$ là một tập hợp trang bị hai phép toán hai ngôi thỏa mãn: $(R, +)$ là một nhóm Abel (phần tử trung hòa là $0$), phép nhân $(\\cdot)$ có tính kết hợp, và phép nhân phân phối hai phía đối với phép cộng: $a(b+c) = ab+ac$ và $(b+c)a = ba+ca$. Các phần tử khác không $a, b \\neq 0$ mà $a \\cdot b = 0$ được gọi là các Ước của không (Zero Divisors). Một vành giao hoán có đơn vị $1 \\neq 0$ không có ước của không được gọi là một Miền nguyên (Integral Domain).',
      formulas: [
        {
          id: 'form-2-3-1',
          label: 'Tiêu chuẩn nhận biết vành con (Subring Criterion)',
          latex: 'H \\subset R \\text{ là vành con} \\iff H \\neq \\emptyset, \\ \\forall x, y \\in H \\implies x - y \\in H \\ \\text{và} \\ x \\cdot y \\in H',
          explanation: 'Tập con đóng kín đối với phép trừ và phép nhân của vành lớn.',
          block: true,
        },
        {
          id: 'form-2-3-2',
          label: 'Miền nguyên và Luật giản ước',
          latex: 'a \\cdot b = 0 \\implies a = 0 \\lor b = 0; \\quad a \\cdot b = a \\cdot c \\ (a \\neq 0) \\implies b = c',
          explanation: 'Trong miền nguyên, không có ước của không và luật giản ước phép nhân có hiệu lực hoàn toàn.',
          block: true,
        },
      ],
      examples: [allExamples[11], allExamples[12]], // ex-12, ex-13
      pitfalls: [allPitfalls[14], allPitfalls[15], allPitfalls[16]], // pit-15, pit-16, pit-17
    },
    {
      id: 'sec-2-4',
      title: '2.4 Cấu trúc Trường, Trường con, Trường thặng dư Z_p và Trường mở rộng',
      pageRange: 'Tr. 11–13',
      theoryContent:
        'Một Trường $(K, +, \\cdot)$ là một vành giao hoán có đơn vị $1 \\neq 0$ mà mọi phần tử khác không đều khả nghịch đối với phép nhân, tức $(K \\setminus \\{0\\}, \\cdot)$ là một nhóm Abel. Mọi trường đều là miền nguyên (không có ước của không). Vành thặng dư $\\mathbb{Z}_n$ lập thành một trường khi và chỉ khi $n$ là một số nguyên tố $p$. Tập hợp $\\mathbb{Q}[\\sqrt{d}] = \\{a + b\\sqrt{d} \\mid a, b \\in \\mathbb{Q}\\}$ là một trường mở rộng của $\\mathbb{Q}$ khi và chỉ khi $d$ là số nguyên không chính phương.',
      formulas: [
        {
          id: 'form-2-4-1',
          label: 'Tiêu chuẩn nhận biết trường con (Subfield Criterion)',
          latex: 'F \\subset K \\text{ là trường con} \\iff |F| \\ge 2, \\ \\forall x, y \\in F: x - y \\in F \\ \\text{và} \\ \\forall y \\neq 0 \\implies x \\cdot y^{-1} \\in F',
          explanation: 'Tập con đóng kín đối với phép trừ và phép chia cho phần tử khác không.',
          block: true,
        },
        {
          id: 'form-2-4-2',
          label: 'Nghịch đảo nhân trong trường mở rộng Q[√d]',
          latex: '(a + b\\sqrt{d})^{-1} = \\frac{a}{a^2 - db^2} - \\frac{b}{a^2 - db^2}\\sqrt{d} \\quad (d \\text{ không chính phương})',
          explanation: 'Đại lượng chuẩn $a^2 - db^2 \\neq 0$ với mọi $(a, b) \\neq (0, 0)$ bảo đảm nghịch đảo luôn tồn tại trong $\\mathbb{Q}$.',
          block: true,
        },
      ],
      examples: [allExamples[13]], // ex-14
      pitfalls: [allPitfalls[17], allPitfalls[18], allPitfalls[19]], // pit-18, pit-19, pit-20
    },
    {
      id: 'sec-2-5',
      title: '2.5 Bảng phân cấp tổng hợp 6 tầng cấu trúc đại số',
      pageRange: 'Tr. 13',
      theoryContent:
        'Sơ đồ phân tầng 6 bậc cấu trúc đại số trừu tượng từ thấp đến cao: Nửa nhóm $\\to$ Monoid $\\to$ Nhóm $\\to$ Nhóm Abel $\\to$ Vành $\\to$ Miền nguyên $\\to$ Trường. Mỗi cấp độ bổ sung thêm một hệ tiên đề nhằm mở rộng năng lực tính toán và thu hẹp không gian sai số.',
      formulas: [
        {
          id: 'form-2-5-1',
          label: 'Chuỗi bao hàm cấu trúc số chuẩn mực',
          latex: '(\\mathbb{N}^*, +) \\subset (\\mathbb{N}, +) \\subset (\\mathbb{Z}, +) \\subset (\\mathbb{Q}, +, \\cdot) \\subset (\\mathbb{R}, +, \\cdot) \\subset (\\mathbb{C}, +, \\cdot)',
          explanation: 'Chuỗi cấu trúc đại số từ nửa nhóm, vị nhóm, nhóm Abel đến các trường số đóng kín.',
          block: true,
        },
      ],
      examples: [],
      pitfalls: [],
      masterTables: [algebraicHierarchyTable],
    },
  ],
};
