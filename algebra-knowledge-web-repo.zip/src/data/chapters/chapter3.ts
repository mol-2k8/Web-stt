import { Chapter } from '../../types/algebra';
import { allExamples } from '../examples';
import { allPitfalls } from '../pitfalls';

export const chapter3: Chapter = {
  id: 'ch3',
  number: 3,
  title: 'Số phức, Định lý Viète bậc cao và Căn bậc n của đơn vị',
  description:
    'Lý thuyết số phức nâng cao, dạng lượng giác Euler, công thức Moivre, khai căn bậc n, định lý Viète tổng quát với cơ chế đan dấu (-1)ᵏ, kỹ thuật đổi biến nghịch đảo w = z⁻¹ và cấu trúc nhóm cyclic căn đơn vị.',
  badge: 'Trang 13–18',
  sections: [
    {
      id: 'sec-3-1',
      title: '3.1 Các dạng biểu diễn số phức, Công thức Moivre và Khai căn số phức',
      pageRange: 'Tr. 13–15',
      theoryContent:
        'Mọi số phức khác không $z \\in \\mathbb{C}$ đều có thể biểu diễn dưới dạng đại số $z = a + bi$ ($a, b \\in \\mathbb{R}, i^2 = -1$), dạng lượng giác $z = r(\\cos\\varphi + i\\sin\\varphi)$ hoặc dạng số mũ Euler $z = r e^{i\\varphi}$, với môđun $r = |z| = \\sqrt{a^2 + b^2}$ và argument $\\varphi = \\arg(z)$. Đẳng thức cốt lõi liên hệ môđun và liên hợp: $z \\cdot \\bar{z} = |z|^2 = a^2 + b^2 \\implies z^{-1} = \\frac{\\bar{z}}{|z|^2}$. Lưu ý rằng $|z|^2 \\neq z^2$ trừ khi $z$ là số thực. Công thức Moivre cho phép tính lũy thừa nguyên nhanh chóng, và phép khai căn bậc $n$ luôn cho đúng $n$ giá trị phân biệt phân bố đều trên đường tròn.',
      formulas: [
        {
          id: 'form-3-1-1',
          label: 'Công thức Moivre và Lũy thừa số mũ Euler',
          latex: 'z^n = [r(\\cos\\varphi + i\\sin\\varphi)]^n = r^n(\\cos(n\\varphi) + i\\sin(n\\varphi)) = r^n e^{i n \\varphi}, \\quad \\forall n \\in \\mathbb{Z}',
          explanation: 'Lũy thừa số phức bằng cách nhân góc pha với $n$ và nâng môđun lên lũy thừa $n$.',
          block: true,
        },
        {
          id: 'form-3-1-2',
          label: 'Công thức khai căn bậc n của số phức',
          latex: 'w_k = \\sqrt[n]{r} \\left[ \\cos\\left(\\frac{\\varphi + 2k\\pi}{n}\\right) + i\\sin\\left(\\frac{\\varphi + 2k\\pi}{n}\\right) \\right], \\quad k = 0, 1, \\dots, n - 1',
          explanation: 'Tập hợp $n$ căn bậc $n$ phân biệt tạo thành các đỉnh của một đa giác đều $n$ cạnh nội tiếp đường tròn bán kính $\\sqrt[n]{r}$.',
          block: true,
        },
      ],
      examples: [allExamples[14]], // ex-15
      pitfalls: [allPitfalls[20], allPitfalls[21]], // pit-21, pit-22
    },
    {
      id: 'sec-3-2',
      title: '3.2 Biện luận phương trình phức và Hệ phương trình chứa z và z̄',
      pageRange: 'Tr. 14–15',
      theoryContent:
        'Phương trình bậc hai hệ số phức $az^2 + bz + c = 0$ ($a \\neq 0$) luôn có 2 nghiệm phân biệt khi và chỉ khi biệt thức $\\Delta = b^2 - 4ac \\neq 0$ (trường số phức không có quan hệ thứ tự $\\Delta > 0$). Với phương trình chứa đồng thời $z$ và liên hợp $\\bar{z}$, phép toán $z \\mapsto \\bar{z}$ là phi tuyến phức, do đó bắt buộc phải quy về hệ hai phương trình tuyến tính hai ẩn thực $x, y$ bằng cách đặt $z = x + yi$. Hệ này có thể vô nghiệm, nghiệm duy nhất hoặc vô số nghiệm.',
      formulas: [
        {
          id: 'form-3-2-1',
          label: 'Hệ phương trình thực tương đương cho phương trình z, z̄',
          latex: 'z = x + yi, \\quad Az + B\\bar{z} = C \\iff \\begin{cases} \\text{Re}(Az + B\\bar{z}) = \\text{Re}(C) \\\\ \\text{Im}(Az + B\\bar{z}) = \\text{Im}(C) \\end{cases}',
          explanation: 'Chuyển phương trình phức phi tuyến sang hệ đại số tuyến tính 2 ẩn thực.',
          block: true,
        },
      ],
      examples: [allExamples[15]], // ex-16
      pitfalls: [allPitfalls[22], allPitfalls[23]], // pit-23, pit-24
    },
    {
      id: 'sec-3-3',
      title: '3.3 Định lý Viète tổng quát bậc cao và Cơ chế đan dấu đại số (-1)ᵏ',
      pageRange: 'Tr. 15–17',
      theoryContent:
        'Theo Định lý cơ bản của Đại số, mọi đa thức bậc $n$ trên $\\mathbb{C}$: $P(z) = a_n z^n + a_{n-1} z^{n-1} + \\dots + a_1 z + a_0$ ($a_n \\neq 0$) đều có đúng $n$ nghiệm phức (kể cả bội): $P(z) = a_n \\prod_{k=1}^n (z - z_k)$. Khai triển tích này dẫn đến hệ thức Viète tổng quát cho các đa thức đối xứng cơ bản $\\sigma_k$. Điểm then chốt là cơ chế đan dấu luân phiên $(-1)^k$: các tổng chẵn mang dấu dương, các tổng lẻ mang dấu âm.',
      formulas: [
        {
          id: 'form-3-3-1',
          label: 'Định lý Viète tổng quát bậc cao',
          latex: '\\sigma_k = \\sum_{1 \\le i_1 < i_2 < \\dots < i_k \\le n} z_{i_1} z_{i_2} \\dots z_{i_k} = (-1)^k \\frac{a_{n-k}}{a_n}, \\quad k = 1, 2, \\dots, n',
          explanation: 'Quy tắc đan dấu $(-1)^k$ và bắt buộc chia cho hệ số cao nhất $a_n$.',
          block: true,
        },
        {
          id: 'form-3-3-2',
          label: 'Hệ thức Viète và Tổng lập phương bậc ba',
          latex: '\\sigma_1 = -\\frac{b}{a}, \\ \\sigma_2 = \\frac{c}{a}, \\ \\sigma_3 = -\\frac{d}{a}; \\quad S_3 = z_1^3 + z_2^3 + z_3^3 = \\sigma_1^3 - 3\\sigma_1 \\sigma_2 + 3\\sigma_3',
          explanation: 'Hằng đẳng thức đối xứng Newton bậc ba biểu diễn qua các đa thức sơ cấp.',
          block: true,
        },
      ],
      examples: [allExamples[16]], // ex-17
      pitfalls: [allPitfalls[24]], // pit-25
    },
    {
      id: 'sec-3-4',
      title: '3.4 Kỹ thuật đổi biến nghịch đảo w = z⁻¹ tính biểu thức đối xứng hữu tỉ',
      pageRange: 'Tr. 15–18',
      theoryContent:
        'Khi cần tính tổng các lũy thừa âm của các nghiệm, như tổng nghịch đảo $\\sum z_k^{-1}$ hay tổng bình phương nghịch đảo $\\sum z_k^{-2}$, phương pháp quy đồng mẫu số chung truyền thống rất dễ dẫn đến sai sót dấu ở các hạng tử chéo. Kỹ thuật đổi biến hình thức $w = z^{-1} \\iff z = w^{-1}$ cho phép nghịch đảo toàn bộ dãy hệ số của đa thức ($Q(w) = a_0 w^n + a_1 w^{n-1} + \\dots + a_n = 0$), đưa bài toán tính tổng lũy thừa âm về bài toán Viète lũy thừa dương sơ cấp.',
      formulas: [
        {
          id: 'form-3-4-1',
          label: 'Đa thức nghịch đảo (Reciprocal Polynomial)',
          latex: 'P(z) = 0 \\xrightarrow{w = z^{-1}} Q(w) = a_0 w^n + a_1 w^{n-1} + \\dots + a_{n-1} w + a_n = 0',
          explanation: 'Các nghiệm của $Q(w)$ chính là nghịch đảo của các nghiệm của $P(z)$.',
          block: true,
        },
        {
          id: 'form-3-4-2',
          label: 'Tính tổng nghịch đảo bình phương qua đa thức đối xứng',
          latex: '\\sum_{k=1}^n z_k^{-2} = \\sum_{k=1}^n w_k^2 = \\left( -\\frac{a_1}{a_0} \\right)^2 - 2\\left( \\frac{a_2}{a_0} \\right)',
          explanation: 'Chuyển hoàn toàn biểu thức hữu tỉ phức tạp sang đa thức đối xứng của $w$.',
          block: true,
        },
      ],
      examples: [allExamples[17]], // ex-18
      pitfalls: [],
    },
    {
      id: 'sec-3-5',
      title: '3.5 Căn bậc n của đơn vị, Cấu trúc nhóm Cyclic và Các đồng nhất thức giải tích',
      pageRange: 'Tr. 17–18',
      theoryContent:
        'Hệ thống $n$ căn bậc $n$ của đơn vị $\\varepsilon_k = e^{i\\frac{2k\\pi}{n}}$ ($k = 0, 1, \\dots, n - 1$) lập thành một nhóm cyclic cấp $n$ đối với phép nhân số phức, sinh bởi phần tử căn nguyên thủy $\\varepsilon_1$. Tổng lũy thừa bậc $m$ của các căn đơn vị triệt tiêu khi $n$ không chia hết $m$. Bằng phương pháp đồng nhất thức đa thức $z^n - 1 = (z - 1) \\prod_{k=1}^{n-1} (z - \\varepsilon_k) = (z - 1)(z^{n-1} + \\dots + 1)$ và lấy đạo hàm logarit, ta thiết lập được các công thức tính tích và tổng hữu tỉ kinh điển.',
      formulas: [
        {
          id: 'form-3-5-1',
          label: 'Đồng nhất thức tích căn đơn vị tại z = 1',
          latex: '\\prod_{k=1}^{n-1} (1 - \\varepsilon_k) = n \\quad (\\text{Lưu ý: Tích chạy từ } k = 1)',
          explanation: 'Tích chạy từ $k = 0$ sẽ bằng 0 vì thừa số $1 - \\varepsilon_0 = 1 - 1 = 0$.',
          block: true,
        },
        {
          id: 'form-3-5-2',
          label: 'Đạo hàm logarit của đa thức căn đơn vị',
          latex: '\\sum_{k=0}^{n-1} \\frac{1}{z - \\varepsilon_k} = \\frac{n z^{n-1}}{z^n - 1}, \\quad \\prod_{k=0}^{n-1} (a \\varepsilon_k + b) = b^n - (-a)^n',
          explanation: 'Công thức tổng quát tính tổng phân thức hữu tỉ và tích nhị thức chứa căn đơn vị.',
          block: true,
        },
      ],
      examples: [allExamples[18], allExamples[19]], // ex-19, ex-20
      pitfalls: [allPitfalls[25], allPitfalls[26]], // pit-26, pit-27
    },
  ],
};
