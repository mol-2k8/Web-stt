import { Chapter } from '../../types/algebra';
import { allExamples } from '../examples';
import { allPitfalls } from '../pitfalls';
import { kroneckerCapelliTable } from '../masterTables';

export const chapter5: Chapter = {
  id: 'ch5',
  number: 5,
  title: 'Hạng ma trận và Cấu trúc hệ phương trình tuyến tính',
  description:
    'Định lý Kronecker - Capelli, bảng phân loại nghiệm tương quan hạng, cấu trúc không gian nghiệm hạt nhân ker(A) với số chiều n - r, cấu trúc đa tạp affine X₀ + ker(A), tổ hợp affine nghiệm và kỹ thuật biện luận hệ chứa tham số m.',
  badge: 'Trang 27–30',
  sections: [
    {
      id: 'sec-5-1',
      title: '5.1 Định lý Kronecker - Capelli và Điều kiện tương thích',
      pageRange: 'Tr. 27–28',
      theoryContent:
        'Hệ phương trình tuyến tính $m$ phương trình, $n$ ẩn số có dạng ma trận $A X = b$, trong đó $A \\in M_{m \\times n}(\\mathbb{R})$ là ma trận hệ số và $\\bar{A} = [A \\mid b]$ là ma trận hệ số mở rộng. Định lý Kronecker - Capelli xác lập điều kiện cần và đủ cho tính tương thích: hệ có nghiệm khi và chỉ khi hạng của ma trận hệ số bằng hạng của ma trận mở rộng: $\\text{rank}(A) = \\text{rank}([A \\mid b]) = r$. Nếu $r < \\text{rank}([A \\mid b])$, hệ không tương thích (vô nghiệm). Nếu hệ có $m < n$ phương trình ít hơn ẩn, hệ không bao giờ có nghiệm duy nhất (chỉ có thể vô nghiệm hoặc vô số nghiệm).',
      formulas: [
        {
          id: 'form-5-1-1',
          label: 'Định lý Kronecker - Capelli',
          latex: 'AX = b \\text{ có nghiệm} \\iff \\text{rank}(A) = \\text{rank}([A \\mid b])',
          explanation: 'Véc tơ cột hệ số tự do $b$ là tổ hợp tuyến tính của các cột của ma trận $A$.',
          block: true,
        },
        {
          id: 'form-5-1-2',
          label: 'Hệ quả số phương trình nhỏ hơn số ẩn (m < n)',
          latex: 'm < n \\implies \\text{Hệ } AX = b \\text{ KHÔNG THỂ có nghiệm duy nhất}',
          explanation: 'Vì $\\text{rank}(A) \\le m < n$, hệ chỉ có thể vô nghiệm hoặc vô số nghiệm.',
          block: true,
        },
      ],
      examples: [],
      pitfalls: [allPitfalls[39], allPitfalls[40]], // pit-40, pit-41
    },
    {
      id: 'sec-5-2',
      title: '5.2 Bảng ma trận phân loại nghiệm theo định lý Kronecker - Capelli',
      pageRange: 'Tr. 28',
      theoryContent:
        'Bảng phân loại trạng thái nghiệm dựa trên sự so sánh hạng $r = \\text{rank}(A)$, $\\text{rank}([A \\mid b])$ và số ẩn $n$. Hệ thống chia thành ba trường hợp hoàn chỉnh: Vô nghiệm, Nghiệm duy nhất, và Vô số nghiệm phụ thuộc $n - r$ tham số tự do.',
      formulas: [
        {
          id: 'form-5-2-1',
          label: 'Số bậc tự do của hệ phương trình',
          latex: 'k = n - \\text{rank}(A) = n - r',
          explanation: 'Số lượng ẩn tự do trong công thức nghiệm tổng quát của hệ tương thích.',
          block: true,
        },
      ],
      examples: [allExamples[27]], // ex-28
      pitfalls: [],
      masterTables: [kroneckerCapelliTable],
    },
    {
      id: 'sec-5-3',
      title: '5.3 Cấu trúc Không gian nghiệm hệ thuần nhất ker(A) và Số chiều dim = n - r',
      pageRange: 'Tr. 28–29',
      theoryContent:
        'Hệ phương trình thuần nhất $A X = 0$ ($A \\in M_{m \\times n}(\\mathbb{R})$) luôn tương thích vì luôn có nghiệm tầm thường $X = 0$. Không gian nghiệm $S_0 = \\ker(A) = \\{X \\in \\mathbb{R}^n \\mid AX = 0\\}$ là một không gian vectơ con của $\\mathbb{R}^n$. Định lý số chiều xác nhận: $\\dim(S_0) = n - \\text{rank}(A)$. Hệ có nghiệm không tầm thường khi và chỉ khi $\\text{rank}(A) < n$. Đặc biệt, nếu tổng các phần tử trên mỗi hàng của $A$ bằng 0 thì véc tơ $(1, 1, \\dots, 1)^T$ là nghiệm không tầm thường, kéo theo $\\det(A) = 0$ và hệ liên hợp $A^T X = 0$ cũng luôn có nghiệm không tầm thường.',
      formulas: [
        {
          id: 'form-5-3-1',
          label: 'Số chiều không gian nghiệm hạt nhân (Rank-Nullity)',
          latex: '\\dim(\\ker(A)) = n - \\text{rank}(A)',
          explanation: 'Cơ sở của $\\ker(A)$ gồm đúng $n - r$ nghiệm cơ bản độc lập tuyến tính.',
          block: true,
        },
        {
          id: 'form-5-3-2',
          label: 'Tính chất ma trận có tổng hàng bằng 0',
          latex: '\\sum_{j=1}^n a_{ij} = 0, \\forall i \\implies A \\begin{pmatrix} 1 \\\\ \\vdots \\\\ 1 \\end{pmatrix} = 0 \\implies \\det(A) = 0',
          explanation: 'Véc tơ cột toàn số 1 là nghiệm không tầm thường của hệ thuần nhất.',
          block: true,
        },
      ],
      examples: [],
      pitfalls: [],
    },
    {
      id: 'sec-5-4',
      title: '5.4 Cấu trúc Đa tạp affine của nghiệm hệ không thuần nhất và Tổ hợp affine',
      pageRange: 'Tr. 28–29',
      theoryContent:
        'Nghiệm tổng quát của hệ phương trình tuyến tính không thuần nhất $AX = b$ ($b \\neq 0$) có cấu trúc hình học của một Đa tạp affine (Affine Manifold): $S = X_0 + \\ker(A) = \\{X_0 + Y \\mid AY = 0\\}$, trong đó $X_0$ là một nghiệm riêng cố định. Hiệu của hai nghiệm bất kỳ $X_1 - X_2$ luôn là một nghiệm của hệ thuần nhất liên kết: $A(X_1 - X_2) = b - b = 0$. Tổ hợp tuyến tính $\\alpha X_1 + \\beta X_2$ là một nghiệm của $AX = b$ khi và chỉ khi $\\alpha + \\beta = 1$ (tổ hợp affine). Chẳng hạn véc tơ $2X_1 - X_2$ hay $\\frac{1}{2}X_1 + \\frac{1}{2}X_2$ luôn là nghiệm.',
      formulas: [
        {
          id: 'form-5-4-1',
          label: 'Cấu trúc đa tạp affine của tập nghiệm',
          latex: 'S = X_0 + \\ker(A) = \\{X_0 + c_1 Y_1 + \\dots + c_{n-r} Y_{n-r} \\mid c_i \\in \\mathbb{R}\\}',
          explanation: 'Không gian nghiệm là không gian affine song song với không gian con tuyến tính $\\ker(A)$.',
          block: true,
        },
        {
          id: 'form-5-4-2',
          label: 'Điều kiện tổ hợp affine bảo toàn nghiệm',
          latex: 'A(\\alpha X_1 + \\beta X_2) = b \\iff \\alpha + \\beta = 1 \\quad (\\text{với } AX_1 = b, AX_2 = b)',
          explanation: 'Tổ hợp tuyến tính của hai nghiệm chỉ là nghiệm khi tổng các hệ số bằng 1.',
          block: true,
        },
      ],
      examples: [allExamples[28]], // ex-29
      pitfalls: [],
    },
    {
      id: 'sec-5-5',
      title: '5.5 Phương trình ma trận AX = B và Biện luận hệ chứa tham số m',
      pageRange: 'Tr. 29–30',
      theoryContent:
        'Phương trình ma trận $AX = B$ với $A \\in M_{m \\times n}(\\mathbb{R})$ và $B \\in M_{m \\times p}(\\mathbb{R})$ thực chất gồm $p$ hệ phương trình tuyến tính độc lập ghép lại song song. Phương trình ma trận có vô số nghiệm khi và chỉ khi toàn bộ các hệ con đều có vô số nghiệm, tức $\\text{rank}(A) = \\text{rank}([A \\mid B]) < n$. Khi biện luận hệ theo tham số $m$, tính $\\det(A) = 0$ chỉ là điều kiện cần; bước quyết định là thế các giá trị tới hạn của $m$ vào ma trận mở rộng $[A \\mid b]$ và khử Gauss để phân định dứt khoát giữa trạng thái vô nghiệm và vô số nghiệm.',
      formulas: [
        {
          id: 'form-5-5-1',
          label: 'Điều kiện tương thích của phương trình ma trận',
          latex: 'AX = B \\text{ có vô số nghiệm} \\iff \\text{rank}(A) = \\text{rank}([A \\mid B]) < n',
          explanation: 'Mọi cột của ma trận $B$ phải là tổ hợp tuyến tính của các cột độc lập của $A$.',
          block: true,
        },
      ],
      examples: [allExamples[29]], // ex-30
      pitfalls: [allPitfalls[41]], // pit-42
    },
  ],
};
