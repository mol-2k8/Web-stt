import { Chapter } from '../../types/algebra';

export const chapter7: Chapter = {
  id: 'ch7',
  number: 7,
  title: 'Kết luận và Ba nguyên tắc vàng thực hành đại số',
  description:
    'Đúc kết ba nguyên tắc vàng định hướng tư duy và kỹ thuật thực hành đại số chuyên sâu: Tối ưu hóa qua đổi biến hình thức, Kiểm tra giao hoán và khả nghịch, và Phân tách triệt tiêu định thức với trạng thái nghiệm.',
  badge: 'Trang 32–33',
  sections: [
    {
      id: 'sec-7-1',
      title: '7.1 Nguyên tắc 1: Tối ưu hóa kỹ thuật qua phép đổi biến hình thức w = z⁻¹',
      pageRange: 'Tr. 32–33',
      theoryContent:
        'Trong các bài toán tính giá trị biểu thức đối xứng của nghiệm đa thức hoặc nghiệm phức có bậc cao, việc quy đồng mẫu số các phân thức hữu tỉ mang lại rủi ro sai sót rất lớn ở các hệ số đan dấu chéo. Nguyên tắc vàng thứ nhất yêu cầu: Hãy luôn tìm kiếm một phép đổi biến hình thức thích hợp, đặc biệt là phép đặt ẩn phụ nghịch đảo $w = z^{-1}$ hoặc phép tịnh tiến biến số $w = z - c$. Khi đặt $w = z^{-1}$, đa thức mới $Q(w) = a_0 w^n + a_1 w^{n-1} + \\dots + a_n = 0$ có thứ tự các hệ số bị đảo ngược hoàn toàn, đưa toàn bộ các tổng lũy thừa âm khó xử lý về tổng lũy thừa dương sơ cấp giải quyết ngay bằng hệ thức Viète.',
      formulas: [
        {
          id: 'form-7-1-1',
          label: 'Nguyên lý chuyển đổi hệ số qua biến đổi nghịch đảo',
          latex: 'a_n z^n + a_{n-1} z^{n-1} + \\dots + a_0 = 0 \\xrightarrow{w = z^{-1}} a_0 w^n + a_1 w^{n-1} + \\dots + a_n = 0',
          explanation: 'Đảo ngược hoàn toàn dãy hệ số, biến tổng nghịch đảo thành tổng nghiệm thông thường.',
          block: true,
        },
      ],
      examples: [],
      pitfalls: [],
    },
    {
      id: 'sec-7-2',
      title: '7.2 Nguyên tắc 2: Kiểm tra giao hoán và khả nghịch trước khi áp dụng công cụ ma trận',
      pageRange: 'Tr. 33',
      theoryContent:
        'Không gian ma trận $M_n(K)$ là một vành không giao hoán và có chứa các ước của không. Mọi công thức đại số quen thuộc từ trường số thực (như nhị thức Newton $(A+B)^m$, phân tích hằng đẳng thức $A^2 - B^2 = (A-B)(A+B)$, hay luật giản ước $AB = AC \\implies B=C$) đều vô hiệu trừ khi có điều kiện giao hoán $AB = BA$ hoặc tính khả nghịch $\\det(A) \\neq 0$. Nguyên tắc vàng thứ hai: Tuyệt đối không áp dụng nhị thức Newton cho hai ma trận trừ khi đã chứng minh $AB = BA$. Khi tính lũy thừa bậc cao, luôn phân rã ma trận về dạng giao hoán $A = \\lambda I_n + N$ với $N$ là ma trận lũy linh ($N^p = O$), hoặc thực hiện chéo hóa thông qua hệ véc tơ riêng.',
      formulas: [
        {
          id: 'form-7-2-1',
          label: 'Phân rã ma trận chuẩn tắc cho tính lũy thừa',
          latex: 'A = \\lambda I_n + N \\ (N^p = O, \\ \\lambda I_n N = N \\lambda I_n) \\implies A^m = \\sum_{k=0}^{p-1} \\binom{m}{k} \\lambda^{m-k} N^k',
          explanation: 'Vì $\\lambda I_n$ giao hoán với mọi ma trận, công thức nhị thức Newton được áp dụng an toàn và cắt ngắn tại $p$.',
          block: true,
        },
      ],
      examples: [],
      pitfalls: [],
    },
    {
      id: 'sec-7-3',
      title: '7.3 Nguyên tắc 3: Phân tách rành mạch triệt tiêu định thức và trạng thái nghiệm',
      pageRange: 'Tr. 33',
      theoryContent:
        'Một trong những sai lầm có tần suất cao nhất của sinh viên đại số là đồng nhất việc định thức triệt tiêu $\\det(A) = 0$ với trạng thái hệ phương trình có vô số nghiệm. Nguyên tắc vàng thứ ba: $\\det(A) = 0$ chỉ khẳng định ma trận suy biến và hệ KHÔNG CÓ nghiệm duy nhất. Để biết hệ vô nghiệm hay vô số nghiệm, con đường duy nhất đúng đắn và chuẩn mực là lập ma trận mở rộng $\\bar{A} = [A \\mid b]$ và thực hiện các phép biến đổi sơ cấp theo dòng để đưa về dạng bậc thang (REF). Sự xuất hiện của dòng có dạng $(0 \\; 0 \\; \\dots \\; 0 \\mid c)$ với $c \\neq 0$ là chứng chỉ duy nhất kết luận hệ vô nghiệm.',
      formulas: [
        {
          id: 'form-7-3-1',
          label: 'Quy tắc phân định nghiệm chuẩn mực qua Khử Gauss',
          latex: '\\det(A) = 0 \\implies \\begin{cases} \\text{rank}(A) < \\text{rank}([A \\mid b]) & \\implies \\text{Vô nghiệm} \\\\ \\text{rank}(A) = \\text{rank}([A \\mid b]) < n & \\implies \\text{Vô số nghiệm} \\end{cases}',
          explanation: 'Không bao giờ kết luận trạng thái nghiệm chỉ dựa trên định thức ma trận hệ số.',
          block: true,
        },
      ],
      examples: [],
      pitfalls: [],
    },
    {
      id: 'sec-7-4',
      title: '7.4 Lời kết luận chuyên khảo và Phương pháp tự học đại số đại cương & tuyến tính',
      pageRange: 'Tr. 33',
      theoryContent:
        'Đại số đại cương và đại số tuyến tính không phải là tập hợp các công thức tính toán rời rạc, mà là một hệ thống cấu trúc logic hài hòa, trừu tượng và nhất quán cao độ. Việc làm chủ môn học đòi hỏi người học xây dựng thói quen truy nguyên tiên đề (axiomatic tracing), nhận diện cấu trúc trước khi tính toán, và duy trì sự cảnh giác thường trực đối với các bẫy nhận thức phát sinh từ thói quen trực giác số học. Ba nguyên tắc vàng và Ma trận bẫy nhận thức 12 phạm trù được tổng kết trong chuyên khảo này sẽ đóng vai trò như chiếc la bàn tư duy vững chắc, giúp người học chuyển hóa kiến thức từ ghi nhớ máy móc sang thấu hiểu bản chất đại số hiện đại.',
      formulas: [],
      examples: [],
      pitfalls: [],
    },
  ],
};
