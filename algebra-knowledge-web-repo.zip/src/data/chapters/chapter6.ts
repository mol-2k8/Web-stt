import { Chapter } from '../../types/algebra';
import { cognitiveTrapsTable } from '../masterTables';

export const chapter6: Chapter = {
  id: 'ch6',
  number: 6,
  title: 'Ma trận bẫy nhận thức và Khắc phục sai lầm thường gặp',
  description:
    'Phân tích căn nguyên tâm lý học nhận thức và cơ chế phát sinh sai sót toán học qua 12 phạm trù đại số cốt lõi: Tập hợp, Ánh xạ, Cấu trúc đại số, Viète phức, Căn đơn vị, Định thức, Ma trận phụ hợp và Biện luận hệ phương trình.',
  badge: 'Trang 30–32',
  sections: [
    {
      id: 'sec-6-1',
      title: '6.1 Cơ chế tâm lý học nhận thức và Căn nguyên phát sinh sai sót đại số',
      pageRange: 'Tr. 30–31',
      theoryContent:
        'Trong quá trình tiếp cận và thực hành đại số đại cương và đại số tuyến tính, sinh viên thường gặp phải các điểm nghẽn nhận thức (cognitive bottlenecks). Căn nguyên gốc rễ không chỉ nằm ở việc quên công thức, mà bắt nguồn từ ba cơ chế tâm lý học nhận thức chủ đạo: (1) Xu hướng ngoại suy sai lầm từ trực giác số học sơ cấp (Over-generalization from elementary arithmetic): mang các tính chất giao hoán, phân phối số học thông thường sang các cấu trúc không giao hoán như vành ma trận hoặc đại số tập hợp; (2) Trộn lẫn giữa các ký hiệu hình thức tương đồng (Notation ambiguity): ví dụ đồng nhất hàm số ngược $f^{-1}$ với toán tử tạo ảnh tập con $f^{-1}(C)$, hay nhầm lẫn giữa định thức con bù $n-1$ và số chiều ma trận $n$; (3) Đánh đồng điều kiện cần với điều kiện đủ: ngộ nhận $\\det(A) = 0$ đồng nghĩa với việc hệ có vô số nghiệm.',
      formulas: [
        {
          id: 'form-6-1-1',
          label: 'Quy tắc cảnh báo ba sai lầm bản năng',
          latex: 'AB \\neq BA \\quad (\\text{Ma trận}); \\quad |z|^2 = z \\cdot \\bar{z} \\neq z^2 \\quad (\\text{Số phức}); \\quad \\det(A) = 0 \\not\\implies \\text{Vô số nghiệm}',
          explanation: 'Ba điểm nghẽn nhận thức thường xuyên gây mất điểm nhiều nhất trong các kỳ thi đại số chuyên sâu.',
          block: true,
        },
      ],
      examples: [],
      pitfalls: [],
    },
    {
      id: 'sec-6-2',
      title: '6.2 Ma trận bẫy nhận thức 12 phạm trù kiến thức trọng yếu',
      pageRange: 'Tr. 31–32',
      theoryContent:
        'Bảng đối chuẩn toàn diện 12 phạm trù kiến thức đại số: cung cấp phân tích chi tiết về sai lầm phổ biến, cơ chế phát sinh sai sót toán học tương ứng, và quy tắc chuẩn hóa chuẩn mực kèm phản ví dụ định lượng để khắc phục triệt để.',
      formulas: [],
      examples: [],
      pitfalls: [],
      masterTables: [cognitiveTrapsTable],
    },
    {
      id: 'sec-6-3',
      title: '6.3 Quy trình kiểm tra đối chuẩn trước khi kết luận nghiệm và hạng',
      pageRange: 'Tr. 32',
      theoryContent:
        'Để triệt tiêu hoàn toàn sai sót khi làm bài tập và nghiên cứu đại số, người học cần tuân thủ quy trình kiểm tra 4 bước trước khi đưa ra kết luận: Bước 1: Kiểm tra tính khả thi kích thước (Dimensional compatibility check) cho mọi phép toán ma trận; Bước 2: Kiểm tra tính giao hoán và tính khả nghịch trước khi áp dụng hằng đẳng thức hay định lý lũy thừa; Bước 3: Phân tách rành mạch trường số thực $\\mathbb{R}$ và trường số phức $\\mathbb{C}$, không dùng thứ tự so sánh trên $\\mathbb{C}$; Bước 4: Khi biện luận hệ có tham số, luôn kiểm tra trực tiếp các giá trị tới hạn trên ma trận bậc thang mở rộng để loại trừ mâu thuẫn.',
      formulas: [
        {
          id: 'form-6-3-1',
          label: 'Quy trình kiểm tra 4 bước chuẩn mực',
          latex: '\\text{Kích thước} \\longrightarrow \\text{Giao hoán \\& Khả nghịch} \\longrightarrow \\text{Trường số} \\longrightarrow \\text{Ma trận bậc thang mở rộng}',
          explanation: 'Chu trình kiểm soát chất lượng lời giải toán học nhằm bảo đảm tính chính xác tuyệt đối.',
          block: true,
        },
      ],
      examples: [],
      pitfalls: [],
    },
  ],
};
