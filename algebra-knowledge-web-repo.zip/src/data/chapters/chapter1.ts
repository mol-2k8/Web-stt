import { Chapter } from '../../types/algebra';
import { allExamples } from '../examples';
import { allPitfalls } from '../pitfalls';
import { dualityTable } from '../masterTables';

export const chapter1: Chapter = {
  id: 'ch1',
  number: 1,
  title: 'Tập hợp, Quan hệ hai ngôi, Ánh xạ và Kỹ thuật đếm',
  description:
    'Nền tảng logic học và lý thuyết tập hợp Boole, cấu trúc quan hệ hai ngôi, quan hệ tương đương, thứ tự bộ phận và toàn phần, phân loại ánh xạ và kỹ thuật đếm tổ hợp qua số Stirling loại hai.',
  badge: 'Trang 1–7',
  sections: [
    {
      id: 'sec-1-1',
      title: '1.1 Đại số tập hợp Boole, Phép toán logic và Tích Descartes',
      pageRange: 'Tr. 1–2',
      theoryContent:
        'Cho tập hợp nền tảng $X$. Với mọi tập con $A, B, C \\subseteq X$, các phép toán hợp ($A \\cup B$), giao ($A \\cap B$), hiệu ($A \\setminus B$) và hiệu đối xứng ($A \\Delta B$) thỏa mãn hệ tiên đề đại số Boole hoàn chỉnh. Luật phân phối thiết lập mối liên hệ giữa giao và hợp: $A \\cap (B \\cup C) = (A \\cap B) \\cup (A \\cap C)$ và $A \\cup (B \\cap C) = (A \\cup B) \\cap (A \\cup C)$. Định lý De Morgan mở rộng cho phép hiệu tập hợp là công cụ then chốt trong biến đổi tập hợp.',
      formulas: [
        {
          id: 'form-1-1-1',
          label: 'Định luật De Morgan cho phép hiệu tập hợp',
          latex: 'A \\setminus (B \\cup C) = (A \\setminus B) \\cap (A \\setminus C), \\quad A \\setminus (B \\cap C) = (A \\setminus B) \\cup (A \\setminus C)',
          explanation: 'Phép hiệu tập hợp với một giao trở thành hợp của hai hiệu và ngược lại.',
          block: true,
        },
        {
          id: 'form-1-1-2',
          label: 'Phép hiệu đối xứng (Symmetric Difference)',
          latex: 'A \\Delta B = (A \\setminus B) \\cup (B \\setminus A) = (A \\cup B) \\setminus (A \\cap B)',
          explanation: 'Tập hợp các phần tử thuộc đúng một trong hai tập $A$ hoặc $B$.',
          block: true,
        },
        {
          id: 'form-1-1-3',
          label: 'Lực lượng tích Descartes',
          latex: 'A \\times B = \\{(a, b) \\mid a \\in A, b \\in B\\}, \\quad |A \\times B| = |A| \\cdot |B|',
          explanation: 'Tích Descartes của hai tập hữu hạn có lực lượng bằng tích các lực lượng.',
          block: true,
        },
      ],
      examples: [allExamples[0]], // ex-1
      pitfalls: [allPitfalls[0]], // pit-1
    },
    {
      id: 'sec-1-2',
      title: '1.2 Quan hệ hai ngôi, Quan hệ tương đương và Tập thương',
      pageRange: 'Tr. 1–3',
      theoryContent:
        'Một quan hệ hai ngôi $\\mathcal{R}$ trên tập $X$ là một tập con của tích Descartes $X \\times X$. Ta viết $x \\mathcal{R} y$ thay cho $(x, y) \\in \\mathcal{R}$. Quan hệ tương đương là quan hệ thỏa mãn đồng thời ba tính chất: Phản xạ (Reflexive: $\\forall x \\in X, x \\mathcal{R} x$), Đối xứng (Symmetric: $x \\mathcal{R} y \\implies y \\mathcal{R} x$), và Bắc cầu (Transitive: $x \\mathcal{R} y \\land y \\mathcal{R} z \\implies x \\mathcal{R} z$). Quan hệ tương đương tạo nên một phân hoạch tự nhiên trên tập $X$ thông qua các lớp tương đương và tập thương.',
      formulas: [
        {
          id: 'form-1-2-1',
          label: 'Lớp tương đương (Equivalence Class)',
          latex: '[x] = \\{y \\in X \\mid y \\mathcal{R} x\\}',
          explanation: 'Hai lớp tương đương hoặc trùng nhau hoàn toàn $[x] = [y] \\iff x \\mathcal{R} y$, hoặc rời nhau hoàn toàn $[x] \\cap [y] = \\emptyset$.',
          block: true,
        },
        {
          id: 'form-1-2-2',
          label: 'Tập thương (Quotient Set)',
          latex: 'X/\\mathcal{R} = \\{[x] \\mid x \\in X\\}, \\quad \\bigcup_{[x] \\in X/\\mathcal{R}} [x] = X',
          explanation: 'Tập thương lập thành một phân hoạch của $X$: hợp của các lớp bằng $X$ và các lớp đôi một rời nhau.',
          block: true,
        },
      ],
      examples: [],
      pitfalls: [allPitfalls[2]], // pit-3
    },
    {
      id: 'sec-1-3',
      title: '1.3 Quan hệ thứ tự, Phần tử tối đại/tối tiểu vs Lớn nhất/nhỏ nhất',
      pageRange: 'Tr. 2–3',
      theoryContent:
        'Quan hệ thứ tự (ký hiệu $\\le$) là quan hệ hai ngôi thỏa mãn: Phản xạ, Phản đối xứng ($(x \\le y \\land y \\le x) \\implies x = y$), và Bắc cầu. Nếu mọi cặp phần tử đều so sánh được ($x \\le y$ hoặc $y \\le x$), thứ tự là toàn phần; nếu tồn tại cặp không so sánh được, thứ tự là bộ phận. Trong thứ tự bộ phận, cần phân biệt rạch ròi giữa phần tử tối đại (không có phần tử nào lớn hơn nó) và phần tử lớn nhất (lớn hơn tất cả mọi phần tử).',
      formulas: [
        {
          id: 'form-1-3-1',
          label: 'Phần tử tối đại vs Phần tử lớn nhất',
          latex: 'a \\text{ tối đại} \\iff (\\forall x, a \\le x \\implies x = a); \\quad M \\text{ lớn nhất} \\iff (\\forall x, x \\le M)',
          explanation: 'Phần tử lớn nhất nếu tồn tại thì luôn duy nhất. Tập có từ 2 phần tử tối đại thì chắc chắn không có phần tử lớn nhất.',
          block: true,
        },
        {
          id: 'form-1-3-2',
          label: 'Số quan hệ phản đối xứng trên tập n phần tử',
          latex: 'N_{\\text{antisym}} = 2^n \\cdot 3^{\\frac{n(n-1)}{2}}',
          explanation: 'Mỗi phần tử trên đường chéo có 2 khả năng, mỗi cặp ngoài chéo có 3 khả năng.',
          block: true,
        },
      ],
      examples: [allExamples[1], allExamples[2]], // ex-2, ex-3
      pitfalls: [allPitfalls[1]], // pit-2
    },
    {
      id: 'sec-1-4',
      title: '1.4 Phân loại ánh xạ và Lan truyền tính chất qua Ánh xạ hợp',
      pageRange: 'Tr. 3–5',
      theoryContent:
        'Cho ánh xạ $f: X \\to Y$. Ta phân loại $f$ thành Đơn ánh (Injective: $f(x_1) = f(x_2) \\implies x_1 = x_2$), Toàn ánh (Surjective: $\\forall y \\in Y, \\exists x \\in X: f(x) = y$), và Song ánh (Bijective: vừa đơn ánh vừa toàn ánh). Với ánh xạ hợp $g \\circ f: X \\to Z$ ($f: X \\to Y, g: Y \\to Z$), các tính chất lan truyền có định hướng: $g \\circ f$ đơn ánh bảo đảm $f$ đơn ánh; $g \\circ f$ toàn ánh bảo đảm $g$ toàn ánh. Khi $g \\circ f = \\text{Id}_X$, $g$ là nghịch đảo trái của $f$.',
      formulas: [
        {
          id: 'form-1-4-1',
          label: 'Quy luật lan truyền qua ánh xạ hợp',
          latex: 'g \\circ f \\text{ đơn ánh} \\implies f \\text{ đơn ánh}; \\quad g \\circ f \\text{ toàn ánh} \\implies g \\text{ toàn ánh}',
          explanation: 'Không thể suy ngược lại cho ánh xạ thành phần còn lại mà không có giả thiết bổ sung.',
          block: true,
        },
        {
          id: 'form-1-4-2',
          label: 'Số ánh xạ co nghịch đảo trái (Retraction Count)',
          latex: '|A| = m, |B| = n \\ (m \\le n), \\ f: A \\to B \\text{ đơn ánh} \\implies N_g = m^{n - m}',
          explanation: 'Số ánh xạ $g: B \\to A$ thỏa mãn $g \\circ f = \\text{Id}_A$ đúng bằng $m^{n-m}$.',
          block: true,
        },
      ],
      examples: [allExamples[3], allExamples[4]], // ex-4, ex-5
      pitfalls: [allPitfalls[3], allPitfalls[4], allPitfalls[5]], // pit-4, pit-5, pit-6
    },
    {
      id: 'sec-1-5',
      title: '1.5 Đối ngẫu giữa Ảnh thuận f(·) và Tạo ảnh ngược f⁻¹(·)',
      pageRange: 'Tr. 5–6',
      theoryContent:
        'Toán tử tạo ảnh ngược $f^{-1}: \\mathcal{P}(Y) \\to \\mathcal{P}(X)$ là một đồng cấu đại số Boole hoàn chỉnh, bảo toàn nguyên vẹn phép hợp, giao, hiệu và phần bù. Ngược lại, toán tử ảnh thuận $f: \\mathcal{P}(X) \\to \\mathcal{P}(Y)$ chỉ bảo toàn phép hợp; với phép giao và hiệu nói chung chỉ có quan hệ bao hàm. Đẳng thức cho ảnh thuận của giao và hiệu chỉ đạt được khi và chỉ khi $f$ là một đơn ánh.',
      formulas: [
        {
          id: 'form-1-5-1',
          label: 'Tính đồng cấu của Tạo ảnh ngược',
          latex: 'f^{-1}(C \\cap D) = f^{-1}(C) \\cap f^{-1}(D), \\quad f^{-1}(C \\setminus D) = f^{-1}(C) \\setminus f^{-1}(D)',
          explanation: 'Toán tử tạo ảnh ngược luôn bảo toàn giao và hiệu với mọi ánh xạ bất kỳ.',
          block: true,
        },
        {
          id: 'form-1-5-2',
          label: 'Điều kiện đẳng thức của Ảnh thuận',
          latex: 'f(A \\cap B) = f(A) \\cap f(B), \\forall A, B \\iff f \\text{ là đơn ánh}',
          explanation: 'Với ánh xạ tổng quát, chỉ có quan hệ bao hàm $f(A \\cap B) \\subset f(A) \\cap f(B)$.',
          block: true,
        },
      ],
      examples: [allExamples[5]], // ex-6
      pitfalls: [allPitfalls[6], allPitfalls[7]], // pit-7, pit-8
      masterTables: [dualityTable],
    },
    {
      id: 'sec-1-6',
      title: '1.6 Kỹ thuật đếm ánh xạ, Số Stirling loại hai và Nguyên lý Dirichlet',
      pageRange: 'Tr. 6–7',
      theoryContent:
        'Cho tập $|A| = m$ và $|B| = n$. Tổng số ánh xạ từ $A$ vào $B$ là $n^m$. Số đơn ánh ($m \\le n$) là chỉnh hợp $A_n^m = \\frac{n!}{(n-m)!}$. Số toàn ánh ($m \\ge n$) được tính thông qua nguyên lý bao hàm - loại trừ và liên hệ trực tiếp với số Stirling loại hai $S(m, n)$ (số cách phân hoạch $m$ phần tử phân biệt vào $n$ khối không rỗng). Khi $|A| = |B| = n$, đơn ánh, toàn ánh và song ánh là ba khái niệm tương đương.',
      formulas: [
        {
          id: 'form-1-6-1',
          label: 'Số toàn ánh và Số Stirling loại hai',
          latex: '|\\text{Surj}(A, B)| = \\sum_{k=0}^n (-1)^k \\binom{n}{k} (n - k)^m = n! \\, S(m, n)',
          explanation: 'Nguyên lý bù trừ loại bỏ các ánh xạ có ảnh thực tế không phủ kín miền đích.',
          block: true,
        },
        {
          id: 'form-1-6-2',
          label: 'Đếm ánh xạ có kích thước ảnh bằng k',
          latex: 'N_{|f(A)|=k} = \\binom{n}{k} |\\text{Surj}(A, B_k)| = \\binom{n}{k} k! \\, S(m, k)',
          explanation: 'Chọn $k$ phần tử ảnh từ $n$ phần tử, sau đó nhân với số toàn ánh từ $m$ phần tử vào $k$ phần tử.',
          block: true,
        },
      ],
      examples: [allExamples[6], allExamples[7]], // ex-7, ex-8
      pitfalls: [allPitfalls[8], allPitfalls[9]], // pit-9, pit-10
    },
  ],
};
