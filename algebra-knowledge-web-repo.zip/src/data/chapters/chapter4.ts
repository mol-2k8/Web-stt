import { Chapter } from '../../types/algebra';
import { allExamples } from '../examples';
import { allPitfalls } from '../pitfalls';

export const chapter4: Chapter = {
  id: 'ch4',
  number: 4,
  title: 'Ma trận, Định thức và Các biến đổi tuyến tính',
  description:
    'Lý thuyết ma trận toàn diện: phép toán ma trận, vết và phương trình giao hoán tử, cấu trúc định thức đa tuyến tính, ma trận phản xứng cấp lẻ, ma trận phụ hợp A*, đa thức ma trận, định lý Cayley - Hamilton, phân rã lũy linh, ma trận lũy đẳng và hệ thống 5 định lý cốt lõi về biến đổi sơ cấp.',
  badge: 'Trang 18–27',
  sections: [
    {
      id: 'sec-4-1',
      title: '4.1 Phép toán ma trận, Vết và Phương trình giao hoán tử AX - XA = B',
      pageRange: 'Tr. 18–20',
      theoryContent:
        'Phép nhân ma trận $A_{m \\times p} \\cdot B_{p \\times n} = C_{m \\times n}$ nói chung không có tính giao hoán ($AB \\neq BA$). Phép chuyển vị tích thỏa mãn quy tắc đảo chiều $(AB)^T = B^T A^T$. Vết của ma trận vuông $A \\in M_n(K)$ là tổng các phần tử trên đường chéo chính: $\\text{tr}(A) = \\sum_{i=1}^n a_{ii}$. Vết có tính tuyến tính $\\text{tr}(A + B) = \\text{tr}(A) + \\text{tr}(B)$, $\\text{tr}(kA) = k\\text{tr}(A)$, và đặc biệt có tính hoán vị vòng quanh: $\\text{tr}(AB) = \\text{tr}(BA)$. Do đó $\\text{tr}(AX - XA) = 0$, dẫn đến định lý không tồn tại nghiệm của phương trình giao hoán tử $AX - XA = I_n$.',
      formulas: [
        {
          id: 'form-4-1-1',
          label: 'Tính chất hoán vị vòng quanh của Vết (Trace Cycle Property)',
          latex: '\\text{tr}(AB) = \\text{tr}(BA) \\implies \\text{tr}(AX - XA) = 0, \\quad \\forall A, X \\in M_n(K)',
          explanation: 'Vết của giao hoán tử luôn bằng 0, không phụ thuộc vào kích thước hay trường số.',
          block: true,
        },
        {
          id: 'form-4-1-2',
          label: 'Định lý không tồn tại nghiệm của phương trình commutator',
          latex: 'AX - XA = I_n \\quad \\text{không bao giờ có nghiệm trong } M_n(\\mathbb{R}) \\text{ hoặc } M_n(\\mathbb{C})',
          explanation: 'Vì $\\text{tr}(AX - XA) = 0$ trong khi $\\text{tr}(I_n) = n > 0$.',
          block: true,
        },
      ],
      examples: [allExamples[20], allExamples[21]], // ex-21, ex-22
      pitfalls: [allPitfalls[27], allPitfalls[28]], // pit-28, pit-29
    },
    {
      id: 'sec-4-2',
      title: '4.2 Cấu trúc Định thức, Tính chất đa tuyến tính và Ma trận phản xứng cấp lẻ',
      pageRange: 'Tr. 20–21',
      theoryContent:
        'Định thức $\\det: M_n(K) \\to K$ là hàm đa tuyến tính thay phiên duy nhất thỏa mãn $\\det(I_n) = 1$. Định thức bảo toàn phép nhân $\\det(AB) = \\det(A)\\det(B)$, bảo toàn chuyển vị $\\det(A^T) = \\det(A)$, nhưng không bảo toàn phép cộng $\\det(A + B) \\neq \\det(A) + \\det(B)$. Khi nhân ma trận với vô hướng $k$, ta có $\\det(kA) = k^n \\det(A)$. Ma trận vuông $A$ được gọi là phản xứng nếu $A^T = -A$. Định thức của ma trận phản xứng cấp lẻ luôn bằng 0.',
      formulas: [
        {
          id: 'form-4-2-1',
          label: 'Định thức ma trận phản xứng cấp lẻ',
          latex: 'A^T = -A \\implies \\det(A) = \\det(A^T) = \\det(-A) = (-1)^n \\det(A) \\implies \\det(A) = 0 \\quad (\\text{khi } n \\text{ lẻ})',
          explanation: 'Mọi ma trận phản xứng cấp lẻ đều suy biến (hạng nhỏ hơn cấp).',
          block: true,
        },
        {
          id: 'form-4-2-2',
          label: 'Định thức nhân số vô hướng',
          latex: '\\det(kA) = k^n \\det(A), \\quad \\det(AB) = \\det(A)\\det(B), \\quad \\det(A^{-1}) = \\frac{1}{\\det(A)}',
          explanation: 'Tính đa tuyến tính trên toàn bộ $n$ hàng độc lập của ma trận vuông.',
          block: true,
        },
      ],
      examples: [allExamples[22]], // ex-23
      pitfalls: [allPitfalls[29], allPitfalls[30]], // pit-30, pit-31
    },
    {
      id: 'sec-4-3',
      title: '4.3 Ma trận Phụ hợp A*, Công thức nghịch đảo và Quy luật gián đoạn về hạng',
      pageRange: 'Tr. 21–22',
      theoryContent:
        'Ma trận phụ hợp (Adjugate Matrix) $A^*$ của ma trận vuông $A = [a_{ij}]$ cấp $n$ là chuyển vị của ma trận các phần bù đại số: $A^* = [C_{ij}]^T$, trong đó $C_{ij} = (-1)^{i+j} M_{ij}$. Hệ thức nền tảng: $A \\cdot A^* = A^* \\cdot A = \\det(A) I_n$. Khi $\\det(A) \\neq 0$, ma trận nghịch đảo là $A^{-1} = \\frac{1}{\\det(A)} A^*$. Định thức của ma trận phụ hợp thỏa mãn $\\det(A^*) = (\\det A)^{n-1}$. Đặc biệt, hạng của ma trận phụ hợp $\\text{rank}(A^*)$ tuân theo quy luật gián đoạn bước nhảy phụ thuộc vào hạng của $A$.',
      formulas: [
        {
          id: 'form-4-3-1',
          label: 'Đồng nhất thức ma trận phụ hợp và Định thức',
          latex: 'A \\cdot A^* = \\det(A) I_n, \\quad \\det(A^*) = [\\det(A)]^{n-1}, \\quad (kA)^* = k^{n-1} A^*',
          explanation: 'Mỗi phần tử của $A^*$ là định thức con cấp $n-1$, do đó mang số mũ $n-1$.',
          block: true,
        },
        {
          id: 'form-4-3-2',
          label: 'Quy luật gián đoạn về hạng của ma trận phụ hợp',
          latex: '\\text{rank}(A^*) = \\begin{cases} n & \\text{khi } \\text{rank}(A) = n \\\\ 1 & \\text{khi } \\text{rank}(A) = n - 1 \\\\ 0 & \\text{khi } \\text{rank}(A) \\le n - 2 \\end{cases}',
          explanation: 'Khi $\\det(A) = 0$, ma trận phụ hợp $A^*$ vẫn khác ma trận không nếu $\\text{rank}(A) = n - 1$.',
          block: true,
        },
      ],
      examples: [allExamples[23]], // ex-24
      pitfalls: [allPitfalls[31], allPitfalls[32], allPitfalls[33]], // pit-32, pit-33, pit-34
    },
    {
      id: 'sec-4-4',
      title: '4.4 Đa thức ma trận, Định lý Cayley - Hamilton, Phân rã lũy linh và Lũy đẳng',
      pageRange: 'Tr. 22–24',
      theoryContent:
        'Với đa thức $f(x) = a_m x^m + \\dots + a_0$, đa thức ma trận tương ứng là $f(A) = a_m A^m + \\dots + a_1 A + a_0 I_n$ (bắt buộc nhân $a_0 I_n$). Định lý Cayley - Hamilton khẳng định mọi ma trận vuông đều là nghiệm của phương trình đặc trưng của chính nó: với cấp 2 là $A^2 - \\text{tr}(A) A + \\det(A) I_2 = O$. Kỹ thuật phân rã lũy linh $A = \\lambda I_n + N$ với $N^p = O$ cho phép tính lũy thừa bậc cao $A^m$ qua nhị thức Newton cắt ngắn. Ma trận lũy đẳng ($A^2 = A$) có lũy thừa ổn định $A^m = A, \\forall m \\ge 1$ và công thức nghịch đảo giải tích $(I_n - cA)^{-1} = I_n + \\frac{c}{1-c} A$.',
      formulas: [
        {
          id: 'form-4-4-1',
          label: 'Định lý Cayley - Hamilton cấp 2',
          latex: 'A^2 - \\text{tr}(A) A + \\det(A) I_2 = O \\implies A^2 = \\text{tr}(A) A - \\det(A) I_2',
          explanation: 'Quy đổi bậc hai của ma trận về bậc nhất và ma trận đơn vị.',
          block: true,
        },
        {
          id: 'form-4-4-2',
          label: 'Phân rã lũy linh và Ma trận lũy đẳng',
          latex: 'A = \\lambda I_n + N \\ (N^p = O) \\implies A^m = \\sum_{k=0}^{p-1} \\binom{m}{k} \\lambda^{m-k} N^k; \\quad A^2 = A \\implies (I_n - cA)^{-1} = I_n + \\frac{c}{1-c} A',
          explanation: 'Nhị thức Newton cắt ngắn tại $p$ và công thức nghịch đảo ma trận chiếu.',
          block: true,
        },
      ],
      examples: [allExamples[24], allExamples[25]], // ex-25, ex-26
      pitfalls: [allPitfalls[34], allPitfalls[35]], // pit-35, pit-36
    },
    {
      id: 'sec-4-5',
      title: '4.5 Hệ thống 5 Định lý cốt lõi về Biến đổi sơ cấp và Thuật toán Gauss - Jordan',
      pageRange: 'Tr. 24–27',
      theoryContent:
        'Ba loại biến đổi sơ cấp trên dòng: (1) Hoán vị hai dòng $h_i \\leftrightarrow h_j$; (2) Nhân dòng với số khác không $k \\cdot h_i \\to h_i$; (3) Cộng bội dòng khác vào dòng $h_i + c \\cdot h_j \\to h_i$. Bản chất đại số: biến đổi hàng tương đương nhân trái ma trận sơ cấp $E \\cdot A$; biến đổi cột tương đương nhân phải $A \\cdot E$. Mọi ma trận đều đưa được về dạng bậc thang (REF) và bậc thang rút gọn duy nhất (RREF). Hệ thống 5 định lý cốt lõi xác lập: Định lý 1 (Bất biến của hạng ma trận: $A \\sim B \\implies \\text{rank}(A) = \\text{rank}(B)$); Định lý 2 (Dạng bậc thang tương đương); Định lý 3 (Phân tích ma trận khả nghịch thành tích ma trận sơ cấp $A = E_1 \\dots E_k$); Định lý 4 (Thuật toán Gauss - Jordan tìm ma trận nghịch đảo $[A \\mid I_n] \\to [I_n \\mid A^{-1}]$); Định lý 5 (Tính định thức bằng khử Gauss: $\\det(A) = (-1)^s \\prod t_{ii}$).',
      formulas: [
        {
          id: 'form-4-5-1',
          label: 'Tính định thức bằng khử Gauss (Định lý 5)',
          latex: '\\det(A) = (-1)^s \\prod_{i=1}^n t_{ii}',
          explanation: 'Trong đó $s$ là tổng số lần thực hiện phép đổi chỗ hai hàng, và $t_{ii}$ là các phần tử trên đường chéo của ma trận tam giác trên REF.',
          block: true,
        },
        {
          id: 'form-4-5-2',
          label: 'Thuật toán nghịch đảo Gauss - Jordan (Định lý 4)',
          latex: '[A \\mid I_n] \\xrightarrow{\\text{biến đổi hàng}} [I_n \\mid A^{-1}]',
          explanation: 'Nếu trong quá trình biến đổi xuất hiện hàng toàn số 0 ở khối bên trái, ma trận $A$ suy biến và không khả nghịch.',
          block: true,
        },
      ],
      examples: [allExamples[26]], // ex-27
      pitfalls: [allPitfalls[36], allPitfalls[37], allPitfalls[38]], // pit-37, pit-38, pit-39
    },
  ],
};
