import { Chapter, SearchItem } from '../types/algebra';
import { chapter1 } from './chapters/chapter1';
import { chapter2 } from './chapters/chapter2';
import { chapter3 } from './chapters/chapter3';
import { chapter4 } from './chapters/chapter4';
import { chapter5 } from './chapters/chapter5';
import { chapter6 } from './chapters/chapter6';
import { chapter7 } from './chapters/chapter7';

export { allExamples } from './examples';
export { allPitfalls } from './pitfalls';
export { masterTables } from './masterTables';

export const initialChapters: Chapter[] = [
  chapter1,
  chapter2,
  chapter3,
  chapter4,
  chapter5,
  chapter6,
  chapter7,
];

/**
 * Safely trims text for search snippet without cutting LaTeX math delimiters in half.
 */
function cleanSnippet(text: string, maxLength: number = 150): string {
  if (text.length <= maxLength) return text;
  let snippet = text.slice(0, maxLength);
  const mathDelimCount = (snippet.match(/\$/g) || []).length;
  if (mathDelimCount % 2 !== 0) {
    const nextDollar = text.indexOf('$', maxLength);
    if (nextDollar !== -1 && nextDollar - maxLength < 35) {
      snippet = text.slice(0, nextDollar + 1);
    } else {
      const lastDollar = snippet.lastIndexOf('$');
      if (lastDollar > 0) {
        snippet = snippet.slice(0, lastDollar);
      }
    }
  }
  return snippet.trim() + '...';
}

/**
 * Generate flat list of SearchItem for instant fuzzy search across all chapters,
 * sections, formulas, examples, pitfalls, and master comparison tables.
 */
export function buildSearchIndex(chapters: Chapter[]): SearchItem[] {
  const items: SearchItem[] = [];

  for (const ch of chapters) {
    items.push({
      id: `search-ch-${ch.id}`,
      title: `Chương ${ch.number}: ${ch.title}`,
      category: 'Chương',
      chapterId: ch.id,
      snippet: ch.description,
      targetId: ch.id,
    });

    for (const sec of ch.sections) {
      items.push({
        id: `search-sec-${sec.id}`,
        title: sec.title,
        category: 'Mục',
        chapterId: ch.id,
        sectionId: sec.id,
        snippet: cleanSnippet(sec.theoryContent, 140),
        targetId: sec.id,
      });

      for (const ex of sec.examples) {
        items.push({
          id: `search-ex-${ex.id}`,
          title: `Ví dụ: ${ex.title}`,
          category: 'Ví dụ',
          chapterId: ch.id,
          sectionId: sec.id,
          snippet: cleanSnippet(ex.problem, 150),
          targetId: ex.id,
        });
      }

      for (const pit of sec.pitfalls) {
        items.push({
          id: `search-pit-${pit.id}`,
          title: `Bẫy: ${pit.name}`,
          category: 'Bẫy ngộ nhận',
          chapterId: ch.id,
          sectionId: sec.id,
          snippet: cleanSnippet(pit.fallacy, 150),
          targetId: pit.id,
        });
      }

      if (sec.masterTables) {
        for (const tbl of sec.masterTables) {
          items.push({
            id: `search-tbl-${tbl.id}`,
            title: `Bảng: ${tbl.title}`,
            category: 'Bảng tổng hợp',
            chapterId: ch.id,
            sectionId: sec.id,
            snippet: tbl.description || tbl.title,
            targetId: tbl.id,
          });
        }
      }
    }
  }

  return items;
}
