import React, { useState, useEffect, useMemo, useCallback } from 'react';
import { initialChapters, buildSearchIndex } from './data/chaptersData';
import { TopicFilter, SearchItem } from './types/algebra';
import Header from './components/layout/Header';
import Sidebar from './components/layout/Sidebar';
import RightTOC from './components/layout/RightTOC';
import ExampleCard from './components/content/ExampleCard';
import PitfallCallout from './components/content/PitfallCallout';
import MasterTable from './components/content/MasterTable';
import SearchModal from './components/search/SearchModal';
import MathRenderer from './components/math/MathRenderer';
import { BookOpen, Lightbulb, AlertTriangle } from 'lucide-react';

export const App: React.FC = () => {
  const [chapters] = useState(initialChapters);
  const [activeChapterId, setActiveChapterId] = useState('ch1');
  const [activeSectionId, setActiveSectionId] = useState('sec-1-1');
  const [filter, setFilter] = useState<TopicFilter>('all');
  const [isSidebarOpen, setIsSidebarOpen] = useState(false);
  const [isSearchOpen, setIsSearchOpen] = useState(false);

  // Active Chapter Object
  const currentChapter = useMemo(() => {
    return chapters.find((c) => c.id === activeChapterId) || chapters[0];
  }, [chapters, activeChapterId]);

  // Search items index
  const searchIndex = useMemo(() => {
    return buildSearchIndex(chapters);
  }, [chapters]);

  // Keyboard shortcut Ctrl+K / Cmd+K listener
  useEffect(() => {
    const handleKeyDown = (e: KeyboardEvent) => {
      if ((e.ctrlKey || e.metaKey) && e.key.toLowerCase() === 'k') {
        e.preventDefault();
        setIsSearchOpen((prev) => !prev);
      }
    };

    window.addEventListener('keydown', handleKeyDown);
    return () => window.removeEventListener('keydown', handleKeyDown);
  }, []);

  // Smooth scroll helper
  const scrollToElement = useCallback((elementId: string) => {
    const el = document.getElementById(elementId);
    if (el) {
      el.scrollIntoView({ behavior: 'smooth', block: 'start' });
      // Update section highlight
      setActiveSectionId(elementId);
    }
  }, []);

  // Handle select chapter
  const handleSelectChapter = useCallback((chapterId: string) => {
    setActiveChapterId(chapterId);
    const targetChapter = chapters.find((c) => c.id === chapterId);
    if (targetChapter && targetChapter.sections.length > 0) {
      setActiveSectionId(targetChapter.sections[0].id);
    }
    window.scrollTo({ top: 0, behavior: 'smooth' });
  }, [chapters]);

  // Handle select section
  const handleSelectSection = useCallback((sectionId: string) => {
    setActiveSectionId(sectionId);
    scrollToElement(sectionId);
  }, [scrollToElement]);

  // Handle search item selection
  const handleSelectSearchItem = useCallback((item: SearchItem) => {
    setActiveChapterId(item.chapterId);
    if (item.sectionId) {
      setActiveSectionId(item.sectionId);
    }
    setTimeout(() => {
      if (item.targetId) {
        scrollToElement(item.targetId);
      }
    }, 150);
  }, [scrollToElement]);

  return (
    <div className="min-h-screen bg-slate-50 text-slate-800 flex flex-col font-sans">
      {/* Top Header */}
      <Header
        currentChapter={currentChapter}
        onOpenSearch={() => setIsSearchOpen(true)}
        onToggleSidebar={() => setIsSidebarOpen((prev) => !prev)}
        isSidebarOpen={isSidebarOpen}
      />

      {/* Main 3-Column Layout */}
      <div className="flex-1 max-w-7xl w-full mx-auto flex">
        {/* Left Column: Sidebar Navigation */}
        <Sidebar
          chapters={chapters}
          activeChapterId={activeChapterId}
          activeSectionId={activeSectionId}
          onSelectChapter={handleSelectChapter}
          onSelectSection={handleSelectSection}
          isOpen={isSidebarOpen}
          onClose={() => setIsSidebarOpen(false)}
          filter={filter}
          onChangeFilter={setFilter}
        />

        {/* Center Column: Main Content Stream */}
        <div
          className="flex-1 min-w-0 py-6 px-4 sm:px-8 lg:px-10 overflow-y-auto"
        >
          {/* Chapter Banner */}
          <div className="mb-8 rounded-2xl bg-gradient-to-br from-indigo-900 via-indigo-800 to-slate-900 p-6 sm:p-8 text-white shadow-md">
            <div className="flex items-center gap-2 text-indigo-300 text-xs font-semibold uppercase tracking-wider mb-2">
              <BookOpen className="w-4 h-4" />
              <span>Chương {currentChapter.number}</span>
            </div>
            <h2 className="text-xl sm:text-2xl lg:text-3xl font-extrabold tracking-tight mb-3">
              {currentChapter.title}
            </h2>
            <p className="text-sm sm:text-base text-indigo-100/90 leading-relaxed max-w-3xl">
              {currentChapter.description}
            </p>
          </div>

          {/* Sections Content */}
          <div className="space-y-12">
            {currentChapter.sections.map((section) => (
              <section
                key={section.id}
                id={section.id}
                className="scroll-mt-20 border-b border-slate-200/80 pb-10 last:border-b-0"
              >
                {/* Section Header */}
                <div className="flex items-baseline justify-between gap-3 mb-4">
                  <h3 className="text-lg sm:text-xl font-bold text-slate-900 tracking-tight flex items-center gap-2">
                    <span className="h-2 w-2 rounded-full bg-indigo-600 inline-block"></span>
                    <span>{section.title}</span>
                  </h3>
                  <span className="shrink-0 rounded-md bg-slate-100 px-2 py-0.5 text-xs font-mono text-slate-500">
                    {section.pageRange}
                  </span>
                </div>

                {/* Section Theory Content */}
                {(filter === 'all' || filter === 'theory') && (
                  <div className="space-y-4 mb-6">
                    <div className="text-slate-700 text-sm sm:text-base leading-relaxed bg-white p-5 rounded-xl border border-slate-200/70 shadow-2xs">
                      <MathRenderer>{section.theoryContent}</MathRenderer>
                    </div>

                    {/* Section Formulas */}
                    {section.formulas.map((form) => (
                      <div
                        key={form.id}
                        className="my-3 rounded-xl border border-indigo-100 bg-indigo-50/40 p-4 text-center overflow-x-auto"
                      >
                        {form.label && (
                          <div className="text-xs font-semibold text-indigo-700 mb-1">
                            {form.label}
                          </div>
                        )}
                        <MathRenderer math={form.latex} block={form.block ?? true} />
                        {form.explanation && (
                          <div className="mt-1 text-xs text-slate-600">
                            <MathRenderer>{form.explanation}</MathRenderer>
                          </div>
                        )}
                      </div>
                    ))}
                  </div>
                )}

                {/* Master Comparative Tables */}
                {(filter === 'all' || filter === 'theory') && section.masterTables && (
                  <div className="my-6">
                    {section.masterTables.map((tbl) => (
                      <MasterTable key={tbl.id} table={tbl} />
                    ))}
                  </div>
                )}

                {/* Worked Examples */}
                {(filter === 'all' || filter === 'example') && section.examples.length > 0 && (
                  <div className="my-6">
                    <div className="flex items-center gap-2 text-xs font-bold uppercase tracking-wider text-slate-500 mb-3">
                      <Lightbulb className="w-4 h-4 text-indigo-500" />
                      <span>Ví dụ thực hành chi tiết ({section.examples.length})</span>
                    </div>
                    {section.examples.map((ex) => (
                      <ExampleCard key={ex.id} example={ex} />
                    ))}
                  </div>
                )}

                {/* Cognitive Traps & Pitfalls */}
                {(filter === 'all' || filter === 'pitfall') && section.pitfalls.length > 0 && (
                  <div className="my-6">
                    <div className="flex items-center gap-2 text-xs font-bold uppercase tracking-wider text-amber-700 mb-3">
                      <AlertTriangle className="w-4 h-4 text-amber-600" />
                      <span>Cảnh báo bẫy ngộ nhận &amp; Phản ví dụ ({section.pitfalls.length})</span>
                    </div>
                    {section.pitfalls.map((pit) => (
                      <PitfallCallout key={pit.id} pitfall={pit} />
                    ))}
                  </div>
                )}
              </section>
            ))}
          </div>
        </div>

        {/* Right Column: In-page TOC */}
        <RightTOC
          chapter={currentChapter}
          activeSectionId={activeSectionId}
          onScrollToElement={scrollToElement}
        />
      </div>

      {/* Instant Fuzzy Search Modal */}
      <SearchModal
        isOpen={isSearchOpen}
        onClose={() => setIsSearchOpen(false)}
        items={searchIndex}
        onSelectItem={handleSelectSearchItem}
      />
    </div>
  );
};

export default App;
