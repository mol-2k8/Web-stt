import React from 'react';
import { Chapter } from '../../types/algebra';
import { ListTree, BookOpen, AlertTriangle, Lightbulb, Table } from 'lucide-react';

interface RightTOCProps {
  chapter: Chapter;
  activeSectionId: string;
  onScrollToElement: (elementId: string) => void;
}

export const RightTOC: React.FC<RightTOCProps> = ({
  chapter,
  activeSectionId,
  onScrollToElement,
}) => {
  return (
    <nav aria-label="Mục lục trang" className="hidden xl:block w-64 shrink-0 py-6 px-4 sticky top-16 h-[calc(100vh-4rem)] overflow-y-auto">
      <div className="flex items-center gap-2 text-xs font-bold text-slate-800 uppercase tracking-wider mb-4 pb-2 border-b border-slate-200">
        <ListTree className="w-4 h-4 text-indigo-600" />
        <span>Mục Lục Trang Hiện Tại</span>
      </div>

      <div className="space-y-4 text-xs">
        {chapter.sections.map((section) => {
          const isCurrentSection = section.id === activeSectionId;
          return (
            <div key={section.id} className="space-y-1.5">
              <button
                type="button"
                onClick={() => onScrollToElement(section.id)}
                className={`w-full text-left font-medium flex items-start gap-1.5 py-1 px-2 rounded-md transition-colors ${
                  isCurrentSection
                    ? 'bg-indigo-50 text-indigo-900 font-semibold'
                    : 'text-slate-600 hover:text-slate-900 hover:bg-slate-100'
                }`}
              >
                <BookOpen className="w-3.5 h-3.5 text-indigo-500 shrink-0 mt-0.5" />
                <span className="truncate">{section.title}</span>
              </button>

              {/* Sub-items for this section */}
              <div className="pl-5 space-y-1 text-slate-500 text-[11px]">
                {section.examples.map((ex) => (
                  <button
                    key={ex.id}
                    type="button"
                    onClick={() => onScrollToElement(ex.id)}
                    className="w-full text-left flex items-center gap-1.5 py-0.5 hover:text-indigo-600 truncate"
                  >
                    <Lightbulb className="w-3 h-3 text-indigo-400 shrink-0" />
                    <span className="truncate">{ex.title}</span>
                  </button>
                ))}

                {section.pitfalls.map((pit) => (
                  <button
                    key={pit.id}
                    type="button"
                    onClick={() => onScrollToElement(pit.id)}
                    className="w-full text-left flex items-center gap-1.5 py-0.5 hover:text-amber-600 truncate"
                  >
                    <AlertTriangle className="w-3 h-3 text-amber-500 shrink-0" />
                    <span className="truncate">{pit.name}</span>
                  </button>
                ))}

                {section.masterTables?.map((tbl) => (
                  <button
                    key={tbl.id}
                    type="button"
                    onClick={() => onScrollToElement(tbl.id)}
                    className="w-full text-left flex items-center gap-1.5 py-0.5 hover:text-purple-600 truncate"
                  >
                    <Table className="w-3 h-3 text-purple-500 shrink-0" />
                    <span className="truncate">{tbl.title}</span>
                  </button>
                ))}
              </div>
            </div>
          );
        })}
      </div>
    </nav>
  );
};

export default RightTOC;
