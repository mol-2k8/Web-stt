import React, { useState, useEffect } from 'react';
import { Chapter } from '../../types/algebra';
import { Menu, Search, BookMarked, GraduationCap } from 'lucide-react';

interface HeaderProps {
  currentChapter: Chapter;
  onOpenSearch: () => void;
  onToggleSidebar: () => void;
  isSidebarOpen: boolean;
}

export const Header: React.FC<HeaderProps> = ({
  currentChapter,
  onOpenSearch,
  onToggleSidebar,
}) => {
  const [scrollProgress, setScrollProgress] = useState(0);

  useEffect(() => {
    const handleScroll = () => {
      const totalHeight = document.documentElement.scrollHeight - window.innerHeight;
      if (totalHeight > 0) {
        const progress = Math.min(100, Math.max(0, (window.scrollY / totalHeight) * 100));
        setScrollProgress(progress);
      }
    };

    window.addEventListener('scroll', handleScroll, { passive: true });
    handleScroll();
    return () => window.removeEventListener('scroll', handleScroll);
  }, []);

  return (
    <header className="sticky top-0 z-40 w-full border-b border-slate-200/90 bg-white/95 backdrop-blur-md transition-shadow">
      <div className="flex h-16 items-center justify-between px-4 sm:px-6 lg:px-8 max-w-7xl mx-auto">
        {/* Left: Mobile Toggle & Brand Title */}
        <div className="flex items-center gap-3 sm:gap-4 min-w-0">
          <button
            type="button"
            aria-label="menu sidebar toggle"
            data-testid="sidebar-toggle"
            onClick={onToggleSidebar}
            className="lg:hidden flex h-10 w-10 items-center justify-center rounded-lg border border-slate-200 text-slate-600 hover:bg-slate-100 transition-colors"
          >
            <Menu className="w-5 h-5" />
          </button>

          <div className="flex items-center gap-2.5 min-w-0">
            <div className="flex h-9 w-9 shrink-0 items-center justify-center rounded-xl bg-indigo-600 text-white shadow-md shadow-indigo-200">
              <GraduationCap className="w-5 h-5" />
            </div>
            <div className="min-w-0">
              <h1 className="text-sm sm:text-base font-bold text-slate-900 truncate tracking-tight">
                Chuyên Khảo Đại Số Đại Cương và Tuyến Tính
              </h1>
              <div className="flex items-center gap-2 text-xs text-slate-500">
                <span className="inline-flex items-center gap-1 font-medium text-indigo-700">
                  <BookMarked className="w-3 h-3" />
                  Chương {currentChapter.number}
                </span>
                <span className="hidden md:inline text-slate-300">•</span>
                <span className="hidden md:inline truncate font-normal text-slate-600">
                  {currentChapter.title}
                </span>
              </div>
            </div>
          </div>
        </div>

        {/* Right: Search trigger button */}
        <div className="flex items-center gap-2 sm:gap-3">
          <button
            type="button"
            onClick={onOpenSearch}
            aria-label="search search trigger"
            className="flex items-center gap-2 rounded-xl border border-slate-200 bg-slate-50 px-3.5 py-2 text-xs sm:text-sm text-slate-500 hover:border-indigo-300 hover:bg-white hover:text-indigo-600 transition-all shadow-2xs"
          >
            <Search className="w-4 h-4 text-slate-400 group-hover:text-indigo-500" />
            <span className="hidden sm:inline font-medium">Tìm kiếm tri thức</span>
            <span className="sm:hidden font-medium">Tìm kiếm</span>
            <kbd className="hidden sm:inline-block rounded bg-white px-1.5 py-0.5 text-[10px] font-semibold text-slate-400 border border-slate-200 shadow-2xs">
              Ctrl+K
            </kbd>
          </button>
        </div>
      </div>

      {/* Reading Progress Indicator Bar */}
      <div className="h-[2px] w-full bg-slate-100 overflow-hidden">
        <div
          role="progressbar"
          aria-valuenow={Math.round(scrollProgress)}
          aria-valuemin={0}
          aria-valuemax={100}
          data-testid="reading-progress"
          className="reading-progress h-full bg-gradient-to-r from-indigo-500 via-indigo-600 to-indigo-700 transition-[width] duration-150 ease-out"
          style={{ width: `${scrollProgress}%` }}
        />
      </div>
    </header>
  );
};

export default Header;
