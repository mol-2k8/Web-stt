import React from 'react';
import { Chapter, TopicFilter } from '../../types/algebra';
import {
  Layers,
  FileText,
  AlertTriangle,
  Lightbulb,
  X,
  ChevronRight,
  Bookmark,
} from 'lucide-react';

interface SidebarProps {
  chapters: Chapter[];
  activeChapterId: string;
  activeSectionId: string;
  onSelectChapter: (chapterId: string) => void;
  onSelectSection: (sectionId: string) => void;
  isOpen: boolean;
  onClose: () => void;
  filter: TopicFilter;
  onChangeFilter: (filter: TopicFilter) => void;
}

export const Sidebar: React.FC<SidebarProps> = ({
  chapters,
  activeChapterId,
  activeSectionId,
  onSelectChapter,
  onSelectSection,
  isOpen,
  onClose,
  filter,
  onChangeFilter,
}) => {
  const filterOptions: { id: TopicFilter; label: string; icon: React.ReactNode }[] = [
    { id: 'all', label: 'Tất cả', icon: <Layers className="w-3.5 h-3.5" /> },
    { id: 'theory', label: 'Lý thuyết', icon: <FileText className="w-3.5 h-3.5" /> },
    { id: 'pitfall', label: 'Bẫy ngộ nhận', icon: <AlertTriangle className="w-3.5 h-3.5" /> },
    { id: 'example', label: 'Ví dụ thực hành', icon: <Lightbulb className="w-3.5 h-3.5" /> },
  ];

  return (
    <>
      {/* Mobile Backdrop */}
      {isOpen && (
        <div
          className="fixed inset-0 z-40 bg-slate-900/50 backdrop-blur-xs lg:hidden transition-opacity"
          onClick={onClose}
        />
      )}

      {/* Sidebar Container */}
      <aside
        role="navigation"
        data-testid="sidebar"
        className={`fixed top-0 bottom-0 left-0 z-50 w-72 sm:w-80 bg-white border-r border-slate-200 flex flex-col transition-transform duration-300 ease-in-out lg:static lg:translate-x-0 lg:z-0 lg:h-[calc(100vh-4rem)] lg:sticky lg:top-16 ${
          isOpen ? 'translate-x-0 shadow-2xl visible' : '-translate-x-full invisible lg:visible pointer-events-none lg:pointer-events-auto'
        }`}
      >
        {/* Sidebar Header (Mobile close bar) */}
        <div className="flex h-16 items-center justify-between px-4 border-b border-slate-200 lg:hidden">
          <div className="flex items-center gap-2 font-bold text-slate-800 text-sm">
            <Bookmark className="w-4 h-4 text-indigo-600" />
            <span>Mục lục chuyên khảo</span>
          </div>
          <button
            type="button"
            aria-label="close sidebar"
            data-testid="sidebar-close"
            onClick={onClose}
            className="flex h-9 w-9 items-center justify-center rounded-lg border border-slate-200 text-slate-500 hover:bg-slate-100 transition-colors"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Topic Filter Pills */}
        <div className="p-4 border-b border-slate-100 bg-slate-50/70">
          <div className="text-[11px] font-semibold text-slate-400 uppercase tracking-wider mb-2">
            Lọc chế độ hiển thị
          </div>
          <div className="grid grid-cols-2 gap-1.5">
            {filterOptions.map((opt) => {
              const active = filter === opt.id;
              return (
                <button
                  key={opt.id}
                  type="button"
                  onClick={() => onChangeFilter(opt.id)}
                  className={`flex items-center gap-1.5 px-2.5 py-1.5 rounded-lg text-xs font-medium transition-all ${
                    active
                      ? 'bg-indigo-600 text-white shadow-2xs font-semibold'
                      : 'bg-white text-slate-600 border border-slate-200 hover:border-slate-300 hover:bg-slate-50'
                  }`}
                >
                  {opt.icon}
                  <span className="truncate">{opt.label}</span>
                </button>
              );
            })}
          </div>
        </div>

        {/* 7-Chapter Navigation List */}
        <nav className="flex-1 overflow-y-auto p-3 space-y-1.5">
          <div className="text-[11px] font-semibold text-slate-400 uppercase tracking-wider px-2 py-1">
            7 Chương Chuyên Đề (68 Mục)
          </div>

          {chapters.map((chapter) => {
            const isChapterActive = chapter.id === activeChapterId;
            return (
              <div key={chapter.id} className="rounded-xl overflow-hidden">
                <button
                  type="button"
                  role="tab"
                  aria-selected={isChapterActive}
                  data-testid={`chapter-nav-${chapter.id}`}
                  onClick={() => {
                    onSelectChapter(chapter.id);
                    if (window.innerWidth < 1024) {
                      // On mobile, close drawer when selecting chapter
                      onClose();
                    }
                  }}
                  className={`w-full flex items-start gap-2.5 px-3 py-2.5 rounded-xl text-left text-xs sm:text-sm font-medium transition-all ${
                    isChapterActive
                      ? 'bg-indigo-50/90 text-indigo-900 border border-indigo-200/80 shadow-2xs'
                      : 'text-slate-700 hover:bg-slate-100/80 hover:text-slate-900 border border-transparent'
                  }`}
                >
                  <span
                    className={`flex h-5 w-5 shrink-0 items-center justify-center rounded-md text-[11px] font-bold mt-0.5 ${
                      isChapterActive
                        ? 'bg-indigo-600 text-white'
                        : 'bg-slate-200 text-slate-700'
                    }`}
                  >
                    {chapter.number}
                  </span>
                  <div className="flex-1 min-w-0">
                    <div className="flex items-center justify-between">
                      <span className="truncate font-semibold">{chapter.title}</span>
                      <ChevronRight
                        className={`w-3.5 h-3.5 text-slate-400 transition-transform ${
                          isChapterActive ? 'rotate-90 text-indigo-600' : ''
                        }`}
                      />
                    </div>
                    <span className="text-[11px] text-slate-500 line-clamp-1">
                      {chapter.sections.length} chuyên đề
                    </span>
                  </div>
                </button>

                {/* Subsections list when active */}
                {isChapterActive && (
                  <div className="ml-5 my-1 pl-3 border-l-2 border-indigo-200 space-y-1 py-1">
                    {chapter.sections.map((sec) => {
                      const isSecActive = sec.id === activeSectionId;
                      return (
                        <div
                          key={sec.id}
                          role="button"
                          tabIndex={0}
                          onClick={() => {
                            onSelectSection(sec.id);
                            if (window.innerWidth < 1024) {
                              onClose();
                            }
                          }}
                          onKeyDown={(e) => {
                            if (e.key === 'Enter' || e.key === ' ') {
                              onSelectSection(sec.id);
                            }
                          }}
                          className={`w-full flex items-center justify-between px-2.5 py-1.5 rounded-md text-left text-xs cursor-pointer transition-colors ${
                            isSecActive
                              ? 'bg-indigo-100/60 font-semibold text-indigo-800'
                              : 'text-slate-600 hover:text-indigo-600 hover:bg-slate-50'
                          }`}
                        >
                          <span className="truncate">{sec.title}</span>
                          <span className="text-[10px] text-slate-400 ml-1 shrink-0 font-mono">
                            {sec.pageRange}
                          </span>
                        </div>
                      );
                    })}
                  </div>
                )}
              </div>
            );
          })}
        </nav>

        {/* Footer info badge */}
        <div className="p-3 border-t border-slate-100 bg-slate-50/50 text-[11px] text-slate-400 text-center">
          Đại số Đại Cương &amp; Tuyến Tính • 33 Trang Chuẩn
        </div>
      </aside>
    </>
  );
};

export default Sidebar;
