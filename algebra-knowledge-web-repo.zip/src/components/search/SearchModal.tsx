import React, { useState, useEffect, useRef, useMemo } from 'react';
import { SearchItem } from '../../types/algebra';
import { Search, X, BookOpen, AlertCircle, FileText, CornerDownLeft, Sparkles } from 'lucide-react';
import MathRenderer from '../math/MathRenderer';

interface SearchModalProps {
  isOpen: boolean;
  onClose: () => void;
  items: SearchItem[];
  onSelectItem: (item: SearchItem) => void;
}

export function removeVietnameseTones(str: string): string {
  return str
    .normalize('NFD')
    .replace(/[\u0300-\u036f]/g, '')
    .replace(/đ/g, 'd')
    .replace(/Đ/g, 'D')
    .toLowerCase();
}

export const SearchModal: React.FC<SearchModalProps> = ({
  isOpen,
  onClose,
  items,
  onSelectItem,
}) => {
  const [query, setQuery] = useState('');
  const [selectedIndex, setSelectedIndex] = useState(0);
  const inputRef = useRef<HTMLInputElement>(null);

  // Focus input on open
  useEffect(() => {
    if (isOpen) {
      setQuery('');
      setSelectedIndex(0);
      setTimeout(() => {
        inputRef.current?.focus();
      }, 50);
    }
  }, [isOpen]);

  // Handle keyboard navigation & escape
  useEffect(() => {
    const handleKeyDown = (e: KeyboardEvent) => {
      if (!isOpen) return;

      if (e.key === 'Escape') {
        e.preventDefault();
        onClose();
      }
    };

    window.addEventListener('keydown', handleKeyDown);
    return () => window.removeEventListener('keydown', handleKeyDown);
  }, [isOpen, onClose]);

  // Filter items using fuzzy/accent-insensitive search
  const filteredResults = useMemo(() => {
    const trimmed = query.trim();
    if (!trimmed) {
      return items.slice(0, 8); // show initial recommendations
    }

    const normalizedQuery = removeVietnameseTones(trimmed);
    const words = normalizedQuery.split(/\s+/).filter(Boolean);

    return items
      .filter((item) => {
        const titleNorm = removeVietnameseTones(item.title);
        const snippetNorm = removeVietnameseTones(item.snippet);
        const catNorm = removeVietnameseTones(item.category);

        // All query words should appear in title or snippet or category
        return words.every(
          (w) => titleNorm.includes(w) || snippetNorm.includes(w) || catNorm.includes(w)
        );
      })
      .slice(0, 15);
  }, [query, items]);

  // Handle arrows in search results
  const handleInputKeyDown = (e: React.KeyboardEvent) => {
    if (e.key === 'ArrowDown') {
      e.preventDefault();
      setSelectedIndex((prev) => (prev < filteredResults.length - 1 ? prev + 1 : prev));
    } else if (e.key === 'ArrowUp') {
      e.preventDefault();
      setSelectedIndex((prev) => (prev > 0 ? prev - 1 : 0));
    } else if (e.key === 'Enter' && filteredResults.length > 0) {
      e.preventDefault();
      const chosen = filteredResults[selectedIndex] || filteredResults[0];
      if (chosen) {
        onSelectItem(chosen);
        onClose();
      }
    }
  };

  if (!isOpen) return null;

  const getCategoryIcon = (category: string) => {
    switch (category) {
      case 'Bẫy ngộ nhận':
        return <AlertCircle className="w-4 h-4 text-amber-500" />;
      case 'Ví dụ':
        return <FileText className="w-4 h-4 text-indigo-500" />;
      case 'Chương':
      case 'Mục':
      default:
        return <BookOpen className="w-4 h-4 text-emerald-500" />;
    }
  };

  return (
    <div
      role="dialog"
      aria-modal="true"
      data-testid="search-modal"
      className="search-modal fixed inset-0 z-50 flex items-start justify-center p-4 sm:p-6 md:p-20 bg-slate-900/60 backdrop-blur-sm animate-fadeIn"
      onClick={(e) => {
        if (e.target === e.currentTarget) onClose();
      }}
    >
      <div className="w-full max-w-2xl rounded-2xl bg-white shadow-2xl border border-slate-200 overflow-hidden transform transition-all">
        {/* Search Input Bar */}
        <div className="relative flex items-center border-b border-slate-200 px-4 py-3">
          <Search className="w-5 h-5 text-slate-400 mr-3 shrink-0" />
          <input
            ref={inputRef}
            type="search"
            role="combobox"
            aria-expanded={filteredResults.length > 0}
            placeholder="Tìm kiếm lý thuyết, định lý, công thức, bẫy ngộ nhận (Ctrl+K)..."
            value={query}
            onChange={(e) => {
              setQuery(e.target.value);
              setSelectedIndex(0);
            }}
            onKeyDown={handleInputKeyDown}
            className="w-full bg-transparent text-slate-800 placeholder-slate-400 text-sm sm:text-base focus:outline-none"
          />
          {query ? (
            <button
              type="button"
              onClick={() => setQuery('')}
              className="p-1 rounded-md text-slate-400 hover:text-slate-600 hover:bg-slate-100"
            >
              <X className="w-4 h-4" />
            </button>
          ) : (
            <kbd className="hidden sm:inline-block rounded bg-slate-100 px-2 py-0.5 text-xs font-semibold text-slate-500 border border-slate-300">
              ESC
            </kbd>
          )}
        </div>

        {/* Results List */}
        <div
          role="listbox"
          className="max-h-[60vh] overflow-y-auto p-2 divide-y divide-slate-100"
        >
          {filteredResults.length > 0 ? (
            filteredResults.map((item, idx) => {
              const isSelected = idx === selectedIndex;
              return (
                <div
                  key={item.id}
                  role="option"
                  aria-selected={isSelected}
                  data-testid="search-result-item"
                  onClick={() => {
                    onSelectItem(item);
                    onClose();
                  }}
                  onMouseEnter={() => setSelectedIndex(idx)}
                  className={`search-result flex items-start gap-3 p-3 rounded-xl cursor-pointer transition-colors ${
                    isSelected ? 'bg-indigo-50/80 text-indigo-900' : 'hover:bg-slate-50 text-slate-800'
                  }`}
                >
                  <div className="mt-0.5 shrink-0 rounded-lg bg-white p-2 border border-slate-200 shadow-xs">
                    {getCategoryIcon(item.category)}
                  </div>
                  <div className="flex-1 min-w-0">
                    <div className="flex items-center gap-2 mb-1">
                      <span className="text-xs font-semibold px-2 py-0.5 rounded-full bg-slate-100 text-slate-700 border border-slate-200">
                        {item.category}
                      </span>
                      <h4 className="text-sm font-semibold truncate text-slate-900">
                        {item.title}
                      </h4>
                    </div>
                    <p className="text-xs text-slate-600 line-clamp-2">
                      <MathRenderer>{item.snippet}</MathRenderer>
                    </p>
                  </div>
                  {isSelected && (
                    <CornerDownLeft className="w-4 h-4 text-indigo-600 shrink-0 self-center hidden sm:block" />
                  )}
                </div>
              );
            })
          ) : (
            <div
              data-testid="search-empty"
              className="py-12 px-4 text-center text-slate-500"
            >
              <div className="flex justify-center mb-3">
                <Sparkles className="w-8 h-8 text-slate-300" />
              </div>
              <p className="text-sm font-medium text-slate-700">
                Không tìm thấy kết quả phù hợp cho &quot;{query}&quot;
              </p>
              <p className="text-xs text-slate-400 mt-1">
                Thử tìm với từ khóa không dấu như: &quot;dinh thuc&quot;, &quot;kronecker&quot;, &quot;viete&quot; hoặc &quot;anh xa&quot;.
              </p>
            </div>
          )}
        </div>

        {/* Footer shortcuts */}
        <div className="border-t border-slate-100 bg-slate-50 px-4 py-2.5 flex items-center justify-between text-xs text-slate-500">
          <div className="flex items-center gap-4">
            <span className="flex items-center gap-1">
              <kbd className="rounded bg-white px-1.5 py-0.5 border border-slate-200 shadow-2xs font-mono">↑</kbd>
              <kbd className="rounded bg-white px-1.5 py-0.5 border border-slate-200 shadow-2xs font-mono">↓</kbd>
              <span>Di chuyển</span>
            </span>
            <span className="flex items-center gap-1">
              <kbd className="rounded bg-white px-1.5 py-0.5 border border-slate-200 shadow-2xs font-mono">↵</kbd>
              <span>Chọn</span>
            </span>
          </div>
          <div>
            <span>{filteredResults.length} kết quả</span>
          </div>
        </div>
      </div>
    </div>
  );
};

export default SearchModal;
