import React from 'react';
import { MasterTable as MasterTableType } from '../../types/algebra';
import MathRenderer from '../math/MathRenderer';
import { Table as TableIcon, Layers } from 'lucide-react';

interface MasterTableProps {
  table: MasterTableType;
}

export const MasterTable: React.FC<MasterTableProps> = ({ table }) => {
  return (
    <div
      id={table.id}
      data-testid={`master-table-${table.id}`}
      className="master-table-card my-8 rounded-2xl border border-slate-200 bg-white shadow-sm overflow-hidden transition-all hover:shadow-md"
    >
      {/* Table Header / Title */}
      <div className="border-b border-slate-200 bg-gradient-to-r from-slate-50 via-indigo-50/30 to-white px-5 py-4">
        <div className="flex items-center justify-between gap-2">
          <div className="flex items-center gap-2.5">
            <span className="flex h-7 w-7 items-center justify-center rounded-lg bg-indigo-600 text-white shadow-xs">
              <TableIcon className="w-4 h-4" />
            </span>
            <h4 className="text-sm sm:text-base font-bold text-slate-900 tracking-tight">
              {table.title}
            </h4>
          </div>
          <span className="inline-flex items-center gap-1 rounded-full bg-indigo-100/80 px-2.5 py-0.5 text-[11px] font-semibold text-indigo-800 border border-indigo-200/60">
            <Layers className="w-3 h-3" />
            <span>Bảng tổng hợp đối chuẩn</span>
          </span>
        </div>
        {table.description && (
          <p className="mt-2 text-xs sm:text-sm text-slate-600 leading-relaxed pl-9">
            {table.description}
          </p>
        )}
      </div>

      {/* Responsive Table Container */}
      <div className="overflow-x-auto">
        <table className="w-full text-left text-sm border-collapse">
          <thead>
            <tr className="border-b border-slate-200 bg-slate-100/80 text-xs font-semibold text-slate-800">
              {table.headers.map((header, idx) => (
                <th
                  key={idx}
                  scope="col"
                  className="px-4 py-3.5 first:pl-5 last:pr-5 min-w-[120px]"
                >
                  <MathRenderer>{header}</MathRenderer>
                </th>
              ))}
            </tr>
          </thead>
          <tbody className="divide-y divide-slate-100 text-slate-700">
            {table.rows.map((row, rowIdx) => (
              <tr
                key={rowIdx}
                className="hover:bg-indigo-50/40 transition-colors even:bg-slate-50/50"
              >
                {row.map((cell, colIdx) => (
                  <td
                    key={colIdx}
                    className="px-4 py-3.5 align-top first:pl-5 last:pr-5 text-xs sm:text-sm leading-relaxed"
                  >
                    <MathRenderer>{cell}</MathRenderer>
                  </td>
                ))}
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </div>
  );
};

export default MasterTable;
