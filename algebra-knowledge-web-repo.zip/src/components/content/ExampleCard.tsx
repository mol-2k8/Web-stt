import React, { useState } from 'react';
import { Example } from '../../types/algebra';
import MathRenderer from '../math/MathRenderer';
import { ChevronDown, HelpCircle, Lightbulb } from 'lucide-react';

interface ExampleCardProps {
  example: Example;
  defaultOpen?: boolean;
}

export const ExampleCard: React.FC<ExampleCardProps> = ({ example, defaultOpen = false }) => {
  const [isOpen, setIsOpen] = useState(defaultOpen);

  const getDifficultyBadge = (level?: string) => {
    switch (level) {
      case 'Nâng cao':
        return 'bg-purple-100 text-purple-800 border-purple-200';
      case 'Trung bình':
        return 'bg-blue-100 text-blue-800 border-blue-200';
      case 'Cơ bản':
      default:
        return 'bg-emerald-100 text-emerald-800 border-emerald-200';
    }
  };

  return (
    <div
      id={example.id}
      data-testid={`example-card-${example.id}`}
      className="example-card my-4 rounded-xl border border-slate-200 bg-white shadow-sm transition-all duration-200 overflow-hidden hover:border-slate-300"
    >
      {/* Problem Header & Statement */}
      <div className="p-5">
        <div className="flex flex-wrap items-center justify-between gap-2 mb-3">
          <div className="flex items-center gap-2">
            <span className="flex h-6 w-6 items-center justify-center rounded-md bg-indigo-100 text-indigo-700 text-xs font-semibold">
              Ví dụ
            </span>
            <h4 className="text-base font-semibold text-slate-800">
              {example.title}
            </h4>
          </div>
          {example.difficulty && (
            <span
              className={`rounded-full px-2.5 py-0.5 text-xs font-medium border ${getDifficultyBadge(
                example.difficulty
              )}`}
            >
              {example.difficulty}
            </span>
          )}
        </div>

        <div className="text-slate-700 text-sm leading-relaxed mb-3">
          <div className="font-medium text-slate-900 mb-1 flex items-center gap-1.5">
            <HelpCircle className="w-4 h-4 text-indigo-500" />
            <span>Đề bài:</span>
          </div>
          <div className="pl-5 text-slate-800">
            <MathRenderer>{example.problem}</MathRenderer>
          </div>
        </div>

        {/* Tip if available */}
        {example.tip && (
          <div className="badge tag mt-3 flex items-start gap-2 rounded-lg bg-indigo-50/70 p-3 text-xs text-indigo-950 border border-indigo-200/70">
            <Lightbulb className="w-4 h-4 text-indigo-600 shrink-0 mt-0.5" />
            <div>
              <span className="font-semibold text-indigo-900">Mẹo tư duy: </span>
              <MathRenderer>{example.tip}</MathRenderer>
            </div>
          </div>
        )}
      </div>

      {/* Collapsible Accordion Toggle */}
      <div className="border-t border-slate-100 bg-slate-50/60">
        <button
          type="button"
          aria-expanded={isOpen}
          data-testid={`example-step-toggle-${example.id}`}
          onClick={() => setIsOpen(!isOpen)}
          className="flex w-full items-center justify-between px-5 py-3 text-left text-sm font-medium text-slate-700 hover:text-indigo-600 transition-colors"
        >
          <span className="flex items-center gap-2">
            <span>{isOpen ? 'Thu gọn lời giải chi tiết' : 'Xem lời giải chi tiết từng bước'}</span>
            <span className="text-xs text-slate-400">({example.solutionSteps.length} bước giải)</span>
          </span>
          <ChevronDown
            className={`w-4 h-4 text-slate-400 transition-transform duration-200 ${
              isOpen ? 'rotate-180 text-indigo-600' : ''
            }`}
          />
        </button>

        {/* Step-by-Step Solution Derivation */}
        {isOpen && (
          <div
            data-testid="solution-content"
            className="solution-steps border-t border-slate-200/80 bg-white p-5 space-y-4"
          >
            <div className="text-xs font-semibold uppercase tracking-wider text-slate-400 mb-2">
              Các bước dẫn xuất toán học
            </div>
            {example.solutionSteps.map((step, idx) => (
              <div key={idx} className="flex items-start gap-3 text-sm text-slate-700">
                <span className="flex h-5 w-5 shrink-0 items-center justify-center rounded-full bg-indigo-50 text-[11px] font-semibold text-indigo-600 border border-indigo-200">
                  {idx + 1}
                </span>
                <div className="flex-1 overflow-x-auto py-0.5">
                  <MathRenderer>{step}</MathRenderer>
                </div>
              </div>
            ))}
          </div>
        )}
      </div>
    </div>
  );
};

export default ExampleCard;
