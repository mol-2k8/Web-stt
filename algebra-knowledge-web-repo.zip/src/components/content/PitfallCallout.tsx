import React from 'react';
import { Pitfall } from '../../types/algebra';
import MathRenderer from '../math/MathRenderer';
import { AlertTriangle, XCircle, RefreshCw, CheckCircle2 } from 'lucide-react';

interface PitfallCalloutProps {
  pitfall: Pitfall;
}

export const PitfallCallout: React.FC<PitfallCalloutProps> = ({ pitfall }) => {
  return (
    <div
      id={pitfall.id}
      data-testid={`pitfall-${pitfall.id}`}
      className="pitfall-card callout-trap my-5 rounded-xl border-l-4 border-amber-500 border-y border-r border-slate-200 bg-amber-50/20 p-5 shadow-sm transition-all hover:shadow-md"
    >
      {/* Header with warning badge */}
      <div className="flex items-center gap-2 mb-3">
        <span className="flex h-7 w-7 items-center justify-center rounded-lg bg-amber-500 text-white shadow-sm">
          <AlertTriangle className="w-4 h-4" />
        </span>
        <h4 className="text-base font-bold text-slate-900 tracking-tight">
          Bẫy ngộ nhận: {pitfall.name}
        </h4>
        {pitfall.category && (
          <span className="ml-auto rounded-md bg-amber-100 px-2 py-0.5 text-xs font-semibold text-amber-800">
            {pitfall.category}
          </span>
        )}
      </div>

      <div className="space-y-3.5 text-sm">
        {/* Ngộ nhận (Fallacy) */}
        <div className="rounded-lg bg-white/80 p-3.5 border border-red-100/80">
          <div className="flex items-center gap-1.5 font-semibold text-rose-700 mb-1">
            <XCircle className="w-4 h-4 shrink-0" />
            <span>Ngộ nhận thường gặp:</span>
          </div>
          <div className="pl-5 text-slate-800">
            <MathRenderer>{pitfall.fallacy}</MathRenderer>
          </div>
        </div>

        {/* Cơ chế sinh lỗi (Mechanism) */}
        <div className="rounded-lg bg-white/80 p-3.5 border border-amber-100/80">
          <div className="flex items-center gap-1.5 font-semibold text-amber-800 mb-1">
            <RefreshCw className="w-4 h-4 shrink-0 text-amber-600" />
            <span>Cơ chế sinh lỗi:</span>
          </div>
          <div className="pl-5 text-slate-700">
            <MathRenderer>{pitfall.mechanism}</MathRenderer>
          </div>
        </div>

        {/* Phản ví dụ (Counterexample) */}
        <div className="rounded-lg bg-white/80 p-3.5 border border-purple-100/80">
          <div className="flex items-center gap-1.5 font-semibold text-purple-700 mb-1">
            <AlertTriangle className="w-4 h-4 shrink-0 text-purple-600" />
            <span>Phản ví dụ minh họa:</span>
          </div>
          <div className="pl-5 text-slate-800 overflow-x-auto">
            <MathRenderer>{pitfall.counterexample}</MathRenderer>
          </div>
        </div>

        {/* Quy tắc chuẩn hóa (Standard Rule) */}
        <div className="rounded-lg bg-emerald-50/90 p-3.5 border border-emerald-200">
          <div className="flex items-center gap-1.5 font-semibold text-emerald-800 mb-1">
            <CheckCircle2 className="w-4 h-4 shrink-0 text-emerald-600" />
            <span>Quy tắc chuẩn hóa:</span>
          </div>
          <div className="pl-5 text-emerald-950 font-medium">
            <MathRenderer>{pitfall.standardRule}</MathRenderer>
          </div>
        </div>
      </div>
    </div>
  );
};

export default PitfallCallout;
