import React, { useMemo } from 'react';
import katex from 'katex';

export interface MathRendererProps {
  math?: string;
  block?: boolean;
  className?: string;
  children?: string;
}

/**
 * Synchronously render a LaTeX string to KaTeX HTML string.
 */
export function renderLatexToString(latex: string, displayMode: boolean = false): string {
  try {
    const rendered = katex.renderToString(latex.trim(), {
      displayMode,
      throwOnError: false,
      errorColor: '#dc2626',
      strict: false,
      trust: true,
    });
    // Sanitize internal KaTeX font Private Use Area (PUA) overlay glyphs (U+E000 - U+F8FF)
    return rendered.replace(/[\uE000-\uF8FF]/g, '');
  } catch (err) {
    console.error('KaTeX rendering error for:', latex, err);
    return `<span class="katex-fallback">${latex}</span>`;
  }
}

/**
 * Parses mixed text containing inline ($...$ or \(...\)) and display ($$...$$ or \[...\]) math.
 */
export function parseMixedMath(content: string): React.ReactNode[] {
  if (!content) return [];

  // Match:
  // 1. $$ ... $$
  // 2. \[ ... \]
  // 3. $ ... $
  // 4. \( ... \)
  // 5. \begin{pmatrix|vmatrix|cases|array} ... \end{pmatrix|vmatrix|cases|array}
  const mathRegex = /(\$\$(?:[^\$]|\\\$)+?\$\$|\\\[[\s\S]+?\\\]|\$(?:[^\$\n]|\\\$)+?\$|\\\([\s\S]+?\\\)|\n?\\begin\{(?:pmatrix|vmatrix|cases|array|matrix|bmatrix)\}[\s\S]+?\\end\{(?:pmatrix|vmatrix|cases|array|matrix|bmatrix)\}\n?)/g;

  const parts = content.split(mathRegex);

  return parts.map((part, index) => {
    if (!part) return null;

    // Display math $$...$$
    if (part.startsWith('$$') && part.endsWith('$$') && part.length >= 4) {
      const formula = part.slice(2, -2).trim();
      const html = renderLatexToString(formula, true);
      return (
        <span
          key={index}
          className="katex-display my-3 block overflow-x-auto overflow-y-hidden"
          dangerouslySetInnerHTML={{ __html: html }}
        />
      );
    }

    // Display math \[...\]
    if (part.startsWith('\\[') && part.endsWith('\\]') && part.length >= 4) {
      const formula = part.slice(2, -2).trim();
      const html = renderLatexToString(formula, true);
      return (
        <span
          key={index}
          className="katex-display my-3 block overflow-x-auto overflow-y-hidden"
          dangerouslySetInnerHTML={{ __html: html }}
        />
      );
    }

    // Standalone matrix/cases environment
    if (/^\\begin\{(?:pmatrix|vmatrix|cases|array|matrix|bmatrix)\}/.test(part.trim())) {
      const html = renderLatexToString(part.trim(), true);
      return (
        <span
          key={index}
          className="katex-display my-3 block overflow-x-auto overflow-y-hidden"
          dangerouslySetInnerHTML={{ __html: html }}
        />
      );
    }

    // Inline math $...$
    if (part.startsWith('$') && part.endsWith('$') && part.length >= 2) {
      const formula = part.slice(1, -1).trim();
      const html = renderLatexToString(formula, false);
      return (
        <span
          key={index}
          className="inline-math mx-0.5 diacritic-safe"
          dangerouslySetInnerHTML={{ __html: html }}
        />
      );
    }

    // Inline math \(...\)
    if (part.startsWith('\\(') && part.endsWith('\\)') && part.length >= 4) {
      const formula = part.slice(2, -2).trim();
      const html = renderLatexToString(formula, false);
      return (
        <span
          key={index}
          className="inline-math mx-0.5 diacritic-safe"
          dangerouslySetInnerHTML={{ __html: html }}
        />
      );
    }

    // Normal text
    return <React.Fragment key={index}>{part}</React.Fragment>;
  }).filter(Boolean);
}

export const MathRenderer: React.FC<MathRendererProps> = ({
  math,
  block = false,
  className = '',
  children,
}) => {
  const content = math ?? children ?? '';

  // If explicitly block or pure math without text delimiters
  const isPureFormula = block || (
    !content.includes('$') &&
    (content.startsWith('\\') || content.includes('=') || content.includes('^') || content.includes('_')) &&
    !content.includes(' ') // no spaces with words
  );

  const renderedHtml = useMemo(() => {
    if (isPureFormula && content.trim()) {
      return renderLatexToString(content, block);
    }
    return null;
  }, [content, block, isPureFormula]);

  if (renderedHtml) {
    if (block) {
      return (
        <div
          className={`katex-display my-3 overflow-x-auto overflow-y-hidden ${className}`}
          dangerouslySetInnerHTML={{ __html: renderedHtml }}
        />
      );
    }
    return (
      <span
        className={`inline-math diacritic-safe ${className}`}
        dangerouslySetInnerHTML={{ __html: renderedHtml }}
      />
    );
  }

  // Parse mixed text and math
  return (
    <span className={`academic-text leading-relaxed ${className}`}>
      {parseMixedMath(content)}
    </span>
  );
};

export default MathRenderer;
