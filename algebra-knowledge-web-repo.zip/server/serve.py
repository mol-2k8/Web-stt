#!/usr/bin/env python3
"""
server/serve.py
===============
Production HTTP Static Server (Python) for Algebra Knowledge Web.

Requirements Met:
1. RFC 8081 Compliant MIME Types:
   - .woff2 -> font/woff2
   - .woff  -> font/woff
   - .ttf   -> font/ttf
2. Cross-Origin Resource Sharing (CORS):
   - Access-Control-Allow-Origin: *
   - Access-Control-Allow-Methods: GET, HEAD, OPTIONS
3. HTTP Caching Headers:
   - Fonts: Cache-Control: public, max-age=31536000, immutable
   - HTML:  Cache-Control: no-cache, no-store, must-revalidate
4. Static Resolution & SPA Fallback:
   - Resolves from dist/, public/, and project root
   - Fallback to index.html for extensionless client routes
5. Configurable Port via PORT env var (default: 3000)
"""

import os
import sys
import mimetypes
import urllib.parse
from http.server import HTTPServer, BaseHTTPRequestHandler
from pathlib import Path

PORT = int(os.environ.get("PORT", 3000))
HOST = os.environ.get("HOST", "0.0.0.0")
PROJECT_ROOT = Path(__file__).resolve().parent.parent

# Register and override standard MIME types per RFC 8081
MIME_TYPES = {
    ".woff2": "font/woff2",
    ".woff": "font/woff",
    ".ttf": "font/ttf",
    ".otf": "font/otf",
    ".eot": "application/vnd.ms-fontobject",
    ".html": "text/html; charset=utf-8",
    ".htm": "text/html; charset=utf-8",
    ".css": "text/css; charset=utf-8",
    ".js": "application/javascript; charset=utf-8",
    ".mjs": "application/javascript; charset=utf-8",
    ".json": "application/json; charset=utf-8",
    ".svg": "image/svg+xml",
    ".png": "image/png",
    ".jpg": "image/jpeg",
    ".jpeg": "image/jpeg",
    ".gif": "image/gif",
    ".ico": "image/x-icon",
    ".webp": "image/webp",
    ".txt": "text/plain; charset=utf-8",
    ".map": "application/json",
}

def resolve_file(req_path: str) -> Path | None:
    """Find requested path across dist/, public/, and project root."""
    decoded = urllib.parse.unquote(req_path)
    clean_path = decoded.lstrip("/\\")

    candidates = [
        PROJECT_ROOT / "dist" / clean_path,
        PROJECT_ROOT / "public" / clean_path,
        PROJECT_ROOT / clean_path,
    ]

    for cand in candidates:
        if cand.is_file():
            return cand
        if cand.is_dir():
            index_file = cand / "index.html"
            if index_file.is_file():
                return index_file

    return None

def resolve_spa_index() -> Path | None:
    """Return index.html if available."""
    dist_index = PROJECT_ROOT / "dist" / "index.html"
    if dist_index.is_file():
        return dist_index
    root_index = PROJECT_ROOT / "index.html"
    if root_index.is_file():
        return root_index
    return None

class ProductionHTTPHandler(BaseHTTPRequestHandler):
    """High-performance HTTP handler with explicit MIME, CORS and Cache headers."""

    server_version = "AlgebraWebServer/1.0"

    def send_cors_headers(self):
        self.send_header("Access-Control-Allow-Origin", "*")
        self.send_header("Access-Control-Allow-Methods", "GET, HEAD, OPTIONS")
        self.send_header("Access-Control-Allow-Headers", "*")
        self.send_header("Access-Control-Max-Age", "86400")

    def do_OPTIONS(self):
        """Respond to CORS preflight requests."""
        self.send_response(204)
        self.send_cors_headers()
        self.end_headers()

    def do_HEAD(self):
        """Serve HEAD requests."""
        self.serve_file(send_body=False)

    def do_GET(self):
        """Serve GET requests."""
        self.serve_file(send_body=True)

    def serve_file(self, send_body: bool = True):
        parsed = urllib.parse.urlparse(self.path)
        pathname = parsed.path or "/"

        file_path = resolve_file(pathname)

        # Extensionless route fallback to index.html (SPA routing)
        if not file_path and not Path(pathname).suffix:
            file_path = resolve_spa_index()

        if not file_path or not file_path.exists():
            self.send_response(404)
            self.send_cors_headers()
            self.send_header("Content-Type", "text/plain; charset=utf-8")
            self.end_headers()
            if send_body:
                self.wfile.write(f"404 Not Found: {pathname}\n".encode("utf-8"))
            return

        try:
            stat_res = file_path.stat()
            file_size = stat_res.st_size
            suffix = file_path.suffix.lower()
            content_type = MIME_TYPES.get(suffix, "application/octet-stream")

            self.send_response(200)
            self.send_cors_headers()
            self.send_header("Content-Type", content_type)
            self.send_header("Content-Length", str(file_size))

            # Cache headers
            if suffix in [".woff2", ".woff", ".ttf"]:
                self.send_header("Cache-Control", "public, max-age=31536000, immutable")
            elif suffix == ".html":
                self.send_header("Cache-Control", "no-cache, no-store, must-revalidate")
            else:
                self.send_header("Cache-Control", "public, max-age=86400")

            self.end_headers()

            if send_body:
                with open(file_path, "rb") as f:
                    # Stream in 64KB chunks
                    while chunk := f.read(65536):
                        self.wfile.write(chunk)
        except Exception as err:
            self.send_response(500)
            self.send_cors_headers()
            self.send_header("Content-Type", "text/plain; charset=utf-8")
            self.end_headers()
            if send_body:
                self.wfile.write(f"500 Internal Error: {err}\n".encode("utf-8"))

    def log_message(self, format, *args):
        # Keep logs clean during high-concurrency requests
        if os.environ.get("VERBOSE_SERVER"):
            super().log_message(format, *args)

def run_server(port: int = PORT, host: str = HOST):
    server_address = (host, port)
    httpd = HTTPServer(server_address, ProductionHTTPHandler)
    print("=" * 55)
    print("  Algebra Knowledge Web Python Server Running")
    print(f"  Listening at: http://localhost:{port}")
    print("  CORS: Access-Control-Allow-Origin: *")
    print("  WOFF2 MIME: font/woff2 (RFC 8081)")
    print("  WOFF  MIME: font/woff")
    print("=" * 55)
    try:
        httpd.serve_forever()
    except KeyboardInterrupt:
        print("\nServer shutting down gracefully.")
        httpd.server_close()

if __name__ == "__main__":
    run_server()
