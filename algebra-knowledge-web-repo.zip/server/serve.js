/**
 * server/serve.js
 * ===============
 * Production HTTP Static Server (Node.js) for Algebra Knowledge Web.
 *
 * Requirements Met:
 * 1. RFC 8081 Compliant MIME Types:
 *    - .woff2 -> font/woff2
 *    - .woff  -> font/woff
 *    - .ttf   -> font/ttf
 * 2. Cross-Origin Resource Sharing (CORS):
 *    - Access-Control-Allow-Origin: *
 *    - Access-Control-Allow-Methods: GET, HEAD, OPTIONS
 * 3. HTTP Caching Headers:
 *    - Fonts: Cache-Control: public, max-age=31536000, immutable
 *    - HTML:  Cache-Control: no-cache, no-store, must-revalidate
 * 4. Fallback Static Directory Resolution:
 *    - Searches in dist/, public/, and project root
 *    - SPA Fallback: Serves index.html for extensionless client routes
 * 5. Port configuration:
 *    - Uses PORT environment variable or defaults to 3000
 */

const http = require('http');
const fs = require('fs');
const path = require('path');
const url = require('url');

const PORT = parseInt(process.env.PORT || '3000', 10);
const HOST = process.env.HOST || '0.0.0.0';
const PROJECT_ROOT = path.resolve(__dirname, '..');

// MIME type map ensuring RFC 8081 standard for fonts
const MIME_TYPES = {
  '.woff2': 'font/woff2',
  '.woff': 'font/woff',
  '.ttf': 'font/ttf',
  '.otf': 'font/otf',
  '.eot': 'application/vnd.ms-fontobject',
  '.html': 'text/html; charset=utf-8',
  '.htm': 'text/html; charset=utf-8',
  '.css': 'text/css; charset=utf-8',
  '.js': 'application/javascript; charset=utf-8',
  '.mjs': 'application/javascript; charset=utf-8',
  '.json': 'application/json; charset=utf-8',
  '.svg': 'image/svg+xml',
  '.png': 'image/png',
  '.jpg': 'image/jpeg',
  '.jpeg': 'image/jpeg',
  '.gif': 'image/gif',
  '.ico': 'image/x-icon',
  '.webp': 'image/webp',
  '.txt': 'text/plain; charset=utf-8',
  '.map': 'application/json',
};

/**
 * Locate the file on disk checking priority directories:
 * 1. dist/
 * 2. public/
 * 3. project root
 */
function resolveFilePath(reqPath) {
  // Decode percent-encoded URLs and normalize path
  let decodedPath;
  try {
    decodedPath = decodeURIComponent(reqPath);
  } catch {
    decodedPath = reqPath;
  }

  // Prevent directory traversal attacks
  const safePath = path.normalize(decodedPath).replace(/^(\.\.[\/\\])+/, '');
  const relativePath = safePath.replace(/^[\/\\]+/, '');

  const searchCandidates = [
    path.join(PROJECT_ROOT, 'dist', relativePath),
    path.join(PROJECT_ROOT, 'public', relativePath),
    path.join(PROJECT_ROOT, relativePath),
  ];

  for (const candidate of searchCandidates) {
    if (fs.existsSync(candidate)) {
      const stat = fs.statSync(candidate);
      if (stat.isFile()) {
        return candidate;
      }
      if (stat.isDirectory()) {
        const indexHtml = path.join(candidate, 'index.html');
        if (fs.existsSync(indexHtml) && fs.statSync(indexHtml).isFile()) {
          return indexHtml;
        }
      }
    }
  }

  return null;
}

/**
 * Locate SPA index.html fallback
 */
function resolveIndexHtml() {
  const distIndex = path.join(PROJECT_ROOT, 'dist', 'index.html');
  if (fs.existsSync(distIndex)) {
    return distIndex;
  }
  const rootIndex = path.join(PROJECT_ROOT, 'index.html');
  if (fs.existsSync(rootIndex)) {
    return rootIndex;
  }
  return null;
}

const server = http.createServer((req, res) => {
  const parsedUrl = new URL(req.url, `http://${req.headers.host || 'localhost'}`);
  const pathname = parsedUrl.pathname || '/';

  // Universal CORS Headers
  res.setHeader('Access-Control-Allow-Origin', '*');
  res.setHeader('Access-Control-Allow-Methods', 'GET, HEAD, OPTIONS');
  res.setHeader('Access-Control-Allow-Headers', '*');
  res.setHeader('Access-Control-Max-Age', '86400');

  // Handle preflight OPTIONS request
  if (req.method === 'OPTIONS') {
    res.writeHead(204);
    res.end();
    return;
  }

  if (req.method !== 'GET' && req.method !== 'HEAD') {
    res.writeHead(405, { 'Content-Type': 'text/plain' });
    res.end('Method Not Allowed');
    return;
  }

  let filePath = resolveFilePath(pathname);

  // If path has no extension and is not found, fallback to index.html for SPA routing
  if (!filePath && !path.extname(pathname)) {
    filePath = resolveIndexHtml();
  }

  if (!filePath) {
    res.writeHead(404, { 'Content-Type': 'text/plain' });
    res.end(`404 Not Found: ${pathname}`);
    return;
  }

  try {
    const stat = fs.statSync(filePath);
    const ext = path.extname(filePath).toLowerCase();
    const contentType = MIME_TYPES[ext] || 'application/octet-stream';

    // Set Caching Headers
    if (ext === '.woff2' || ext === '.woff' || ext === '.ttf') {
      res.setHeader('Cache-Control', 'public, max-age=31536000, immutable');
    } else if (ext === '.html') {
      res.setHeader('Cache-Control', 'no-cache, no-store, must-revalidate');
    } else {
      res.setHeader('Cache-Control', 'public, max-age=86400');
    }

    res.setHeader('Content-Type', contentType);
    res.setHeader('Content-Length', stat.size);
    res.setHeader('Last-Modified', stat.mtime.toUTCString());

    // Handle If-Modified-Since 304 Not Modified
    const ifModifiedSince = req.headers['if-modified-since'];
    if (ifModifiedSince) {
      const clientTime = new Date(ifModifiedSince).getTime();
      const fileTime = Math.floor(stat.mtime.getTime() / 1000) * 1000;
      if (!isNaN(clientTime) && clientTime >= fileTime) {
        res.writeHead(304);
        res.end();
        return;
      }
    }

    if (req.method === 'HEAD') {
      res.writeHead(200);
      res.end();
      return;
    }

    res.writeHead(200);
    const readStream = fs.createReadStream(filePath);
    readStream.pipe(res);
  } catch (err) {
    res.writeHead(500, { 'Content-Type': 'text/plain' });
    res.end(`500 Internal Server Error: ${err.message}`);
  }
});

if (require.main === module) {
  server.listen(PORT, HOST, () => {
    console.log(`=====================================================`);
    console.log(`  Algebra Knowledge Web Node.js Server Running`);
    console.log(`  Listening at: http://localhost:${PORT}`);
    console.log(`  CORS: Access-Control-Allow-Origin: *`);
    console.log(`  WOFF2 MIME: font/woff2 (RFC 8081)`);
    console.log(`  WOFF  MIME: font/woff`);
    console.log(`=====================================================`);
  });
}

module.exports = { server, PORT, HOST };
