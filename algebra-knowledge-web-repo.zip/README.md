# Chuyên Khảo Đại Số Đại Cương và Tuyến Tính
### Nền tảng Web Tra Cứu Tri Thức, Cấu Trúc Nghiệm và Phân Tích Bẫy Nhận Thức Đại Số

Trang web tổng hợp và số hóa toàn diện từ 33 trang tài liệu chuyên khảo chuyên sâu về Đại số đại cương và Đại số tuyến tính, khắc phục triệt để các lỗi phông chữ tiếng Việt và ký hiệu toán học trên mọi trình duyệt hiện đại.

---

## 🌟 Tính Năng Nổi Bật

- **Số hóa trọn vẹn 33 trang tài liệu:**
  - **7 chương lý thuyết chuyên sâu:** Từ lý thuyết tập hợp, quan hệ hai ngôi, cấu trúc nửa nhóm - nhóm - vành - trường, số phức & căn bậc n đơn vị, đến không gian véc-tơ, ma trận, định thức và hệ phương trình tuyến tính.
  - **30 bài toán minh họa:** Kèm giải tích từng bước và các biến đổi đại số chi tiết.
  - **42 bẫy lý thuyết:** Phân tích điểm nghẽn nhận thức và phản ví dụ thực tế.
  - **4 bảng ma trận đối chuẩn:** Đối ngẫu ảnh thuận/ngược, phân cấp 6 tầng cấu trúc đại số, định lý Kronecker-Capelli, và ma trận bẫy nhận thức 12 phạm trù.
- **Chuẩn hóa & Tối ưu phông chữ Web (Zero Tofu):**
  - Sử dụng phông tiếng Việt tối ưu `Be Vietnam Pro` được subsetting định dạng **WOFF2** siêu nhẹ (~23KB) bao phủ 100% ký tự tiếng Việt Unicode (NFC).
  - Tích hợp bộ kết xuất công thức toán học KaTeX đồng bộ, hiển thị sắc nét các biểu thức và ma trận phức tạp.
  - Cấu hình `@font-face` chuẩn với `font-display: swap` và preload font chính trong HTML, loại bỏ hoàn toàn hiện tượng văn bản vô hình (FOIT).
- **Giao diện học thuật 3 cột:** Điều hướng nhanh giữa các chương mục, tìm kiếm tức thì với phím tắt `Ctrl + K`.

---

## 🚀 Cách Triển Khai Lên GitHub & Mở Web Miễn Phí (GitHub Pages)

### Bước 1: Đẩy mã nguồn lên GitHub Repo
1. Tạo một repository mới trên GitHub (ví dụ: `algebra-knowledge-web`).
2. Mở terminal tại thư mục này và chạy các lệnh:
   ```bash
   git init
   git add .
   git commit -m "Initial commit: Chuyen khao Dai so Web App"
   git branch -M main
   git remote add origin https://github.com/<tai-khoan-cua-ban>/<ten-repo>.git
   git push -u origin main
   ```

### Bước 2: Bật GitHub Pages (Tự động chạy máy chủ trên GitHub)
Repo đã được cấu hình sẵn **GitHub Actions Workflow** tại `.github/workflows/deploy.yml`. Bạn chỉ cần:
1. Vào trang repository trên GitHub -> Chọn tab **Settings**.
2. Ở thanh menu bên trái, nhấp vào mục **Pages**.
3. Tại phần **Build and deployment** -> **Source**: Chọn **GitHub Actions**.
4. GitHub Actions sẽ tự động biên dịch và triển khai trang web! Sau khoảng 1-2 phút, bạn sẽ nhận được đường link truy cập công khai trực tiếp trên internet, dạng:
   👉 `https://<tai-khoan-cua-ban>.github.io/<ten-repo>/`

---

## 💻 Khởi Chạy Cục Bộ (Local Development)

Yêu cầu: Đã cài đặt **Node.js** (phiên bản 18+ trở lên).

```bash
# 1. Cài đặt các thư viện cần thiết
npm install

# 2. Khởi chạy môi trường phát triển (Vite Dev Server)
npm run dev
# Mở trình duyệt tại: http://localhost:3000

# 3. Đóng gói bản sản xuất
npm run build

# 4. Khởi chạy máy chủ sản xuất tĩnh (Static Production Server)
npm run serve
```

---

## 📁 Cấu Trúc Dự Án

```
algebra-knowledge-web/
├── .github/workflows/deploy.yml   # Workflow tự động triển khai GitHub Pages
├── dist/                          # Gói web tĩnh sẵn sàng phục vụ
├── public/
│   └── fonts/                     # Bộ phông web WOFF2/WOFF đã subsetting
├── server/
│   ├── serve.js                   # Máy chủ Node.js chuẩn MIME RFC 8081 & CORS
│   └── serve.py                   # Máy chủ Python dự phòng
├── src/
│   ├── components/                # Các thành phần giao diện (MathRenderer, MasterTable, ...)
│   ├── data/                      # Cơ sở tri thức 33 trang (7 chương, 30 ví dụ, 42 bẫy)
│   ├── App.tsx                    # Thành phần chính của ứng dụng
│   └── index.css                  # Cấu hình CSS, Tailwind & @font-face
├── launcher.pyw                   # App 1 nút bấm mở web tiện lợi
├── package.json
└── vite.config.ts
```

---

## 📜 Giấy Phép
Dự án được phân phối phục vụ mục đích học tập và nghiên cứu học thuật.
