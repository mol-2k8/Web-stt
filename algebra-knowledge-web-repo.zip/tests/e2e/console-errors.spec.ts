import { test, expect, ConsoleMessage } from '@playwright/test';

test.describe('Tier 1 & Tier 2: Zero Console Errors, Zero CORS Violations & Zero 404/500 Assets', () => {
  test('T1.1: Assert 0 console errors and 0 pageerror unhandled exceptions on initial page load', async ({ page }) => {
    const consoleErrors: string[] = [];
    const pageErrors: Error[] = [];

    page.on('console', (msg: ConsoleMessage) => {
      if (msg.type() === 'error') {
        consoleErrors.push(msg.text());
      }
    });

    page.on('pageerror', (err: Error) => {
      pageErrors.push(err);
    });

    const response = await page.goto('/', { waitUntil: 'networkidle' });
    expect(response?.status()).toBe(200);

    expect(
      consoleErrors,
      `Detected console errors on initial load: \n${consoleErrors.join('\n')}`
    ).toHaveLength(0);

    expect(
      pageErrors,
      `Detected unhandled page errors: \n${pageErrors.map((e) => e.message).join('\n')}`
    ).toHaveLength(0);
  });

  test('T1.2: Assert 0 CORS policy violations across all network requests and console', async ({ page }) => {
    const corsViolations: string[] = [];

    page.on('console', (msg) => {
      const text = msg.text();
      if (
        text.toLowerCase().includes('cors') ||
        text.toLowerCase().includes('access-control-allow-origin') ||
        text.toLowerCase().includes('blocked by cors policy')
      ) {
        corsViolations.push(text);
      }
    });

    page.on('requestfailed', (req) => {
      const failure = req.failure();
      if (failure && failure.errorText.toLowerCase().includes('cors')) {
        corsViolations.push(`Request to ${req.url()} failed with CORS: ${failure.errorText}`);
      }
    });

    await page.goto('/', { waitUntil: 'networkidle' });

    expect(
      corsViolations,
      `Detected CORS policy violations: \n${corsViolations.join('\n')}`
    ).toHaveLength(0);
  });

  test('T1.3: Assert 0 HTTP 404 or 500 status codes for any script, style, font, or data asset', async ({ page }) => {
    const failedAssets: { url: string; status: number }[] = [];

    page.on('response', (res) => {
      const status = res.status();
      if (status >= 400) {
        failedAssets.push({
          url: res.url(),
          status,
        });
      }
    });

    await page.goto('/', { waitUntil: 'networkidle' });

    expect(
      failedAssets,
      `Detected failed asset requests (HTTP 4xx/5xx): \n${failedAssets
        .map((a) => `[HTTP ${a.status}] ${a.url}`)
        .join('\n')}`
    ).toHaveLength(0);
  });

  test('T1.4: Assert 0 font decoding, OTS parsing or glyph replacement warnings', async ({ page }) => {
    const fontWarnings: string[] = [];

    page.on('console', (msg) => {
      const text = msg.text().toLowerCase();
      if (
        text.includes('ots parsing error') ||
        text.includes('failed to decode downloaded font') ||
        text.includes('sanitiser') ||
        text.includes('missing glyph') ||
        text.includes('cannot find font') ||
        text.includes('bad font')
      ) {
        fontWarnings.push(msg.text());
      }
    });

    await page.goto('/', { waitUntil: 'networkidle' });
    await page.evaluate(async () => await document.fonts.ready);

    expect(
      fontWarnings,
      `Detected font engine warnings: \n${fontWarnings.join('\n')}`
    ).toHaveLength(0);
  });

  test('T2.1: Boundary - 0 console errors during full 7-chapter sequential navigation', async ({ page }) => {
    const capturedErrors: string[] = [];

    page.on('console', (msg) => {
      if (msg.type() === 'error') {
        capturedErrors.push(`[Console Error] ${msg.text()}`);
      }
    });

    page.on('pageerror', (err) => {
      capturedErrors.push(`[Page Error] ${err.message}`);
    });

    await page.goto('/', { waitUntil: 'networkidle' });

    // Find all chapter navigation items (tabs, links, or sidebar items)
    const chapterLinks = page.locator('aside nav button, aside nav a, nav [role="tab"], [data-testid^="chapter-nav-"]');
    const linkCount = await chapterLinks.count();

    if (linkCount > 0) {
      for (let i = 0; i < linkCount; i++) {
        const item = chapterLinks.nth(i);
        if (await item.isVisible()) {
          await item.click().catch(() => {});
          await page.waitForTimeout(150);
        }
      }
    }

    expect(
      capturedErrors,
      `Errors recorded during chapter navigation: \n${capturedErrors.join('\n')}`
    ).toHaveLength(0);
  });

  test('T2.2: Boundary - 0 unhandled promise rejections or errors under stress interaction', async ({ page }) => {
    const capturedErrors: string[] = [];

    page.on('console', (msg) => {
      if (msg.type() === 'error') {
        capturedErrors.push(msg.text());
      }
    });

    page.on('pageerror', (err) => {
      capturedErrors.push(err.message);
    });

    await page.goto('/', { waitUntil: 'networkidle' });

    // Stress test: toggle accordions / worked examples
    const accordionTriggers = page.locator('summary, button[aria-expanded], [data-testid^="accordion-"]');
    const count = await accordionTriggers.count();

    for (let i = 0; i < Math.min(count, 15); i++) {
      await accordionTriggers.nth(i).click().catch(() => {});
      await page.waitForTimeout(50);
      // Double toggle
      await accordionTriggers.nth(i).click().catch(() => {});
    }

    expect(capturedErrors).toHaveLength(0);
  });

  test('T2.3: Boundary - 0 errors during search modal open, rapid input, and close cycle', async ({ page }) => {
    const capturedErrors: string[] = [];

    page.on('console', (msg) => {
      if (msg.type() === 'error') {
        capturedErrors.push(msg.text());
      }
    });

    await page.goto('/', { waitUntil: 'networkidle' });

    // Open search modal via shortcut or button
    const searchTrigger = page.locator('button:has-text("Tìm kiếm"), input[placeholder*="Tìm"], [aria-label*="search" i]').first();
    if (await searchTrigger.isVisible()) {
      await searchTrigger.click();

      const searchInput = page.locator('input[type="search"], input[placeholder*="tìm" i], input[role="combobox"]').first();
      if (await searchInput.isVisible()) {
        // Test various edge inputs
        const queries = [
          'Kronecker',
          'Viète',
          '[][]*+?()\\', // Regex special characters
          '   ',
          '1234567890!@#$%^&*()',
          'ánh xạ toàn ánh và ma trận nghịch đảo',
        ];

        for (const q of queries) {
          await searchInput.fill(q);
          await page.waitForTimeout(50);
        }

        // Close search
        await page.keyboard.press('Escape');
      }
    }

    expect(capturedErrors).toHaveLength(0);
  });

  test('T3.1: Cross-Feature - Window error event listeners receive 0 uncaught exceptions', async ({ page }) => {
    await page.goto('/');

    const unhandledRejections = await page.evaluate(() => {
      return new Promise<string[]>((resolve) => {
        const errors: string[] = [];
        window.addEventListener('unhandledrejection', (event) => {
          errors.push(`Unhandled rejection: ${event.reason}`);
        });
        window.addEventListener('error', (event) => {
          errors.push(`Uncaught error: ${event.message}`);
        });

        setTimeout(() => resolve(errors), 1000);
      });
    });

    expect(unhandledRejections).toHaveLength(0);
  });
});
