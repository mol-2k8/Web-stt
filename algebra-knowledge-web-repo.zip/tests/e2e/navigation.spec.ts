import { test, expect } from '@playwright/test';

test.describe('Tier 1, Tier 2, Tier 3 & Tier 4: Academic UI, Navigation & Interactive Features', () => {
  test.beforeEach(async ({ page }) => {
    await page.goto('/', { waitUntil: 'networkidle' });
  });

  test('T1.1: 7-Chapter Navigation - Verify sidebar chapter links and chapter content switching', async ({ page }) => {
    // Locate chapter links in navigation sidebar
    const chapterLinks = page.locator('aside nav button, aside nav a, nav [role="tab"], [data-testid^="chapter-nav-"]');
    const count = await chapterLinks.count();
    expect(count, 'Should render navigation items for all chapters').toBeGreaterThanOrEqual(1);

    // Click each available chapter link and verify chapter heading changes or updates
    for (let i = 0; i < count; i++) {
      const chapterItem = chapterLinks.nth(i);
      const text = (await chapterItem.innerText()).trim();
      if (text.length > 0 && (await chapterItem.isVisible())) {
        await chapterItem.click().catch(() => {});
        await page.waitForTimeout(100);

        // Verify main content area is updated
        const mainContent = page.locator('main, [role="main"], article, #root');
        await expect(mainContent).toBeVisible();
      }
    }
  });

  test('T1.2: Sidebar Toggle - Mobile drawer opens and closes smoothly', async ({ page }) => {
    // Set viewport to mobile/tablet
    await page.setViewportSize({ width: 768, height: 1024 });

    const menuToggle = page.locator('button[aria-label*="menu" i], button[aria-label*="sidebar" i], [data-testid="sidebar-toggle"], header button:has(svg)').first();
    if (await menuToggle.isVisible()) {
      // Open sidebar
      await menuToggle.click();
      await page.waitForTimeout(200);

      const sidebar = page.locator('aside, [role="navigation"], [data-testid="sidebar"]');
      await expect(sidebar).toBeVisible();

      // Close sidebar (via close button, backdrop, or toggle)
      const closeButton = page.locator('button[aria-label*="close" i], button:has-text("✕"), [data-testid="sidebar-close"]').first();
      if (await closeButton.isVisible()) {
        await closeButton.click();
      } else {
        await menuToggle.click();
      }
      await page.waitForTimeout(200);
    }
  });

  test('T1.3: Reading Progress Indicator - Updates value upon scrolling down the page', async ({ page }) => {
    // Check if progress bar exists
    const progressBar = page.locator('[role="progressbar"], [data-testid="reading-progress"], .reading-progress, header [style*="width"]').first();

    if (await progressBar.isVisible()) {
      // Initial value
      const initialStyle = await progressBar.getAttribute('style');

      // Scroll to middle of the page
      await page.evaluate(() => window.scrollTo(0, document.body.scrollHeight / 2));
      await page.waitForTimeout(200);

      const scrolledStyle = await progressBar.getAttribute('style');
      expect(initialStyle).not.toBe(scrolledStyle);

      // Scroll to bottom
      await page.evaluate(() => window.scrollTo(0, document.body.scrollHeight));
      await page.waitForTimeout(200);
    }
  });

  test('T1.4: Instant Fuzzy Search Modal - Ctrl+K trigger, input query matching and result list', async ({ page }) => {
    // Trigger via keyboard shortcut Ctrl+K
    await page.keyboard.press('Control+KeyK');
    await page.waitForTimeout(200);

    let searchModal = page.locator('[role="dialog"], [data-testid="search-modal"], .search-modal');
    if (!(await searchModal.isVisible())) {
      // Fallback: Click on search trigger button in header
      const searchBtn = page.locator('button:has-text("Tìm kiếm"), input[placeholder*="Tìm"], [aria-label*="search" i]').first();
      if (await searchBtn.isVisible()) {
        await searchBtn.click();
        await page.waitForTimeout(200);
      }
    }

    const searchInput = page.locator('input[type="search"], input[placeholder*="tìm" i], input[role="combobox"]').first();
    if (await searchInput.isVisible()) {
      // Type academic search term
      await searchInput.fill('Kronecker');
      await page.waitForTimeout(200);

      // Verify search results appear
      const results = page.locator('[role="listbox"] [role="option"], .search-result, [data-testid="search-result-item"]');
      const count = await results.count();
      expect(count, 'Fuzzy search should return results for "Kronecker"').toBeGreaterThanOrEqual(1);

      // Close modal with Escape
      await page.keyboard.press('Escape');
      await page.waitForTimeout(100);
    }
  });

  test('T1.5: Collapsible Worked Examples - Expanding and collapsing step-by-step solutions', async ({ page }) => {
    const exampleAccordions = page.locator('summary, button[aria-expanded], [data-testid^="example-step-toggle"]');
    const count = await exampleAccordions.count();

    if (count > 0) {
      const firstAccordion = exampleAccordions.first();
      // Expand
      await firstAccordion.click();
      await page.waitForTimeout(150);

      // Verify step-by-step solution text or KaTeX elements inside become visible
      const solutionContent = page.locator('.solution-steps, [data-testid="solution-content"], details[open]');
      await expect(solutionContent.first()).toBeVisible();

      // Collapse again
      await firstAccordion.click();
      await page.waitForTimeout(150);
    }
  });

  test('T1.6: Cognitive Trap Alert Callouts - Verify warning badges and remediation rules', async ({ page }) => {
    // Locate pitfall callout boxes
    const trapCallouts = page.locator('[data-testid^="pitfall-"], .pitfall-card, .callout-trap, [class*="border-amber"], [class*="border-rose"], [class*="border-red"]');
    const count = await trapCallouts.count();

    if (count > 0) {
      const firstTrap = trapCallouts.first();
      await expect(firstTrap).toBeVisible();

      const trapText = await firstTrap.innerText();
      // Expect characteristic keywords from spec
      const hasKeywords =
        trapText.includes('Bẫy') ||
        trapText.includes('Sai lầm') ||
        trapText.includes('Phản ví dụ') ||
        trapText.includes('Ngộ nhận') ||
        trapText.includes('Quy tắc');

      expect(hasKeywords, 'Cognitive trap callout should contain pedagogical alert indicators').toBeTruthy();
    }
  });

  test('T1.7: 4 Master Synthesis Tables - Verify presence and structure of comparison matrices', async ({ page }) => {
    // Check tables rendered in the application
    const tables = page.locator('table, [role="table"], [data-testid^="master-table"]');
    const tableCount = await tables.count();

    if (tableCount > 0) {
      const firstTable = tables.first();
      await expect(firstTable).toBeVisible();

      // Ensure headers exist
      const headers = firstTable.locator('th, [role="columnheader"]');
      expect(await headers.count()).toBeGreaterThan(0);
    }
  });

  test('T2.1: Boundary - Fuzzy search with unaccented Vietnamese queries matches accented content', async ({ page }) => {
    const searchTrigger = page.locator('button:has-text("Tìm kiếm"), input[placeholder*="Tìm"], [aria-label*="search" i]').first();
    if (await searchTrigger.isVisible()) {
      await searchTrigger.click();
      await page.waitForTimeout(150);

      const searchInput = page.locator('input[type="search"], input[placeholder*="tìm" i], input[role="combobox"]').first();
      if (await searchInput.isVisible()) {
        // Unaccented query
        await searchInput.fill('dinh thuc');
        await page.waitForTimeout(200);

        const results = page.locator('[role="listbox"] [role="option"], .search-result, [data-testid="search-result-item"]');
        const count = await results.count();
        expect(count, 'Search for unaccented "dinh thuc" should return accented "Định thức" results').toBeGreaterThanOrEqual(1);

        await page.keyboard.press('Escape');
      }
    }
  });

  test('T2.2: Boundary - Fuzzy search graceful handling for non-matching gibberish', async ({ page }) => {
    const searchTrigger = page.locator('button:has-text("Tìm kiếm"), input[placeholder*="Tìm"], [aria-label*="search" i]').first();
    if (await searchTrigger.isVisible()) {
      await searchTrigger.click();
      await page.waitForTimeout(150);

      const searchInput = page.locator('input[type="search"], input[placeholder*="tìm" i], input[role="combobox"]').first();
      if (await searchInput.isVisible()) {
        await searchInput.fill('xyzqwe987nonexistentterm');
        await page.waitForTimeout(200);

        // Assert empty state or 0 results message
        const emptyMessage = page.locator(':has-text("Không tìm thấy"), :has-text("No results"), [data-testid="search-empty"]');
        await expect(emptyMessage.first()).toBeVisible();

        await page.keyboard.press('Escape');
      }
    }
  });

  test('T3.1: Cross-Feature - Search result selection navigates directly to target section and opens solution', async ({ page }) => {
    const searchTrigger = page.locator('button:has-text("Tìm kiếm"), input[placeholder*="Tìm"], [aria-label*="search" i]').first();
    if (await searchTrigger.isVisible()) {
      await searchTrigger.click();
      await page.waitForTimeout(150);

      const searchInput = page.locator('input[type="search"], input[placeholder*="tìm" i], input[role="combobox"]').first();
      if (await searchInput.isVisible()) {
        await searchInput.fill('Kronecker');
        await page.waitForTimeout(200);

        const firstResult = page.locator('[role="listbox"] [role="option"], .search-result, [data-testid="search-result-item"]').first();
        if (await firstResult.isVisible()) {
          await firstResult.click();
          await page.waitForTimeout(300);

          // URL hash or active section should reflect navigation
          const currentUrl = page.url();
          expect(currentUrl.length).toBeGreaterThan(0);
        }
      }
    }
  });

  // TIER 4: Real-World Academic Workload User Scenarios
  test('T4.1: Scenario 1 - Student studying Kronecker-Capelli theorem and parameter m discussion', async ({ page }) => {
    // Step 1: Navigate to Systems of Linear Equations (Chapter 5)
    const menuToggle = page.locator('button[aria-label*="menu" i], button[aria-label*="sidebar" i], [data-testid="sidebar-toggle"], header button:has(svg)').first();
    if (await menuToggle.isVisible()) {
      await menuToggle.click();
      await page.waitForTimeout(200);
    }

    const ch5Nav = page.locator('aside nav button:has-text("Hệ phương trình"), aside nav a:has-text("Hệ phương trình"), [data-testid="chapter-nav-ch5"], aside nav button:has-text("Chương 5")').first();
    if (await ch5Nav.isVisible()) {
      await ch5Nav.click();
      await page.waitForTimeout(200);
    }

    // Step 2: Verify Kronecker-Capelli section is rendered
    const bodyText = await page.locator('main, [role="main"], article').innerText();
    expect(bodyText.includes('Kronecker') || bodyText.includes('Hạng') || bodyText.includes('nghiệm')).toBeTruthy();

    // Step 3: Expand worked example on parameter m
    const exampleToggle = page.locator('summary:has-text("Ví dụ"), button:has-text("Ví dụ"), [data-testid^="example-"]').first();
    if (await exampleToggle.isVisible()) {
      await exampleToggle.click();
      await page.waitForTimeout(150);
    }

    // Step 4: Verify KaTeX matrices and formulas in the solution
    const matrices = page.locator('.katex .matrix, .katex .pmatrix, .katex');
    expect(await matrices.count()).toBeGreaterThan(0);
  });

  test('T4.2: Scenario 2 - Researcher reviewing 6-tier algebraic hierarchy from semigroup to field', async ({ page }) => {
    // Step 1: Navigate to Abstract Algebra Structures (Chapter 2)
    const menuToggle = page.locator('button[aria-label*="menu" i], button[aria-label*="sidebar" i], [data-testid="sidebar-toggle"], header button:has(svg)').first();
    if (await menuToggle.isVisible()) {
      await menuToggle.click();
      await page.waitForTimeout(200);
    }

    const ch2Nav = page.locator('aside nav button:has-text("Nửa nhóm"), aside nav button:has-text("Cấu trúc đại số"), [data-testid="chapter-nav-ch2"], aside nav button:has-text("Chương 2")').first();
    if (await ch2Nav.isVisible()) {
      await ch2Nav.click();
      await page.waitForTimeout(200);
    }

    // Step 2: Verify 6-tier hierarchy elements
    const pageText = await page.locator('body').innerText();
    const tiers = ['Nửa nhóm', 'Monoid', 'Nhóm', 'Vành', 'Trường'];
    let matchedTiers = 0;
    for (const tier of tiers) {
      if (pageText.includes(tier)) matchedTiers++;
    }
    expect(matchedTiers, 'Should contain core algebraic hierarchy terms').toBeGreaterThanOrEqual(2);
  });

  test('T4.3: Scenario 3 - Student examining Viète higher-degree alternating sign rule (-1)^k', async ({ page }) => {
    // Step 1: Navigate to Complex Numbers & Polynomials (Chapter 3)
    const menuToggle = page.locator('button[aria-label*="menu" i], button[aria-label*="sidebar" i], [data-testid="sidebar-toggle"], header button:has(svg)').first();
    if (await menuToggle.isVisible()) {
      await menuToggle.click();
      await page.waitForTimeout(200);
    }

    const ch3Nav = page.locator('aside nav button:has-text("Số phức"), aside nav button:has-text("Đa thức"), [data-testid="chapter-nav-ch3"], aside nav button:has-text("Chương 3")').first();
    if (await ch3Nav.isVisible()) {
      await ch3Nav.click();
      await page.waitForTimeout(200);
    }

    // Step 2: Search or verify Viète theorem content
    const pageText = await page.locator('body').innerText();
    expect(pageText.includes('Viète') || pageText.includes('nghiệm') || pageText.includes('bậc cao') || pageText.includes('Moivre')).toBeTruthy();
  });

  test('T4.4: Scenario 4 - Full document fuzzy search for "định thức ma trận phản xứng cấp lẻ"', async ({ page }) => {
    const searchTrigger = page.locator('button:has-text("Tìm kiếm"), input[placeholder*="Tìm"], [aria-label*="search" i]').first();
    if (await searchTrigger.isVisible()) {
      await searchTrigger.click();
      await page.waitForTimeout(150);

      const searchInput = page.locator('input[type="search"], input[placeholder*="tìm" i], input[role="combobox"]').first();
      if (await searchInput.isVisible()) {
        await searchInput.fill('phản xứng');
        await page.waitForTimeout(250);

        const results = page.locator('[role="listbox"] [role="option"], .search-result, [data-testid="search-result-item"]');
        const count = await results.count();
        expect(count, 'Should return results for skew-symmetric matrices').toBeGreaterThanOrEqual(1);

        await page.keyboard.press('Escape');
      }
    }
  });

  test('T4.5: Scenario 5 - Mobile learner accessing worked examples on smartphone (375x812)', async ({ page }) => {
    await page.setViewportSize({ width: 375, height: 812 });
    await page.goto('/', { waitUntil: 'networkidle' });

    // Ensure zero horizontal body overflow on mobile
    const horizontalOverflow = await page.evaluate(() => {
      return document.documentElement.scrollWidth > window.innerWidth;
    });
    expect(horizontalOverflow, 'Mobile layout must have 0 horizontal body scroll overflow').toBeFalsy();

    // Open an example accordion if present
    const example = page.locator('summary, button[aria-expanded]').first();
    if (await example.isVisible()) {
      await example.click();
      await page.waitForTimeout(150);
      await expect(example).toBeVisible();
    }
  });
});
