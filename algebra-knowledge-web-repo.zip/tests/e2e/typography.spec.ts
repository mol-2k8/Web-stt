import { test, expect, Page } from '@playwright/test';

test.describe('Tier 1 & Tier 2: Vietnamese Typography, Unicode NFC & Zero-Tofu Integrity', () => {
  // Helper to extract visible text excluding script, style, and svg elements
  async function extractRenderedTexts(page: Page): Promise<{ tag: string; text: string; selector: string }[]> {
    return await page.evaluate(() => {
      const elements = Array.from(
        document.querySelectorAll('h1, h2, h3, h4, h5, h6, p, li, blockquote, dt, dd, td, th, [role="article"]')
      );
      return elements.map((el, index) => ({
        tag: el.tagName.toLowerCase(),
        text: (el as HTMLElement).innerText || '',
        selector: `${el.tagName.toLowerCase()}:nth-of-type(${index + 1})`,
      })).filter((item) => item.text.trim().length > 0);
    });
  }

  test('T1.1: Assert 0 tofu characters (□ \\u25A1 or replacement character \\uFFFD) in entire DOM', async ({ page }) => {
    await page.goto('/', { waitUntil: 'networkidle' });

    const tofuScan = await page.evaluate(() => {
      const bodyText = document.body.innerText;
      const issues: { char: string; codePoint: string; context: string }[] = [];

      for (let i = 0; i < bodyText.length; i++) {
        const char = bodyText[i];
        const code = char.charCodeAt(0);

        // Check Unicode replacement char (U+FFFD)
        if (code === 0xfffd) {
          const start = Math.max(0, i - 15);
          const end = Math.min(bodyText.length, i + 15);
          issues.push({
            char: 'Replacement Char \\uFFFD',
            codePoint: 'U+FFFD',
            context: bodyText.slice(start, end),
          });
        }

        // Check white square tofu (U+25A1)
        if (code === 0x25a1) {
          const start = Math.max(0, i - 15);
          const end = Math.min(bodyText.length, i + 15);
          issues.push({
            char: 'Tofu Square \\u25A1',
            codePoint: 'U+25A1',
            context: bodyText.slice(start, end),
          });
        }

        // Check Private Use Area (PUA) unmapped bullets: U+E000 to U+F8FF
        if (code >= 0xe000 && code <= 0xf8ff) {
          const start = Math.max(0, i - 15);
          const end = Math.min(bodyText.length, i + 15);
          issues.push({
            char: 'Untranslated PUA char',
            codePoint: `U+${code.toString(16).toUpperCase()}`,
            context: bodyText.slice(start, end),
          });
        }
      }

      return issues;
    });

    expect(
      tofuScan,
      `Found tofu or corrupted glyphs in rendered text: \n${JSON.stringify(tofuScan, null, 2)}`
    ).toHaveLength(0);
  });

  test('T1.2: Assert Vietnamese text is 100% Unicode Normalization Form C (NFC)', async ({ page }) => {
    await page.goto('/', { waitUntil: 'networkidle' });

    const renderedTexts = await extractRenderedTexts(page);
    expect(renderedTexts.length).toBeGreaterThan(0);

    const nonNfcViolations: { tag: string; preview: string; nfcDiff: string }[] = [];

    for (const item of renderedTexts) {
      const rawText = item.text;
      const normalizedNFC = rawText.normalize('NFC');

      if (rawText !== normalizedNFC) {
        nonNfcViolations.push({
          tag: item.tag,
          preview: rawText.slice(0, 50),
          nfcDiff: `Length raw: ${rawText.length} vs NFC: ${normalizedNFC.length}`,
        });
      }
    }

    expect(
      nonNfcViolations,
      `Found non-NFC normalized text segments (decomposed diacritics): \n${JSON.stringify(
        nonNfcViolations,
        null,
        2
      )}`
    ).toHaveLength(0);
  });

  test('T1.3: Verify accurate presence and rendering of complex Vietnamese compound diacritics', async ({ page }) => {
    await page.goto('/', { waitUntil: 'networkidle' });

    const complexDiacritics = [
      { char: 'ế', name: 'e + mũ + sắc', sampleWords: ['thực tế', 'tiền đề', 'tập hợp', 'mệnh đề'] },
      { char: 'ệ', name: 'e + mũ + nặng', sampleWords: ['hệ phương trình', 'nghiệm', 'quan hệ', 'tuyến tính'] },
      { char: 'ẩ', name: 'a + mũ + hỏi', sampleWords: ['chuẩn', 'chuẩn tắc'] },
      { char: 'ộ', name: 'o + mũ + nặng', sampleWords: ['cộng', 'tập hợp', 'bội số', 'toàn bộ'] },
      { char: 'Ứ', name: 'Ư hoa + sắc', sampleWords: ['Ứng dụng', 'Ứng với'] },
      { char: 'đ', name: 'chữ đ thường', sampleWords: ['đại số', 'định thức', 'đồng cấu', 'đẳng cấu'] },
    ];

    const bodyText = await page.locator('body').innerText();

    for (const diacritic of complexDiacritics) {
      const containsChar = bodyText.includes(diacritic.char) || bodyText.toLowerCase().includes(diacritic.char.toLowerCase());
      expect(
        containsChar,
        `Academic content must contain Vietnamese diacritic: ${diacritic.char} (${diacritic.name})`
      ).toBeTruthy();
    }
  });

  test('T1.4: Verify KaTeX math formula rendering integrity (0 parse errors, 0 raw LaTeX leakage)', async ({ page }) => {
    await page.goto('/', { waitUntil: 'networkidle' });

    // KaTeX should render with .katex class
    const katexElements = page.locator('.katex');
    const katexCount = await katexElements.count();
    expect(katexCount, 'Math expressions should be rendered via KaTeX engine').toBeGreaterThan(0);

    // Assert KaTeX error fallback is absent (KaTeX inserts .katex-error on parse failure)
    const katexErrors = page.locator('.katex-error');
    const errorCount = await katexErrors.count();
    if (errorCount > 0) {
      const errorTexts = await katexErrors.allInnerTexts();
      expect(
        errorCount,
        `Found KaTeX parsing errors on page: \n${errorTexts.join('\n')}`
      ).toBe(0);
    }

    // Assert absence of unparsed raw LaTeX commands visible in readable text
    const pageText = await page.locator('main, [role="main"], article, #root').innerText();
    const rawLatexPatterns = [
      /\\begin\{pmatrix\}/,
      /\\begin\{cases\}/,
      /\\begin\{vmatrix\}/,
      /\\frac\{/,
      /\\mathbb\{R\}/,
      /\\mathbb\{C\}/,
      /\\det\(/,
      /\\ker\(/,
    ];

    for (const pattern of rawLatexPatterns) {
      const match = pageText.match(pattern);
      expect(
        match,
        `Detected unparsed raw LaTeX code leaking into visible UI: ${pattern}`
      ).toBeNull();
    }
  });

  test('T1.5: Verify Blackboard Bold math symbols (ℝ, ℂ, ℤ, ℚ, ℕ) render correctly', async ({ page }) => {
    await page.goto('/', { waitUntil: 'networkidle' });

    const mathbbSymbols = await page.evaluate(() => {
      const katexNodes = Array.from(document.querySelectorAll('.katex, .katex-display, .katex-html'));
      const text = katexNodes.map((n) => (n as HTMLElement).innerText).join(' ');
      return {
        hasR: text.includes('ℝ') || text.includes('R'),
        hasC: text.includes('ℂ') || text.includes('C'),
        hasZ: text.includes('ℤ') || text.includes('Z'),
      };
    });

    expect(mathbbSymbols.hasR || mathbbSymbols.hasC || mathbbSymbols.hasZ).toBeTruthy();
  });

  test('T2.1: Boundary - Scan typography across all 7 individual chapters sequentially', async ({ page }) => {
    await page.goto('/', { waitUntil: 'networkidle' });

    const chapterLinks = page.locator('aside nav button, aside nav a, nav [role="tab"], [data-testid^="chapter-nav-"]');
    const count = await chapterLinks.count();

    for (let i = 0; i < count; i++) {
      const item = chapterLinks.nth(i);
      if (await item.isVisible()) {
        await item.click().catch(() => {});
        await page.waitForTimeout(100);
      }

      const tofuCheck = await page.evaluate(() => {
        const text = document.body.innerText;
        return text.includes('\uFFFD') || text.includes('\u25A1');
      });

      expect(tofuCheck, `Chapter index ${i} should have zero tofu characters`).toBeFalsy();
    }
  });

  test('T2.2: Boundary - Check font-family computed styles on headings and math text', async ({ page }) => {
    await page.goto('/', { waitUntil: 'networkidle' });

    const fontStyles = await page.evaluate(() => {
      const heading = document.querySelector('h1, h2');
      const paragraph = document.querySelector('p');
      const mathText = document.querySelector('.katex .text');

      return {
        headingFont: heading ? window.getComputedStyle(heading).fontFamily : '',
        pFont: paragraph ? window.getComputedStyle(paragraph).fontFamily : '',
        mathTextFont: mathText ? window.getComputedStyle(mathText).fontFamily : '',
      };
    });

    expect(
      fontStyles.headingFont.toLowerCase().includes('vietnam') ||
      fontStyles.headingFont.toLowerCase().includes('sans-serif') ||
      fontStyles.headingFont.toLowerCase().includes('inter')
    ).toBeTruthy();

    expect(
      fontStyles.pFont.toLowerCase().includes('vietnam') ||
      fontStyles.pFont.toLowerCase().includes('sans-serif') ||
      fontStyles.pFont.toLowerCase().includes('inter')
    ).toBeTruthy();
  });

  test('T2.3: Boundary - Ensure line-height prevents Vietnamese diacritic clipping on headings', async ({ page }) => {
    await page.goto('/', { waitUntil: 'networkidle' });

    const clippingChecks = await page.evaluate(() => {
      const headings = Array.from(document.querySelectorAll('h1, h2, h3'));
      return headings.map((h) => {
        const style = window.getComputedStyle(h);
        const fontSize = parseFloat(style.fontSize);
        const lineHeight = parseFloat(style.lineHeight) || fontSize * 1.2;
        return {
          tag: h.tagName,
          fontSize,
          lineHeight,
          ratio: lineHeight / fontSize,
        };
      });
    });

    for (const check of clippingChecks) {
      // Vietnamese compound diacritics require line-height >= 1.15 to avoid ascender clipping
      expect(
        check.ratio,
        `Line height ratio for ${check.tag} should be >= 1.1 to prevent diacritic clipping`
      ).toBeGreaterThanOrEqual(1.1);
    }
  });
});
