import { test, expect, Response } from '@playwright/test';

test.describe('Tier 1 & Tier 2: WOFF2/WOFF Font Loading, MIME Types & CORS Compliance', () => {
  test('T1.1: Intercept .woff2 font requests and assert HTTP 200, Content-Type and CORS headers', async ({ page }) => {
    const interceptedFontResponses: Response[] = [];

    page.on('response', (response) => {
      const url = response.url();
      if (url.includes('.woff2') || url.includes('.woff')) {
        interceptedFontResponses.push(response);
      }
    });

    const response = await page.goto('/', { waitUntil: 'networkidle' });
    expect(response?.status()).toBe(200);

    // Expect at least one primary web font was loaded
    expect(interceptedFontResponses.length).toBeGreaterThan(0);

    for (const fontRes of interceptedFontResponses) {
      const url = fontRes.url();
      const status = fontRes.status();
      const headers = fontRes.headers();

      // Assert HTTP 200 OK (or 304 if cached)
      expect([200, 304], `Font ${url} returned status ${status}`).toContain(status);

      // Assert RFC 8081 standard MIME type for WOFF2
      if (url.endsWith('.woff2')) {
        const contentType = headers['content-type'] || '';
        expect(
          contentType.includes('font/woff2') || contentType.includes('application/font-woff2'),
          `Font ${url} should have MIME font/woff2, got: ${contentType}`
        ).toBeTruthy();
      } else if (url.endsWith('.woff')) {
        const contentType = headers['content-type'] || '';
        expect(
          contentType.includes('font/woff') || contentType.includes('application/font-woff') || contentType.includes('application/x-font-woff'),
          `Font ${url} should have MIME font/woff, got: ${contentType}`
        ).toBeTruthy();
      }

      // Assert Access-Control-Allow-Origin: *
      const corsHeader = headers['access-control-allow-origin'];
      expect(
        corsHeader,
        `Font ${url} is missing CORS Access-Control-Allow-Origin header`
      ).toBeDefined();
      expect(
        corsHeader === '*' || corsHeader?.includes('localhost') || corsHeader?.includes('127.0.0.1'),
        `CORS header should allow cross-origin or localhost, got: ${corsHeader}`
      ).toBeTruthy();
    }
  });

  test('T1.2: Verify document.fonts.ready and document.fonts.status === "loaded"', async ({ page }) => {
    await page.goto('/', { waitUntil: 'networkidle' });

    // Wait for FontFaceSet promise to resolve
    const fontStatus = await page.evaluate(async () => {
      await document.fonts.ready;
      return {
        status: document.fonts.status,
        size: document.fonts.size,
      };
    });

    expect(fontStatus.status).toBe('loaded');
    expect(fontStatus.size).toBeGreaterThan(0);
  });

  test('T1.3: Verify document.fonts.check() for primary BeVietnamPro font weights', async ({ page }) => {
    await page.goto('/', { waitUntil: 'networkidle' });
    await page.evaluate(async () => await document.fonts.ready);

    const weightsToCheck = [
      { name: 'Regular 400', spec: '400 16px BeVietnamPro, "Be Vietnam Pro"' },
      { name: 'SemiBold 600', spec: '600 16px BeVietnamPro, "Be Vietnam Pro"' },
      { name: 'Bold 700', spec: '700 16px BeVietnamPro, "Be Vietnam Pro"' },
    ];

    for (const { name, spec } of weightsToCheck) {
      const isLoaded = await page.evaluate((fontSpec) => {
        return (
          document.fonts.check(fontSpec) ||
          document.fonts.check(`16px BeVietnamPro`) ||
          document.fonts.check(`16px "Be Vietnam Pro"`)
        );
      }, spec);

      expect(isLoaded, `Font weight ${name} (${spec}) should be loaded and recognized by browser`).toBeTruthy();
    }
  });

  test('T1.4: Verify HTML head contains font preloads with crossorigin attribute', async ({ page }) => {
    await page.goto('/');

    const preloads = await page.evaluate(() => {
      const links = Array.from(document.querySelectorAll('link[rel="preload"][as="font"]'));
      return links.map((link) => ({
        href: link.getAttribute('href'),
        type: link.getAttribute('type'),
        crossorigin: link.getAttribute('crossorigin'),
      }));
    });

    // If preloads are defined in index.html, verify their correctness
    if (preloads.length > 0) {
      for (const preload of preloads) {
        expect(preload.href).toBeTruthy();
        expect(preload.type).toBe('font/woff2');
        expect(
          preload.crossorigin === '' || preload.crossorigin === 'anonymous',
          `Preload ${preload.href} must have crossorigin="anonymous" or empty attribute`
        ).toBeTruthy();
      }
    }
  });

  test('T1.5: Verify CSS @font-face rules declare font-display: swap', async ({ page }) => {
    await page.goto('/', { waitUntil: 'networkidle' });

    const fontFaceRules = await page.evaluate(() => {
      const results: { family: string; fontDisplay?: string }[] = [];
      for (const sheet of Array.from(document.styleSheets)) {
        try {
          for (const rule of Array.from(sheet.cssRules || [])) {
            if (rule instanceof CSSFontFaceRule) {
              results.push({
                family: rule.style.fontFamily,
                fontDisplay: rule.style.getPropertyValue('font-display'),
              });
            }
          }
        } catch {
          // Cross-origin stylesheet access restriction if any
        }
      }
      return results;
    });

    if (fontFaceRules.length > 0) {
      for (const rule of fontFaceRules) {
        if (rule.family.includes('BeVietnam') || rule.family.includes('Be Vietnam')) {
          expect(
            rule.fontDisplay === 'swap' || rule.fontDisplay === 'optional',
            `Font family ${rule.family} must specify font-display: swap, got: ${rule.fontDisplay}`
          ).toBeTruthy();
        }
      }
    }
  });

  test('T2.1: Boundary - Font glyph check for full 73 Vietnamese precomposed NFC characters', async ({ page }) => {
    await page.goto('/', { waitUntil: 'networkidle' });
    await page.evaluate(async () => await document.fonts.ready);

    // 73 Vietnamese precomposed NFC characters from Document 3.pdf
    const vietnameseSample = 'Á Ô Ý à á â ã è é ê ì í ò ó ô õ ù ú ý ă Đ đ ĩ ũ ơ Ư ư ạ Ả ả ấ ầ ẩ ẫ ậ ắ ằ ẳ ẵ ặ ẹ ẻ ẽ ế ề ể ễ ệ ỉ ị ọ ỏ ố ồ ổ ỗ ộ ớ ờ ở ỡ ợ ụ ủ Ứ ứng ừ sử nữ ự ỳ ỷ ỹ';

    const glyphsVerified = await page.evaluate((text) => {
      // document.fonts.check with text parameter tests glyph coverage
      const testCases = [
        `16px BeVietnamPro`,
        `16px "Be Vietnam Pro"`,
      ];
      return testCases.some((font) => {
        try {
          return document.fonts.check(font, text);
        } catch {
          return false;
        }
      });
    }, vietnameseSample);

    // If browser supports glyph-level check
    expect(glyphsVerified).toBeTruthy();
  });

  test('T2.2: Boundary - Font glyph check for mathematical operators and Blackboard Bold symbols', async ({ page }) => {
    await page.goto('/', { waitUntil: 'networkidle' });
    await page.evaluate(async () => await document.fonts.ready);

    const mathSymbolsSample = 'ℝ ℂ ℤ ℚ ℕ ∈ ∉ ⊂ ⊆ ∩ ∪ ∑ ∏ √ ≠ ≤ ≥ ↔ → λ σ ε';

    const mathGlyphsSupported = await page.evaluate((text) => {
      return (
        document.fonts.check('16px BeVietnamPro, KaTeX_Main, sans-serif', text) ||
        document.fonts.check('16px "Be Vietnam Pro", sans-serif', text)
      );
    }, mathSymbolsSample);

    expect(mathGlyphsSupported).toBeTruthy();
  });

  test('T2.3: Boundary - Cache-Control header presence for optimized font assets', async ({ page }) => {
    const fontHeaders: Record<string, string>[] = [];

    page.on('response', (response) => {
      if (response.url().includes('/fonts/')) {
        fontHeaders.push(response.headers());
      }
    });

    await page.goto('/', { waitUntil: 'networkidle' });

    for (const headerMap of fontHeaders) {
      const cacheControl = headerMap['cache-control'] || '';
      // Fonts should have caching directives
      expect(
        cacheControl.includes('max-age') || cacheControl.includes('public') || cacheControl.includes('immutable'),
        `Font response should include Cache-Control directive, got: ${cacheControl}`
      ).toBeTruthy();
    }
  });

  test('T3.1: Cross-Feature - Zero redundant font refetch during chapter navigation', async ({ page }) => {
    await page.goto('/', { waitUntil: 'networkidle' });

    let fontFetchCountAfterInitialLoad = 0;
    page.on('request', (req) => {
      if (req.url().includes('.woff2') || req.url().includes('.woff')) {
        fontFetchCountAfterInitialLoad++;
      }
    });

    // Navigate across chapters
    const chapterButtons = page.locator('nav button, aside nav a, [role="tab"]');
    const count = await chapterButtons.count();

    if (count > 1) {
      for (let i = 0; i < Math.min(count, 5); i++) {
        const btn = chapterButtons.nth(i);
        if (await btn.isVisible()) {
          await btn.click().catch(() => {});
          await page.waitForTimeout(100);
        }
      }
    }

    // Cached/subsetted fonts should not cause continuous network re-fetching
    expect(fontFetchCountAfterInitialLoad).toBe(0);
  });
});
