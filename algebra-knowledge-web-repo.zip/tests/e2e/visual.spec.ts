import { test, expect } from '@playwright/test';
import fs from 'fs';
import path from 'path';

test.describe('Tier 1 & Tier 2: Multi-Viewport Visual Rendering & Screenshot Captures', () => {
  const screenshotsDir = path.resolve('test-results/screenshots');

  test.beforeAll(async () => {
    if (!fs.existsSync(screenshotsDir)) {
      fs.mkdirSync(screenshotsDir, { recursive: true });
    }
  });

  const viewports = [
    { name: 'desktop-1920x1080', width: 1920, height: 1080 },
    { name: 'laptop-1440x900', width: 1440, height: 900 },
    { name: 'tablet-768x1024', width: 768, height: 1024 },
    { name: 'mobile-375x812', width: 375, height: 812 },
  ];

  for (const vp of viewports) {
    test(`Visual capture across ${vp.name} viewport`, async ({ page }) => {
      await page.setViewportSize({ width: vp.width, height: vp.height });
      await page.goto('/', { waitUntil: 'networkidle' });
      await page.evaluate(async () => await document.fonts.ready);

      const filePath = path.join(screenshotsDir, `fullpage-${vp.name}.png`);
      await page.screenshot({
        path: filePath,
        fullPage: true,
      });

      expect(fs.existsSync(filePath), `Screenshot ${filePath} should be generated`).toBeTruthy();
      const stats = fs.statSync(filePath);
      expect(stats.size, `Screenshot ${filePath} should not be empty`).toBeGreaterThan(1000);
    });
  }

  test('Component capture: KaTeX mathematical formulas & matrices', async ({ page }) => {
    await page.setViewportSize({ width: 1440, height: 900 });
    await page.goto('/', { waitUntil: 'networkidle' });
    await page.evaluate(async () => await document.fonts.ready);

    const mathBlock = page.locator('.katex-display, .katex').first();
    if (await mathBlock.isVisible()) {
      const filePath = path.join(screenshotsDir, 'component-math-formula.png');
      await mathBlock.screenshot({ path: filePath });
      expect(fs.existsSync(filePath)).toBeTruthy();
    }
  });

  test('Component capture: Expanded worked example solution', async ({ page }) => {
    await page.setViewportSize({ width: 1440, height: 900 });
    await page.goto('/', { waitUntil: 'networkidle' });

    const example = page.locator('summary, button[aria-expanded], [data-testid^="example-"]').first();
    if (await example.isVisible()) {
      await example.click();
      await page.waitForTimeout(200);

      const card = page.locator('.example-card, details[open], [data-testid^="example-card"]').first();
      const target = (await card.isVisible()) ? card : example;

      const filePath = path.join(screenshotsDir, 'component-worked-example-expanded.png');
      await target.screenshot({ path: filePath });
      expect(fs.existsSync(filePath)).toBeTruthy();
    }
  });

  test('Component capture: Cognitive trap warning callout badge', async ({ page }) => {
    await page.setViewportSize({ width: 1440, height: 900 });
    await page.goto('/', { waitUntil: 'networkidle' });

    const callout = page.locator('.pitfall-card, .callout-trap, [data-testid^="pitfall-"], [class*="border-amber"], [class*="border-rose"]').first();
    if (await callout.isVisible()) {
      const filePath = path.join(screenshotsDir, 'component-cognitive-trap.png');
      await callout.screenshot({ path: filePath });
      expect(fs.existsSync(filePath)).toBeTruthy();
    }
  });

  test('Component capture: Instant fuzzy search modal with results', async ({ page }) => {
    await page.setViewportSize({ width: 1440, height: 900 });
    await page.goto('/', { waitUntil: 'networkidle' });

    const searchBtn = page.locator('button:has-text("Tìm kiếm"), input[placeholder*="Tìm"], [aria-label*="search" i]').first();
    if (await searchBtn.isVisible()) {
      await searchBtn.click();
      await page.waitForTimeout(150);

      const searchInput = page.locator('input[type="search"], input[placeholder*="tìm" i], input[role="combobox"]').first();
      if (await searchInput.isVisible()) {
        await searchInput.fill('Kronecker');
        await page.waitForTimeout(200);

        const modal = page.locator('[role="dialog"], [data-testid="search-modal"], .search-modal').first();
        const target = (await modal.isVisible()) ? modal : page;

        const filePath = path.join(screenshotsDir, 'component-search-modal-active.png');
        await target.screenshot({ path: filePath });
        expect(fs.existsSync(filePath)).toBeTruthy();

        await page.keyboard.press('Escape');
      }
    }
  });

  test('Component capture: Master synthesis comparison table', async ({ page }) => {
    await page.setViewportSize({ width: 1440, height: 900 });
    await page.goto('/', { waitUntil: 'networkidle' });

    const table = page.locator('table, [role="table"], [data-testid^="master-table"]').first();
    if (await table.isVisible()) {
      const filePath = path.join(screenshotsDir, 'component-master-table.png');
      await table.screenshot({ path: filePath });
      expect(fs.existsSync(filePath)).toBeTruthy();
    }
  });
});
