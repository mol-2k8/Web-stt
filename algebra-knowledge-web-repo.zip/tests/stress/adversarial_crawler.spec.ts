import { test, expect, Page } from '@playwright/test';

// 73 distinct Vietnamese precomposed NFC accented characters
const VIETNAMESE_73_ACCENTED_CHARS = [
  'Á', 'Ô', 'Ý', 'à', 'á', 'â', 'ã', 'è', 'é', 'ê', 'ì', 'í', 'ò', 'ó', 'ô', 'õ',
  'ù', 'ú', 'ý', 'ă', 'Đ', 'đ', 'ĩ', 'ũ', 'ơ', 'Ư', 'ư', 'ạ', 'Ả', 'ả', 'ấ', 'ầ',
  'ẩ', 'ẫ', 'ậ', 'ắ', 'ằ', 'ẳ', 'ẵ', 'ặ', 'ẹ', 'ẻ', 'ẽ', 'ế', 'ề', 'ể', 'ễ', 'ệ',
  'ỉ', 'ị', 'ọ', 'ỏ', 'ố', 'ồ', 'ổ', 'ỗ', 'ộ', 'ớ', 'ờ', 'ở', 'ỡ', 'ợ', 'ụ', 'ủ',
  'Ứ', 'ứ', 'ừ', 'ử', 'ữ', 'ự', 'ỳ', 'ỷ', 'ỹ'
];

// Helper to sweep all text in a container for tofu, replacement, and PUA characters
interface ScanResult {
  hasTofu: boolean;
  tofuCount: number;
  hasReplacement: boolean;
  replacementCount: number;
  hasPua: boolean;
  puaCount: number;
  violations: Array<{ type: string; char: string; codePoint: string; context: string }>;
  nonNfcViolations: Array<{ preview: string; rawLen: number; nfcLen: number }>;
}

async function scanPageTypography(page: Page, scopeSelector: string = 'body'): Promise<ScanResult> {
  return await page.evaluate((selector) => {
    const root = document.querySelector(selector) || document.body;
    const violations: Array<{ type: string; char: string; codePoint: string; context: string }> = [];
    const nonNfcViolations: Array<{ preview: string; rawLen: number; nfcLen: number }> = [];

    // Traverse text nodes
    const walker = document.createTreeWalker(root, NodeFilter.SHOW_TEXT, {
      acceptNode(node) {
        // Skip script and style tags
        const parentTag = node.parentElement?.tagName.toLowerCase();
        if (parentTag === 'script' || parentTag === 'style') {
          return NodeFilter.FILTER_REJECT;
        }
        return NodeFilter.FILTER_ACCEPT;
      },
    });

    let node: Node | null;
    let tofuCount = 0;
    let replacementCount = 0;
    let puaCount = 0;

    while ((node = walker.nextNode())) {
      const text = node.textContent || '';
      if (!text.trim()) continue;

      // Check NFC normalization
      const nfc = text.normalize('NFC');
      if (text !== nfc) {
        nonNfcViolations.push({
          preview: text.slice(0, 40),
          rawLen: text.length,
          nfcLen: nfc.length,
        });
      }

      // Check characters
      for (let i = 0; i < text.length; i++) {
        const code = text.charCodeAt(i);

        // U+25A1 White square tofu
        if (code === 0x25a1) {
          tofuCount++;
          const start = Math.max(0, i - 15);
          const end = Math.min(text.length, i + 15);
          violations.push({
            type: 'Tofu \\u25A1',
            char: text[i],
            codePoint: 'U+25A1',
            context: text.slice(start, end),
          });
        }

        // U+FFFD Replacement character
        if (code === 0xfffd) {
          replacementCount++;
          const start = Math.max(0, i - 15);
          const end = Math.min(text.length, i + 15);
          violations.push({
            type: 'Replacement \\uFFFD',
            char: text[i],
            codePoint: 'U+FFFD',
            context: text.slice(start, end),
          });
        }

        // U+E000 - U+F8FF Private Use Area
        if (code >= 0xe000 && code <= 0xf8ff) {
          puaCount++;
          const start = Math.max(0, i - 15);
          const end = Math.min(text.length, i + 15);
          violations.push({
            type: 'PUA Character',
            char: text[i],
            codePoint: `U+${code.toString(16).toUpperCase()}`,
            context: text.slice(start, end),
          });
        }
      }
    }

    return {
      hasTofu: tofuCount > 0,
      tofuCount,
      hasReplacement: replacementCount > 0,
      replacementCount,
      hasPua: puaCount > 0,
      puaCount,
      violations,
      nonNfcViolations,
    };
  }, scopeSelector);
}

test.describe('Adversarial Stress Verification Suite: Typography, Glyph Mapping & Stability', () => {

  test('Stress 1: Tofu, Replacement & PUA Sweep across all 7 Chapters, 30 Examples, 42 Traps & 4 Tables', async ({ page }) => {
    // Collect all console errors
    const consoleErrors: string[] = [];
    page.on('console', (msg) => {
      if (msg.type() === 'error') consoleErrors.push(msg.text());
    });
    page.on('pageerror', (err) => {
      consoleErrors.push(err.message);
    });

    await page.goto('/', { waitUntil: 'networkidle' });

    // Ensure document.fonts.ready
    await page.evaluate(async () => await document.fonts.ready);

    // Get chapter navigation buttons
    const chapterButtons = page.locator('aside nav button[data-testid^="chapter-nav-"]');
    const chapterCount = await chapterButtons.count();
    expect(chapterCount, 'Must find 7 chapter navigation buttons').toBe(7);

    let totalExamplesExpanded = 0;
    let totalPitfallsFound = 0;
    let totalMasterTablesFound = 0;
    const accumulatedTextFound: string[] = [];

    // Traverse all 7 chapters
    for (let c = 0; c < chapterCount; c++) {
      const btn = chapterButtons.nth(c);
      await btn.click();
      await page.waitForTimeout(250);

      // Expand ALL worked examples in this chapter to reveal solutions in DOM
      const exampleToggles = page.locator('button[data-testid^="example-step-toggle-"]');
      const exCount = await exampleToggles.count();
      totalExamplesExpanded += exCount;

      for (let e = 0; e < exCount; e++) {
        const toggle = exampleToggles.nth(e);
        const isExpanded = await toggle.getAttribute('aria-expanded');
        if (isExpanded !== 'true') {
          await toggle.click();
        }
      }

      // Check pitfalls in this chapter
      const pitfalls = page.locator('[data-testid^="pitfall-callout-"]');
      totalPitfallsFound += await pitfalls.count();

      // Check master tables in this chapter
      const tables = page.locator('[data-testid^="master-table-"]');
      totalMasterTablesFound += await tables.count();

      // Run deep typography scan on center content
      const scan = await scanPageTypography(page, 'main, .flex-1.min-w-0');
      expect(scan.violations, `Tofu/PUA violations in Chapter ${c + 1}: ${JSON.stringify(scan.violations, null, 2)}`).toHaveLength(0);
      expect(scan.nonNfcViolations, `Non-NFC text in Chapter ${c + 1}: ${JSON.stringify(scan.nonNfcViolations, null, 2)}`).toHaveLength(0);

      // Verify zero KaTeX render errors
      const katexErrors = await page.locator('.katex-error').count();
      expect(katexErrors, `Found KaTeX errors in Chapter ${c + 1}`).toBe(0);

      // Extract text content for diacritic coverage check
      const chapterText = await page.evaluate(() => document.body.innerText);
      accumulatedTextFound.push(chapterText);
    }

    // Verify inventory counts meet requirements
    console.log(`[Crawl Stats] Expanded Examples: ${totalExamplesExpanded}, Pitfalls: ${totalPitfallsFound}, Master Tables: ${totalMasterTablesFound}`);
    expect(totalExamplesExpanded, 'Must find at least 30 worked examples').toBeGreaterThanOrEqual(30);
    expect(totalPitfallsFound, 'Must find at least 42 cognitive traps').toBeGreaterThanOrEqual(42);
    expect(totalMasterTablesFound, 'Must find 4 master synthesis tables').toBe(4);

    // Verify 0 console errors occurred throughout entire crawl
    expect(consoleErrors, `Console errors detected during crawl: ${consoleErrors.join('\n')}`).toHaveLength(0);
  });

  test('Stress 2: Vietnamese 73-Character Glyph & Diacritic Stress Test (NFC, Clipping & Font Mapping)', async ({ page }) => {
    await page.goto('/', { waitUntil: 'networkidle' });
    await page.evaluate(async () => await document.fonts.ready);

    // 1. Verify BeVietnamPro font handles all 73 accented characters in browser font engine
    const fontCheckResult = await page.evaluate((chars) => {
      const results: Record<string, boolean> = {};
      for (const char of chars) {
        // Test with BeVietnamPro
        const loaded = document.fonts.check(`16px BeVietnamPro`, char);
        results[char] = loaded;
      }
      return results;
    }, VIETNAMESE_73_ACCENTED_CHARS);

    const unsupportedFontChars = Object.entries(fontCheckResult)
      .filter(([_, supported]) => !supported)
      .map(([char]) => char);

    expect(
      unsupportedFontChars,
      `BeVietnamPro font failed document.fonts.check for characters: ${unsupportedFontChars.join(', ')}`
    ).toHaveLength(0);

    // 2. DOM Rendering & Bounding Box Stress Test:
    // Mount all 73 Vietnamese characters in a test container in live DOM and inspect bounding boxes
    const glyphDimensions = await page.evaluate((chars) => {
      const container = document.createElement('div');
      container.id = 'stress-glyph-container';
      container.style.cssText = 'position: absolute; left: -9999px; top: 0; font-family: "BeVietnamPro", sans-serif; font-size: 24px; line-height: 1.5;';
      document.body.appendChild(container);

      const measurements: Array<{
        char: string;
        codePoint: string;
        width: number;
        height: number;
        hasTofu: boolean;
      }> = [];

      for (const ch of chars) {
        const span = document.createElement('span');
        span.textContent = ch;
        span.style.display = 'inline-block';
        container.appendChild(span);

        const rect = span.getBoundingClientRect();
        const code = ch.charCodeAt(0);

        measurements.push({
          char: ch,
          codePoint: `U+${code.toString(16).toUpperCase()}`,
          width: rect.width,
          height: rect.height,
          hasTofu: ch === '\u25A1' || ch === '\uFFFD',
        });
      }

      // Cleanup
      container.remove();
      return measurements;
    }, VIETNAMESE_73_ACCENTED_CHARS);

    // Verify all 73 characters have non-zero width and height (not dropped or zero-sized)
    for (const m of glyphDimensions) {
      expect(m.width, `Glyph ${m.char} (${m.codePoint}) has zero width (dropped)`).toBeGreaterThan(0);
      expect(m.height, `Glyph ${m.char} (${m.codePoint}) has zero height (dropped)`).toBeGreaterThan(0);
      expect(m.hasTofu, `Glyph ${m.char} rendered as tofu or replacement`).toBeFalsy();
    }

    // 3. Heading Diacritic Clipping Prevention Check across all headings in application
    const clippingAudit = await page.evaluate(() => {
      const headings = Array.from(document.querySelectorAll('h1, h2, h3, h4, h5, h6, .katex'));
      const clippingRisks: Array<{
        selector: string;
        text: string;
        fontSize: number;
        lineHeight: number;
        ratio: number;
        overflow: string;
      }> = [];

      for (let i = 0; i < headings.length; i++) {
        const el = headings[i] as HTMLElement;
        const text = el.innerText || '';
        // Check if element contains compound diacritics
        if (/[ếềểễệốồổỗộắằẳẵặứừửữự]/i.test(text)) {
          const style = window.getComputedStyle(el);
          const fontSize = parseFloat(style.fontSize);
          const rawLineHeight = style.lineHeight;
          const lineHeight = rawLineHeight === 'normal' ? fontSize * 1.2 : parseFloat(rawLineHeight);
          const ratio = lineHeight / fontSize;

          // If line-height is cramped (< 1.1) and overflow is hidden, diacritic may be clipped
          if (ratio < 1.1 && style.overflow === 'hidden') {
            clippingRisks.push({
              selector: `${el.tagName.toLowerCase()}:nth-of-type(${i})`,
              text: text.slice(0, 30),
              fontSize,
              lineHeight,
              ratio,
              overflow: style.overflow,
            });
          }
        }
      }
      return clippingRisks;
    });

    expect(
      clippingAudit,
      `Found headings with clipped compound Vietnamese diacritics: ${JSON.stringify(clippingAudit, null, 2)}`
    ).toHaveLength(0);
  });

  test('Stress 3: Search Modal Stress - Instant Fuzzy Search & Special Vietnamese Diacritic Queries', async ({ page }) => {
    await page.goto('/', { waitUntil: 'networkidle' });

    // Open Search Modal via keyboard shortcut Ctrl+K
    await page.keyboard.press('Control+KeyK');
    const searchModal = page.locator('[data-testid="search-modal"]');
    await expect(searchModal).toBeVisible();

    const searchInput = page.locator('[data-testid="search-input"]');
    await expect(searchInput).toBeVisible();

    // Adversarial queries: Vietnamese with complex tone marks, unaccented, math symbols, edge cases
    const testQueries = [
      'ma trận',               // Common Vietnamese
      'ma tran',               // Unaccented search
      'Kronecker-Capelli',     // Mixed dash & Latin
      'định thức',             // Compound diacritic
      'Viète',                 // French/Vietnamese diacritic
      'bẫy ngộ nhận',          // Traps search
      'ℝ',                     // Blackboard bold math symbol
      'xyz123nonexistent!@#',  // Non-matching gibberish
    ];

    for (const query of testQueries) {
      await searchInput.fill(query);
      await page.waitForTimeout(100);

      // Verify no tofu in search results
      const scan = await scanPageTypography(page, '[data-testid="search-modal"]');
      expect(scan.violations, `Tofu in search results for query "${query}": ${JSON.stringify(scan.violations, null, 2)}`).toHaveLength(0);
      expect(scan.nonNfcViolations, `Non-NFC text in search results for query "${query}"`).toHaveLength(0);
    }

    // Close search modal
    await page.keyboard.press('Escape');
    await expect(searchModal).toBeHidden();
  });

  test('Stress 4: Master Comparison Tables Typography & Math Alignment Check', async ({ page }) => {
    await page.goto('/', { waitUntil: 'networkidle' });

    // Navigate to Chapter 1 to check Duality Table
    const ch1Btn = page.locator('button[data-testid="chapter-nav-ch1"]');
    await ch1Btn.click();
    await page.waitForTimeout(200);

    const dualityTable = page.locator('[data-testid="master-table-tbl-duality"]');
    await expect(dualityTable).toBeVisible();

    // Navigate to Chapter 2 to check Hierarchy Table
    const ch2Btn = page.locator('button[data-testid="chapter-nav-ch2"]');
    await ch2Btn.click();
    await page.waitForTimeout(200);

    const hierarchyTable = page.locator('[data-testid="master-table-tbl-hierarchy"]');
    await expect(hierarchyTable).toBeVisible();

    // Navigate to Chapter 5 to check Kronecker-Capelli Table
    const ch5Btn = page.locator('button[data-testid="chapter-nav-ch5"]');
    await ch5Btn.click();
    await page.waitForTimeout(200);

    const kroneckerTable = page.locator('[data-testid="master-table-tbl-kronecker"]');
    await expect(kroneckerTable).toBeVisible();

    // Navigate to Chapter 6 to check Cognitive Traps Table
    const ch6Btn = page.locator('button[data-testid="chapter-nav-ch6"]');
    await ch6Btn.click();
    await page.waitForTimeout(200);

    const trapsTable = page.locator('[data-testid="master-table-tbl-traps"]');
    await expect(trapsTable).toBeVisible();

    // Scan table typography
    const tableScan = await scanPageTypography(page, '[data-testid="master-table-tbl-traps"]');
    expect(tableScan.violations).toHaveLength(0);
    expect(tableScan.nonNfcViolations).toHaveLength(0);
  });
});
