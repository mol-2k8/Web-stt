from pathlib import Path
from fontTools.ttLib import TTFont

font_path = Path("dist/fonts/BeVietnamPro-Regular.woff2")
font = TTFont(str(font_path))
cmap = font.getBestCmap()
print(f"Total cmap entries: {len(cmap)}")

# Categorize codepoints
ranges = {
    "Basic Latin (0x20..0x7E)": [cp for cp in cmap if 0x20 <= cp <= 0x7E],
    "Latin-1 Supplement (0xA0..0xFF)": [cp for cp in cmap if 0xA0 <= cp <= 0xFF],
    "Latin Extended-A (0x100..0x17F)": [cp for cp in cmap if 0x100 <= cp <= 0x17F],
    "Latin Extended-B (0x180..0x24F)": [cp for cp in cmap if 0x180 <= cp <= 0x24F],
    "Latin Extended Additional (0x1EA0..0x1EF9)": [cp for cp in cmap if 0x1EA0 <= cp <= 0x1EF9],
    "Math Operators (0x2200..0x22FF)": [cp for cp in cmap if 0x2200 <= cp <= 0x22FF],
    "Letterlike Symbols (0x2100..0x214F)": [cp for cp in cmap if 0x2100 <= cp <= 0x214F],
    "Arrows (0x2190..0x21FF)": [cp for cp in cmap if 0x2190 <= cp <= 0x21FF],
    "Greek (0x0370..0x03FF)": [cp for cp in cmap if 0x0370 <= cp <= 0x03FF],
    "Other": [cp for cp in cmap if not (
        (0x20 <= cp <= 0x7E) or (0xA0 <= cp <= 0x24F) or (0x1EA0 <= cp <= 0x1EF9) or
        (0x2200 <= cp <= 0x22FF) or (0x2100 <= cp <= 0x21FF) or (0x0370 <= cp <= 0x03FF)
    )]
}

for name, cps in ranges.items():
    print(f"{name}: {len(cps)} chars")
    if name in ["Math Operators (0x2200..0x22FF)", "Letterlike Symbols (0x2100..0x214F)", "Arrows (0x2190..0x21FF)"]:
        chars = [f"{chr(c)}(U+{c:04X})" for c in cps]
        print(f"   Glyphs: {', '.join(chars)}")
