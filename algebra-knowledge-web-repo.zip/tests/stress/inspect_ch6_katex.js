const { chromium } = require('@playwright/test');

(async () => {
  const browser = await chromium.launch({
    executablePath: 'C:\\Program Files\\Google\\Chrome\\Application\\chrome.exe',
    headless: true,
    args: ['--no-sandbox', '--disable-setuid-sandbox', '--disable-dev-shm-usage', '--disable-gpu'],
  });
  const page = await browser.newPage();
  await page.goto('http://localhost:3000');
  await page.waitForTimeout(500);

  const chapters = ['ch1', 'ch2', 'ch3', 'ch4', 'ch5', 'ch6', 'ch7'];
  const allErrors = {};

  for (const ch of chapters) {
    await page.click(`button[data-testid="chapter-nav-${ch}"]`);
    await page.waitForTimeout(400);

    // Expand all examples in this chapter
    const toggles = await page.$$('button[data-testid^="example-step-toggle-"]');
    for (const toggle of toggles) {
      const expanded = await toggle.getAttribute('aria-expanded');
      if (expanded !== 'true') await toggle.click();
    }
    await page.waitForTimeout(200);

    const errors = await page.evaluate(() => {
      return Array.from(document.querySelectorAll('.katex-error')).map(el => ({
        text: el.innerText,
        title: el.getAttribute('title'),
        parentHTML: el.parentElement ? el.parentElement.outerHTML.slice(0, 300) : ''
      }));
    });

    if (errors.length > 0) {
      allErrors[ch] = errors;
    }
  }

  console.log('All Chapters KaTeX Errors:');
  console.log(JSON.stringify(allErrors, null, 2));

  await browser.close();
})();
