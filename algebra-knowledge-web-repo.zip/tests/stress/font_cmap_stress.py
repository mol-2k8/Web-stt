#!/usr/bin/env python3
"""
tests/stress/font_cmap_stress.py
================================
Adversarial Font File Integrity & Cmap Verification Suite.

Stress-tests dist/fonts/BeVietnamPro-*.woff2 and .woff against:
1. Magic headers (b'wOF2' / b'wOFF').
2. Font table integrity (head, hhea, maxp, OS/2, hmtx, cmap, loca, glyf, name, post).
3. Cmap table format & subtable integrity.
4. Complete glyph coverage for all 73 Vietnamese precomposed NFC characters (both uppercase and lowercase).
5. Mathematical symbol coverage per PROJECT.md (Blackboard bold R, C, Z, Q, N, operators, quantifiers, set relations, Greek letters).
6. Glyph outline decompression check (ensuring no corrupted glyph coordinate data).
"""

import sys
from pathlib import Path
from fontTools.ttLib import TTFont

PROJECT_ROOT = Path(__file__).resolve().parent.parent.parent
DIST_FONTS = PROJECT_ROOT / "dist" / "fonts"

# Comprehensive Vietnamese NFC Character Set:
# All 73 distinct accented characters + all uppercase/lowercase pairs (134 characters)
VIETNAMESE_NFC_STR = (
    "ÁÀẢÃẠĂẮẰẲẴẶÂẤẦẨẪẬĐÉÈẺẼẸÊẾỀỂỄỆÍÌỈĨỊÓÒỎÕỌÔỐỒỔỖỘƠỚỜỞỠỢÚÙỦŨỤƯỨỪỬỮỰÝỲỶỸỴ"
    "áàảãạăắằẳẵặâấầẩẫậđéèẻẽẹêếềểễệíìỉĩịóòỏõọôốồổỗộơớờởỡợúùủũụưứừửữựýỳỷỹỵ"
)
VIETNAMESE_UNIQUE_CHARS = sorted(list(set(VIETNAMESE_NFC_STR)))

# Required Math and Letterlike Symbols defined in PROJECT.md / M1 Contract
REQUIRED_MATH_SYMBOLS = [
    ("Blackboard Bold R", "ℝ", 0x211D),
    ("Blackboard Bold C", "ℂ", 0x2102),
    ("Blackboard Bold Z", "ℤ", 0x2124),
    ("Blackboard Bold Q", "ℚ", 0x211A),
    ("Blackboard Bold N", "ℕ", 0x2115),
    ("Union", "∪", 0x222A),
    ("Intersection", "∩", 0x2229),
    ("Subset", "⊂", 0x2282),
    ("Superset", "⊃", 0x2283),
    ("Composition / Circle", "∘", 0x2218),
    ("Set Difference / Backslash", "∖", 0x2216),
    ("Empty set", "∅", 0x2205),
    ("Summation", "∑", 0x2211),
    ("Product", "∏", 0x220F),
    ("Square Root", "√", 0x221A),
    ("Not Equal", "≠", 0x2260),
    ("Less than or equal", "≤", 0x2264),
    ("Greater than or equal", "≥", 0x2265),
    ("Almost equal", "≈", 0x2248),
    ("Equivalent / Congruent", "≡", 0x2261),
    ("For all", "∀", 0x2200),
    ("There exists", "∃", 0x2203),
    ("Element of", "∈", 0x2208),
    ("Not element of", "∉", 0x2209),
    ("Left arrow", "←", 0x2190),
    ("Right arrow", "→", 0x2192),
    ("Left-right arrow", "↔", 0x2194),
    ("Double left arrow", "⇐", 0x21D0),
    ("Double right arrow", "⇒", 0x21D2),
    ("Double left-right arrow", "⇔", 0x21D4),
    ("Bullet", "•", 0x2022),
    ("Black Square", "▪", 0x25AA),
    ("Middle Dot", "·", 0x00B7),
    ("Multiplication", "×", 0x00D7),
    ("Division", "÷", 0x00F7),
    ("Plus-minus", "±", 0x00B1),
    ("Delta", "Δ", 0x0394),
    ("Alpha", "α", 0x03B1),
    ("Beta", "β", 0x03B2),
    ("Epsilon", "ε", 0x03B5),
    ("Lambda", "λ", 0x03BB),
    ("Pi", "π", 0x03C0),
    ("Sigma", "σ", 0x03C3),
    ("Phi", "φ", 0x03C6),
]

REQUIRED_TABLES = [
    'head', 'hhea', 'maxp', 'OS/2', 'hmtx', 'cmap', 'loca', 'glyf', 'name', 'post'
]

def audit_font(font_path: Path) -> dict:
    result = {
        "path": str(font_path),
        "name": font_path.name,
        "exists": font_path.exists(),
        "passed": True,
        "errors": [],
        "warnings": [],
        "metrics": {}
    }

    if not font_path.exists():
        result["passed"] = False
        result["errors"].append(f"Font file does not exist: {font_path}")
        return result

    data = font_path.read_bytes()
    magic = data[:4]
    expected_magic = b"wOF2" if font_path.suffix == ".woff2" else b"wOFF"
    if magic != expected_magic:
        result["passed"] = False
        result["errors"].append(f"Invalid magic header: {magic!r}, expected {expected_magic!r}")
        return result

    result["metrics"]["file_size_bytes"] = len(data)
    result["metrics"]["file_size_kb"] = round(len(data) / 1024, 2)

    try:
        font = TTFont(str(font_path))
    except Exception as e:
        result["passed"] = False
        result["errors"].append(f"Failed to load TTFont: {e}")
        return result

    # 1. Check required tables
    existing_tables = set(font.keys())
    for tbl in REQUIRED_TABLES:
        if tbl not in existing_tables:
            result["passed"] = False
            result["errors"].append(f"Missing essential table: {tbl}")

    # 2. Inspect cmap table
    if 'cmap' not in font:
        result["passed"] = False
        result["errors"].append("Missing cmap table entirely")
        return result

    cmap_table = font['cmap']
    best_cmap = font.getBestCmap()
    if not best_cmap:
        result["passed"] = False
        result["errors"].append("Font getBestCmap() returned None or empty")
        return result

    result["metrics"]["cmap_char_count"] = len(best_cmap)

    # Verify cmap subtables
    subtables = cmap_table.tables
    format_types = [s.format for s in subtables]
    result["metrics"]["cmap_subtable_formats"] = format_types
    if 4 not in format_types and 12 not in format_types:
        result["warnings"].append(f"Standard cmap format 4 or 12 not found: {format_types}")

    # 3. Check Vietnamese characters coverage
    missing_vn = []
    for char in VIETNAMESE_UNIQUE_CHARS:
        cp = ord(char)
        if cp not in best_cmap:
            missing_vn.append(f"{char} (U+{cp:04X})")

    if missing_vn:
        result["passed"] = False
        result["errors"].append(f"Missing {len(missing_vn)} Vietnamese characters: {', '.join(missing_vn[:15])}...")
    else:
        result["metrics"]["vietnamese_nfc_coverage"] = "100% (all 134 uppercase/lowercase forms present)"

    # 4. Check Math symbols coverage
    missing_math = []
    for name, sym, cp in REQUIRED_MATH_SYMBOLS:
        if cp not in best_cmap:
            missing_math.append(f"{name} '{sym}' (U+{cp:04X})")

    if missing_math:
        result["passed"] = False
        result["errors"].append(f"Missing {len(missing_math)} Math symbols: {', '.join(missing_math)}")
    else:
        result["metrics"]["math_symbols_coverage"] = f"100% ({len(REQUIRED_MATH_SYMBOLS)} symbols verified)"

    # 5. Glyph outline decompilation check (stress test against glyf table corruption)
    if 'glyf' in font:
        glyf_table = font['glyf']
        decompiled_count = 0
        corrupted_glyphs = []
        for glyph_name in font.getGlyphOrder():
            try:
                g = glyf_table[glyph_name]
                if hasattr(g, 'numberOfContours'):
                    _ = g.numberOfContours
                decompiled_count += 1
            except Exception as e:
                corrupted_glyphs.append(f"{glyph_name}: {e}")

        result["metrics"]["total_glyphs_decompiled"] = decompiled_count
        if corrupted_glyphs:
            result["passed"] = False
            result["errors"].append(f"Corrupted glyph outlines detected: {corrupted_glyphs[:5]}")
        else:
            result["metrics"]["glyph_integrity"] = "100% decompiled without errors"

    return result

def run_stress_cmap_check():
    print("=" * 70)
    print("  TASK 3: EMPIRICAL ADVERSARIAL FONT INTEGRITY & CMAP STRESS TEST")
    print("=" * 70)

    font_candidates = [
        DIST_FONTS / "BeVietnamPro-Regular.woff2",
        DIST_FONTS / "BeVietnamPro-SemiBold.woff2",
        DIST_FONTS / "BeVietnamPro-Bold.woff2",
        DIST_FONTS / "BeVietnamPro-Regular.woff",
        DIST_FONTS / "BeVietnamPro-SemiBold.woff",
        DIST_FONTS / "BeVietnamPro-Bold.woff",
    ]

    overall_pass = True
    for fpath in font_candidates:
        print(f"\n[Testing Font] -> {fpath.name}")
        res = audit_font(fpath)
        print(f"  Path: {fpath}")
        print(f"  Exists: {res['exists']}")
        print(f"  Size: {res['metrics'].get('file_size_kb', 0)} KB ({res['metrics'].get('file_size_bytes', 0)} bytes)")
        print(f"  CMap Glyphs: {res['metrics'].get('cmap_char_count', 'N/A')}")
        print(f"  Subtable Formats: {res['metrics'].get('cmap_subtable_formats', 'N/A')}")
        print(f"  Vietnamese NFC: {res['metrics'].get('vietnamese_nfc_coverage', 'FAIL')}")
        print(f"  Math Symbols: {res['metrics'].get('math_symbols_coverage', 'FAIL')}")
        print(f"  Glyph Decompilation: {res['metrics'].get('glyph_integrity', 'N/A')}")

        if res["warnings"]:
            for w in res["warnings"]:
                print(f"  WARN: {w}")

        if not res["passed"]:
            overall_pass = False
            for err in res["errors"]:
                print(f"  ERROR: {err}")
            print(f"  RESULT: [FAIL]")
        else:
            print(f"  RESULT: [PASS]")

    print("\n" + "=" * 70)
    if overall_pass:
        print("  ALL FONT AUDIT & CMAP STRESS TESTS PASSED EMPIRICALLY!")
        print("=" * 70)
        return 0
    else:
        print("  FONT AUDIT & CMAP STRESS TESTS FAILED!")
        print("=" * 70)
        return 1

if __name__ == "__main__":
    sys.exit(run_stress_cmap_check())
