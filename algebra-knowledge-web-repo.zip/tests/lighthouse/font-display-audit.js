#!/usr/bin/env node

/**
 * Lighthouse Font-Display Compliance Audit Runner
 * Checks that all @font-face rules use `font-display: swap` or `optional`
 * to eliminate Flash of Invisible Text (FOIT) per Requirement R4.
 */

const fs = require('fs');
const path = require('path');
const http = require('http');
const { spawnSync } = require('child_process');

const TARGET_URL = process.env.TARGET_URL || 'http://localhost:3000';
const DEFAULT_CHROME_PATH = 'C:\\Program Files\\Google\\Chrome\\Application\\chrome.exe';
const CHROME_PATH = fs.existsSync(DEFAULT_CHROME_PATH)
  ? DEFAULT_CHROME_PATH
  : process.env.CHROME_PATH || '';

const OUTPUT_DIR = path.resolve('test-results/lighthouse');
if (!fs.existsSync(OUTPUT_DIR)) {
  fs.mkdirSync(OUTPUT_DIR, { recursive: true });
}

const REPORT_PREFIX = path.join(OUTPUT_DIR, 'font-display-report');

console.log('===============================================================');
console.log('  LIGHTHOUSE FONT-DISPLAY COMPLIANCE AUDIT');
console.log('===============================================================');
console.log(`Target URL:  ${TARGET_URL}`);
console.log(`Chrome Path: ${CHROME_PATH || 'System Default'}`);
console.log(`Output Dir:  ${OUTPUT_DIR}`);
console.log('---------------------------------------------------------------');

async function checkServerReachable(urlStr) {
  return new Promise((resolve) => {
    try {
      const u = new URL(urlStr);
      const req = http.request(
        {
          hostname: u.hostname,
          port: u.port || 80,
          path: u.pathname || '/',
          method: 'GET',
          timeout: 3000,
        },
        (res) => {
          resolve(true);
        }
      );
      req.on('error', () => resolve(false));
      req.on('timeout', () => {
        req.destroy();
        resolve(false);
      });
      req.end();
    } catch {
      resolve(false);
    }
  });
}

async function runAudit() {
  const isUp = await checkServerReachable(TARGET_URL);
  if (!isUp) {
    console.warn(`WARNING: Target URL ${TARGET_URL} is currently unreachable.`);
    console.warn('To execute this audit against live server, start the application via:');
    console.warn('  node server/serve.js  (or py server/serve.py)');
    console.warn('Skipping live audit execution until server is active.');
    return;
  }

  // Prepare lighthouse arguments
  const args = [
    'lighthouse',
    TARGET_URL,
    '--quiet',
    '--chrome-flags=--headless --no-sandbox --disable-gpu --disable-dev-shm-usage',
    '--only-categories=performance',
    '--output=json',
    '--output=html',
    `--output-path=${REPORT_PREFIX}`,
  ];

  const env = {
    ...process.env,
  };
  if (CHROME_PATH) {
    env.CHROME_PATH = CHROME_PATH;
  }

  console.log('Executing Lighthouse audit via npx...');
  const npxCmd = process.platform === 'win32' ? 'npx.cmd' : 'npx';

  const run = spawnSync(npxCmd, args, {
    env,
    stdio: 'inherit',
    shell: true,
  });

  if (run.error) {
    console.error('Failed to execute Lighthouse:', run.error);
    process.exit(1);
  }

  // Find generated JSON report
  let jsonReportPath = `${REPORT_PREFIX}.report.json`;
  if (!fs.existsSync(jsonReportPath)) {
    jsonReportPath = `${REPORT_PREFIX}.json`;
  }

  if (!fs.existsSync(jsonReportPath)) {
    const files = fs.readdirSync(OUTPUT_DIR).filter((f) => f.endsWith('.json'));
    if (files.length > 0) {
      jsonReportPath = path.join(OUTPUT_DIR, files[0]);
    } else {
      console.error(`ERROR: No Lighthouse report file generated at ${REPORT_PREFIX}.report.json`);
      process.exit(1);
    }
  }

  try {
    const reportData = JSON.parse(fs.readFileSync(jsonReportPath, 'utf8'));
    const fontDisplayAudit = reportData.audits && (reportData.audits['font-display'] || reportData.audits['font-display-insight']);

    if (!fontDisplayAudit) {
      console.error('ERROR: font-display audit result not found in Lighthouse report');
      process.exit(1);
    }

    console.log('\n--- AUDIT RESULTS ---');
    console.log(`Audit ID:       ${fontDisplayAudit.id}`);
    console.log(`Title:          ${fontDisplayAudit.title}`);
    console.log(`Score:          ${fontDisplayAudit.score} (1.0 = 100% PASS)`);
    console.log(`Display Value:  ${fontDisplayAudit.displayValue || 'Compliant'}`);

    const items = fontDisplayAudit.details?.items || [];
    if (items.length > 0) {
      console.warn('\nWarning: Detected font-display non-compliant items:');
      items.forEach((item, idx) => {
        console.warn(`  [${idx + 1}] Font URL: ${item.url} | Wasted Ms: ${item.wastedMs}`);
      });
    } else {
      console.log('All @font-face rules comply with font-display: swap. Zero invisible text detected.');
    }

    console.log('---------------------------------------------------------------');
    console.log(`Report JSON: ${jsonReportPath}`);
    console.log(`Report HTML: ${REPORT_PREFIX}.report.html`);
    console.log('===============================================================\n');

    if (fontDisplayAudit.score === 1 || items.length === 0) {
      console.log('>>> STATUS: AUDIT PASSED [100% COMPLIANT] <<<');
      process.exit(0);
    } else {
      console.error('>>> STATUS: AUDIT FAILED <<<');
      process.exit(1);
    }
  } catch (err) {
    console.error('Error evaluating Lighthouse report JSON:', err);
    process.exit(1);
  }
}

runAudit();
