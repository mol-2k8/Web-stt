const fs = require('fs');
const path = require('path');

const dataDir = path.resolve(__dirname, '../src/data');

function getFiles(dir) {
  let results = [];
  const list = fs.readdirSync(dir);
  list.forEach(file => {
    const fullPath = path.join(dir, file);
    const stat = fs.statSync(fullPath);
    if (stat && stat.isDirectory()) {
      results = results.concat(getFiles(fullPath));
    } else if (fullPath.endsWith('.ts')) {
      results.push(fullPath);
    }
  });
  return results;
}

const files = getFiles(dataDir);
const issues = [];
const matrixEnvs = ['pmatrix', 'vmatrix', 'cases', 'array', 'matrix', 'bmatrix'];

files.forEach(file => {
  const content = fs.readFileSync(file, 'utf8');
  const lines = content.split('\n');

  lines.forEach((line, idx) => {
    if (!line.includes('&')) return;

    // Filter out purely JS operator &&
    if (line.includes('&&') && !line.replace(/&&/g, '').includes('&')) return;

    // Check latex: '...' field
    const latexFieldMatch = line.match(/latex:\s*['"`](.*)['"`]/);
    if (latexFieldMatch) {
      let latex = latexFieldMatch[1];
      // remove escaped ampersand
      latex = latex.replace(/\\\\&/g, '').replace(/\\&/g, '');
      // remove matrix environments
      matrixEnvs.forEach(env => {
        const re = new RegExp('\\\\begin\\{' + env + '\\}[\\s\\S]*?\\\\end\\{' + env + '\\}', 'g');
        latex = latex.replace(re, '');
      });
      if (latex.includes('&')) {
        issues.push({
          file: path.relative(path.resolve(__dirname, '..'), file),
          lineNum: idx + 1,
          type: 'latex property',
          snippet: line.trim()
        });
      }
    }

    // Check inline math $...$ in strings
    const dollarMatches = line.match(/\$([^\$]+)\$/g);
    if (dollarMatches) {
      dollarMatches.forEach(dm => {
        let math = dm;
        // remove escaped ampersand
        math = math.replace(/\\\\&/g, '').replace(/\\&/g, '');
        // remove matrix environments
        matrixEnvs.forEach(env => {
          const re = new RegExp('\\\\begin\\{' + env + '\\}[\\s\\S]*?\\\\end\\{' + env + '\\}', 'g');
          math = math.replace(re, '');
        });
        if (math.includes('&')) {
          issues.push({
            file: path.relative(path.resolve(__dirname, '..'), file),
            lineNum: idx + 1,
            type: 'inline $ math',
            formula: dm,
            snippet: line.trim()
          });
        }
      });
    }

    // Check display math $$...$$
    const doubleDollarMatches = line.match(/\$\$([^\$]+)\$\$/g);
    if (doubleDollarMatches) {
      doubleDollarMatches.forEach(dm => {
        let math = dm;
        math = math.replace(/\\\\&/g, '').replace(/\\&/g, '');
        matrixEnvs.forEach(env => {
          const re = new RegExp('\\\\begin\\{' + env + '\\}[\\s\\S]*?\\\\end\\{' + env + '\\}', 'g');
          math = math.replace(re, '');
        });
        if (math.includes('&')) {
          issues.push({
            file: path.relative(path.resolve(__dirname, '..'), file),
            lineNum: idx + 1,
            type: 'display $$ math',
            formula: dm,
            snippet: line.trim()
          });
        }
      });
    }
  });
});

console.log('AUDIT RESULT:');
console.log(`Scanned ${files.length} data files.`);
console.log(`Unescaped & count outside matrix environments: ${issues.length}`);
if (issues.length > 0) {
  console.log(JSON.stringify(issues, null, 2));
  process.exit(1);
} else {
  console.log('ALL FILES CLEAN: No unescaped & found outside matrix environments!');
  process.exit(0);
}
