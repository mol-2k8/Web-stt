const fs = require('fs');
const path = require('path');
const katex = require('katex');

console.log('================================================================================');
console.log('CHALLENGER 2: ADVERSARIAL KATEX RENDERING & CONTENT INTEGRITY TEST');
console.log('================================================================================\n');

let passCount = 0;
let failCount = 0;

function testKatexFormula(mathStr, context) {
  try {
    katex.renderToString(mathStr, {
      displayMode: false,
      throwOnError: true,
      strict: false,
      trust: true
    });
    passCount++;
  } catch (err) {
    failCount++;
    console.error(`[FAIL] LaTeX Error in [${context}]: "${mathStr}"`);
    console.error(`       Error: ${err.message}`);
  }
}

// Function to extract $...$ and $$...$$ from a text string
function extractMathFormulas(text, context) {
  if (!text) return;
  // Match $$...$$
  const blockRegex = /\$\$([\s\S]+?)\$\$/g;
  let match;
  while ((match = blockRegex.exec(text)) !== null) {
    testKatexFormula(match[1].trim(), `${context} (block math)`);
  }
  // Remove block math before searching for inline math
  const cleanText = text.replace(blockRegex, '');
  // Match $...$
  const inlineRegex = /\$([^\$\n]+?)\$/g;
  while ((match = inlineRegex.exec(cleanText)) !== null) {
    testKatexFormula(match[1].trim(), `${context} (inline math)`);
  }
}

// Scan all ts files in src/data
const dataDir = path.join(__dirname, '..', 'src', 'data');

function scanDir(dir) {
  const entries = fs.readdirSync(dir, { withFileTypes: true });
  for (const entry of entries) {
    const fullPath = path.join(dir, entry.name);
    if (entry.isDirectory()) {
      scanDir(fullPath);
    } else if (entry.name.endsWith('.ts') || entry.name.endsWith('.tsx')) {
      const content = fs.readFileSync(fullPath, 'utf8');
      const relativePath = path.relative(dataDir, fullPath);
      
      // Extract all strings enclosed in quotes or backticks
      // We can also search directly for $...$
      extractMathFormulas(content, relativePath);

      // Also check specific formula objects: latex: '...'
      const latexFieldRegex = /latex:\s*'([^']+)'/g;
      while ((match = latexFieldRegex.exec(content)) !== null) {
        // Need to unescape backslashes in JS regex match if double escaped
        const latexStr = match[1].replace(/\\\\/g, '\\');
        testKatexFormula(latexStr, `${relativePath} (field: latex)`);
      }
    }
  }
}

scanDir(dataDir);

console.log(`\nKaTeX Verification Summary:`);
console.log(`- Successfully rendered formulas: ${passCount}`);
console.log(`- Failed formulas: ${failCount}`);

if (failCount > 0) {
  console.error('\nFAILED: One or more LaTeX formulas failed KaTeX parsing!');
  process.exit(1);
} else {
  console.log('\nSUCCESS: All LaTeX formulas compile cleanly with KaTeX!');
  process.exit(0);
}
