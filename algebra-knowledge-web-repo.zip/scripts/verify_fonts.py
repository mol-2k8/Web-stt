#!/usr/bin/env python3
"""
scripts/verify_fonts.py
=======================
Automated verification suite for Milestone M1 (font-pipeline-and-server).

Checks:
1. Font File Integrity & Size:
   - Verifies all 6 font files exist in public/fonts/
   - Verifies magic byte headers (b'wOF2' for WOFF2, b'wOFF' for WOFF)
   - Asserts WOFF2 sizes are within target ~10-25 KB range
2. CMap Glyph Verification:
   - Verifies all 73 Vietnamese precomposed NFC characters are present in all weights
   - Verifies mathematical symbols and blackboard bold characters
3. HTTP Server Verification:
   - Boots the server on a test port
   - Sends HTTP GET and OPTIONS requests
   - Asserts HTTP 200 / 204, Content-Type: font/woff2, and Access-Control-Allow-Origin: *
"""

import os
import sys
import time
import subprocess
import urllib.request
import urllib.error
from pathlib import Path
from fontTools import ttLib

PROJECT_ROOT = Path(__file__).resolve().parent.parent
FONTS_DIR = PROJECT_ROOT / "public" / "fonts"

# The 73 Vietnamese precomposed NFC characters from Document 3.pdf
VIETNAMESE_73_CHARS = (
    "ÁÔÝàáâãèéêìíòóôõùúýăĐđĩũơƯưạẢảấầẩẫậắằẳẵặẹẻẽếềểễệỉịọỏốồổỗộớờởỡợụủỨứngừsửnữựỳỷỹ"
)

# Essential math symbols that must be present
MATH_SYMBOLS = [
    ("Blackboard Bold R", "ℝ", 0x211D),
    ("Blackboard Bold C", "ℂ", 0x2102),
    ("Blackboard Bold Z", "ℤ", 0x2124),
    ("Blackboard Bold Q", "ℚ", 0x211A),
    ("Blackboard Bold N", "ℕ", 0x2115),
    ("Union", "∪", 0x222A),
    ("Intersection", "∩", 0x2229),
    ("Subset", "⊂", 0x2282),
    ("Summation", "∑", 0x2211),
    ("Square Root", "√", 0x221A),
    ("Not Equal", "≠", 0x2260),
    ("Less Than or Equal", "≤", 0x2264),
    ("Bullet", "•", 0x2022),
    ("Black Square", "▪", 0x25AA),
]

def verify_file_integrity():
    """Verify font files exist, have correct magic bytes, and match target sizes."""
    print("\n--- [Check 1/3] Font File Integrity & Size ---")
    weights = ["Regular", "SemiBold", "Bold"]
    all_passed = True

    for weight in weights:
        # Check WOFF2
        woff2_file = FONTS_DIR / f"BeVietnamPro-{weight}.woff2"
        if not woff2_file.exists():
            print(f"  FAIL: Missing file {woff2_file.name}")
            all_passed = False
            continue

        woff2_data = woff2_file.read_bytes()
        woff2_magic = woff2_data[:4]
        woff2_size_kb = round(len(woff2_data) / 1024, 2)

        if woff2_magic != b"wOF2":
            print(f"  FAIL: {woff2_file.name} invalid magic header: {woff2_magic} (expected b'wOF2')")
            all_passed = False
        else:
            size_ok = 10.0 <= woff2_size_kb <= 26.0
            status = "PASS" if size_ok else "WARN"
            print(f"  [{status}] {woff2_file.name}: {woff2_size_kb} KB (magic: {woff2_magic.decode()})")
            if not size_ok:
                print(f"        Warning: size {woff2_size_kb} KB outside ideal target 10-25 KB")

        # Check WOFF
        woff_file = FONTS_DIR / f"BeVietnamPro-{weight}.woff"
        if not woff_file.exists():
            print(f"  FAIL: Missing fallback {woff_file.name}")
            all_passed = False
            continue

        woff_data = woff_file.read_bytes()
        woff_magic = woff_data[:4]
        woff_size_kb = round(len(woff_data) / 1024, 2)

        if woff_magic != b"wOFF":
            print(f"  FAIL: {woff_file.name} invalid magic header: {woff_magic} (expected b'wOFF')")
            all_passed = False
        else:
            print(f"  [PASS] {woff_file.name}: {woff_size_kb} KB (magic: {woff_magic.decode()})")

    return all_passed

def verify_cmap_glyphs():
    """Verify that all 73 Vietnamese characters and math symbols exist in the font cmap."""
    print("\n--- [Check 2/3] CMap Glyph Coverage ---")
    weights = ["Regular", "SemiBold", "Bold"]
    all_passed = True

    for weight in weights:
        woff2_file = FONTS_DIR / f"BeVietnamPro-{weight}.woff2"
        font = ttLib.TTFont(str(woff2_file))
        cmap = font.getBestCmap()
        total_glyphs = len(cmap)
        print(f"\n  Weight: BeVietnamPro-{weight} (Total cmap characters: {total_glyphs})")

        # Check 73 Vietnamese characters
        missing_vn = []
        for char in set(VIETNAMESE_73_CHARS):
            cp = ord(char)
            if cp not in cmap:
                missing_vn.append(f"{char}(U+{cp:04X})")

        if missing_vn:
            print(f"    FAIL: Missing {len(missing_vn)} Vietnamese characters: {', '.join(missing_vn)}")
            all_passed = False
        else:
            print(f"    [PASS] 100% of 73 Vietnamese precomposed NFC characters present")

        # Check Math symbols
        missing_math = []
        for name, sym, cp in MATH_SYMBOLS:
            if cp not in cmap:
                missing_math.append(f"{name} ({sym})")

        if missing_math:
            print(f"    FAIL: Missing math symbols: {', '.join(missing_math)}")
            all_passed = False
        else:
            print(f"    [PASS] Essential blackboard bold and math operators present")

    return all_passed

def test_server_instance(server_cmd: list, server_name: str, test_port: int = 3456):
    """Test HTTP server instance for MIME types and CORS headers."""
    print(f"\n  Testing server: {server_name} on port {test_port}...")
    env = os.environ.copy()
    env["PORT"] = str(test_port)

    # Start server process
    proc = subprocess.Popen(
        server_cmd,
        cwd=str(PROJECT_ROOT),
        env=env,
        stdout=subprocess.PIPE,
        stderr=subprocess.PIPE,
    )

    time.sleep(1.2)  # Give server time to bind port

    passed = True
    base_url = f"http://127.0.0.1:{test_port}"

    try:
        # 1. Test WOFF2 request
        font_url = f"{base_url}/fonts/BeVietnamPro-Regular.woff2"
        req = urllib.request.Request(font_url, headers={"Origin": "http://localhost:5173"})
        with urllib.request.urlopen(req, timeout=5) as resp:
            status = resp.status
            content_type = resp.headers.get("Content-Type", "")
            cors = resp.headers.get("Access-Control-Allow-Origin", "")
            cache = resp.headers.get("Cache-Control", "")

            print(f"    GET {font_url}")
            print(f"      Status:       {status}")
            print(f"      Content-Type: {content_type}")
            print(f"      CORS:         {cors}")
            print(f"      Cache:        {cache}")

            if status != 200:
                print(f"      FAIL: Expected status 200, got {status}")
                passed = False
            if "font/woff2" not in content_type:
                print(f"      FAIL: Expected font/woff2, got {content_type}")
                passed = False
            if cors != "*":
                print(f"      FAIL: Expected Access-Control-Allow-Origin: *, got {cors}")
                passed = False
            if "immutable" not in cache:
                print(f"      FAIL: Expected immutable cache-control, got {cache}")
                passed = False

        # 2. Test WOFF fallback request
        woff_url = f"{base_url}/fonts/BeVietnamPro-Regular.woff"
        req_woff = urllib.request.Request(woff_url)
        with urllib.request.urlopen(req_woff, timeout=5) as resp_woff:
            ct_woff = resp_woff.headers.get("Content-Type", "")
            if "font/woff" not in ct_woff:
                print(f"      FAIL: WOFF Expected font/woff, got {ct_woff}")
                passed = False
            else:
                print(f"    GET {woff_url} -> Content-Type: {ct_woff} [PASS]")

        # 3. Test OPTIONS preflight
        req_opt = urllib.request.Request(font_url, method="OPTIONS")
        req_opt.add_header("Origin", "http://example.com")
        req_opt.add_header("Access-Control-Request-Method", "GET")
        with urllib.request.urlopen(req_opt, timeout=5) as resp_opt:
            if resp_opt.status in [200, 204]:
                print(f"    OPTIONS preflight -> Status {resp_opt.status}, CORS: {resp_opt.headers.get('Access-Control-Allow-Origin')} [PASS]")
            else:
                print(f"      FAIL: OPTIONS preflight status {resp_opt.status}")
                passed = False

    except Exception as e:
        print(f"    FAIL: Request error: {e}")
        passed = False
    finally:
        # Terminate server
        proc.terminate()
        try:
            proc.wait(timeout=3)
        except subprocess.TimeoutExpired:
            proc.kill()

    return passed

def verify_servers():
    """Verify both Node.js and Python servers."""
    print("\n--- [Check 3/3] HTTP Production Servers (MIME & CORS) ---")
    node_ok = test_server_instance(["node", "server/serve.js"], "Node.js (server/serve.js)", 3101)
    py_ok = test_server_instance([sys.executable, "server/serve.py"], "Python (server/serve.py)", 3102)

    return node_ok and py_ok

def main():
    print("=" * 65)
    print("  Milestone M1 Font Pipeline & Production Server Verification")
    print("=" * 65)

    c1 = verify_file_integrity()
    c2 = verify_cmap_glyphs()
    c3 = verify_servers()

    print("\n" + "=" * 65)
    print("  Final Verification Summary")
    print("=" * 65)
    print(f"  Check 1 - Font Files & WOFF2 Size (~10-25 KB): {'PASS' if c1 else 'FAIL'}")
    print(f"  Check 2 - 73 Vietnamese & Math CMap Glyphs:   {'PASS' if c2 else 'FAIL'}")
    print(f"  Check 3 - Node.js & Python MIME/CORS Servers:  {'PASS' if c3 else 'FAIL'}")
    print("=" * 65)

    if c1 and c2 and c3:
        print("\nALL CHECKS PASSED: Milestone M1 fully verified and ready for integration.\n")
        sys.exit(0)
    else:
        print("\nVERIFICATION FAILED: Please inspect errors above.\n")
        sys.exit(1)

if __name__ == "__main__":
    main()
