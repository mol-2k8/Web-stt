#!/usr/bin/env python3
"""
scripts/subset_fonts.py
=======================
Automated font subsetting pipeline for Algebra Knowledge Web.

Features:
1. Downloads / caches high-quality open-source base fonts:
   - Be Vietnam Pro (Regular 400, SemiBold 600, Bold 700) by Fábio Haag / VietAnh Nguyen (OFL)
   - Noto Sans Math (Regular) for mathematical operators and blackboard bold symbols
2. Merges Vietnamese typography with math symbols.
3. Subsets fonts keeping:
   - Basic Latin (U+0020-007E)
   - Latin-1 Supplement (U+00A0-00FF)
   - Latin Extended-A (U+0100-017F)
   - Latin Extended-B (U+0180-024F)
   - Latin Extended Additional (U+1EA0-1EF9 - all 73 Vietnamese precomposed NFC glyphs)
   - Mathematical Operators & Symbols:
     * Blackboard bold: R, C, Z, Q, N (U+211D, U+2102, U+2124, U+211A, U+2115)
     * Set operations: cup, cap, subset, supset, setminus, circ (U+222A, U+2229, U+2282, U+2283, U+2216, U+2218)
     * Algebraic operators: sum, prod, sqrt, ne, le, ge, approx, equiv (U+2211, U+220F, U+221A, U+2260, U+2264, U+2265, U+2248, U+2261)
     * Quantifiers & logic: forall, exists, in, notin, emptyset (U+2200, U+2203, U+2208, U+2209, U+2205)
     * Arrows: leftarrow, rightarrow, leftrightarrow, Leftrightarrow, Rightarrow (U+2190, U+2192, U+2194, U+21D4, U+21D2)
     * Bullets & shapes: bullet (U+2022), square (U+25AA), middle dot (U+00B7)
     * Greek letters: alpha, beta, gamma, delta, epsilon, lambda, pi, sigma, phi (U+0394, U+03B1, U+03B2, U+03B5, U+03BB, U+03C0, U+03C3, U+03C6)
     * Subscripts & superscripts (U+2070-209F, U+1D62, U+2C7C, U+1D50, U+1D4F)
4. Emits compressed WOFF2 (Brotli) and WOFF (Zopfli) files into public/fonts/:
   - BeVietnamPro-Regular.woff2 & .woff
   - BeVietnamPro-SemiBold.woff2 & .woff
   - BeVietnamPro-Bold.woff2 & .woff
Target size: ~10-25 KB per WOFF2 file.
"""

import os
import sys
import io
import urllib.request
from pathlib import Path

# Verify fontTools is available
try:
    from fontTools import ttLib, subset
    from fontTools.merge import Merger
except ImportError as err:
    print(f"ERROR: fontTools is required: {err}", file=sys.stderr)
    print("Please install via: pip install fonttools brotli zopfli", file=sys.stderr)
    sys.exit(1)

# Ensure zopfli is available for WOFF
try:
    import zopfli
    ZOPFLI_AVAILABLE = True
except ImportError:
    ZOPFLI_AVAILABLE = False
    print("Warning: zopfli module not found, fallback to standard zlib for WOFF.", file=sys.stderr)

PROJECT_ROOT = Path(__file__).resolve().parent.parent
CACHE_DIR = PROJECT_ROOT / "scripts" / ".cache_fonts"
OUTPUT_DIR = PROJECT_ROOT / "public" / "fonts"

# Font sources (official Google Fonts GitHub OFL repositories)
FONT_URLS = {
    "BeVietnamPro-Regular": "https://raw.githubusercontent.com/google/fonts/main/ofl/bevietnampro/BeVietnamPro-Regular.ttf",
    "BeVietnamPro-SemiBold": "https://raw.githubusercontent.com/google/fonts/main/ofl/bevietnampro/BeVietnamPro-SemiBold.ttf",
    "BeVietnamPro-Bold": "https://raw.githubusercontent.com/google/fonts/main/ofl/bevietnampro/BeVietnamPro-Bold.ttf",
    "NotoSansMath-Regular": "https://raw.githubusercontent.com/google/fonts/main/ofl/notosansmath/NotoSansMath-Regular.ttf",
}

# The 73 Vietnamese precomposed NFC characters from Document 3.pdf
VIETNAMESE_73_CHARS = (
    "ÁÔÝàáâãèéêìíòóôõùúýăĐđĩũơƯưạẢảấầẩẫậắằẳẵặẹẻẽếềểễệỉịọỏốồổỗộớờởỡợụủỨứngừsửnữựỳỷỹ"
)

# Targeted mathematical symbols & operators
MATH_UNICODES = {
    # Blackboard Bold number sets
    0x2115,  # ℕ
    0x2124,  # ℤ
    0x211A,  # ℚ
    0x211D,  # ℝ
    0x2102,  # ℂ
    # Set Operations & Relations
    0x222A,  # ∪
    0x2229,  # ∩
    0x2282,  # ⊂
    0x2283,  # ⊃
    0x2218,  # ∘
    0x2216,  # ∖
    0x2205,  # ∅
    # Mathematical Operators
    0x2211,  # ∑
    0x220F,  # ∏
    0x221A,  # √
    0x2260,  # ≠
    0x2264,  # ≤
    0x2265,  # ≥
    0x2248,  # ≈
    0x2261,  # ≡
    # Quantifiers & Membership
    0x2200,  # ∀
    0x2203,  # ∃
    0x2208,  # ∈
    0x2209,  # ∉
    # Arrows & Logic
    0x2190,  # ←
    0x2192,  # →
    0x2194,  # ↔
    0x21D0,  # ⇐
    0x21D2,  # ⇒
    0x21D4,  # ⇔
    # Greek letters
    0x0394,  # Δ
    0x03B1,  # α
    0x03B2,  # β
    0x03B5,  # ε
    0x03BB,  # λ
    0x03C0,  # π
    0x03C3,  # σ
    0x03C6,  # φ
    # Bullets, markers & arithmetic
    0x2022,  # •
    0x25AA,  # ▪
    0x00B7,  # ·
    0x00D7,  # ×
    0x00F7,  # ÷
    0x00B1,  # ±
    # Superscripts & Subscripts
    0x2070, 0x00B9, 0x00B2, 0x00B3, 0x2074, 0x2075, 0x2076, 0x2077, 0x2078, 0x2079, 0x207B, 0x207F,
    0x2080, 0x2081, 0x2082, 0x2083, 0x2084, 0x2085, 0x2086, 0x2087, 0x2088, 0x2089,
    0x209A, 0x2099, 0x1D62, 0x2C7C, 0x1D50, 0x1D4F,
}

def get_subset_unicodes():
    """Build the comprehensive set of Unicode codepoints to keep."""
    unicodes = set()

    # 1. Basic Latin (U+0020 - U+007E)
    unicodes.update(range(0x0020, 0x007F))

    # 2. Latin-1 Supplement (U+00A0 - U+00FF)
    unicodes.update(range(0x00A0, 0x0100))

    # 3. Latin Extended-A (U+0100 - U+017F)
    unicodes.update(range(0x0100, 0x0180))

    # 4. Latin Extended-B (U+0180 - U+024F)
    unicodes.update(range(0x0180, 0x0250))

    # 5. Latin Extended Additional (U+1EA0 - U+1EF9: all 73 Vietnamese characters)
    unicodes.update(range(0x1EA0, 0x1EFA))

    # 6. Explicit 73 Vietnamese precomposed characters (assert inclusion)
    for char in VIETNAMESE_73_CHARS:
        unicodes.add(ord(char))

    # 7. Math symbols & operators
    unicodes.update(MATH_UNICODES)

    return unicodes

def download_font(name: str, url: str) -> Path:
    """Download font TTF to cache directory if not already cached."""
    CACHE_DIR.mkdir(parents=True, exist_ok=True)
    target_path = CACHE_DIR / f"{name}.ttf"

    if target_path.exists() and target_path.stat().st_size > 5000:
        print(f"  [Cache hit] {target_path.name} ({target_path.stat().st_size} bytes)")
        return target_path

    print(f"  [Downloading] {name} from {url}...")
    req = urllib.request.Request(url, headers={"User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64)"})
    with urllib.request.urlopen(req, timeout=30) as resp:
        data = resp.read()

    target_path.write_bytes(data)
    print(f"  [Saved] {target_path.name} ({len(data)} bytes)")
    return target_path

def subset_and_save(font_path: Path, output_woff2: Path, output_woff: Path, unicodes: set):
    """Subset font and emit WOFF2 and WOFF formats."""
    # 1. Load font
    font = ttLib.TTFont(str(font_path))

    # 2. Configure WOFF2 subsetter
    options_woff2 = subset.Options()
    options_woff2.flavor = "woff2"
    options_woff2.hinting = False  # Stripping hinting achieves ~10-25 KB for web
    options_woff2.desubroutinize = True

    subsetter_woff2 = subset.Subsetter(options=options_woff2)
    subsetter_woff2.populate(unicodes=unicodes)
    subsetter_woff2.subset(font)

    # Save WOFF2
    output_woff2.parent.mkdir(parents=True, exist_ok=True)
    subset.save_font(font, str(output_woff2), options_woff2)
    woff2_size = output_woff2.stat().st_size
    print(f"    -> Generated {output_woff2.name}: {woff2_size} bytes ({round(woff2_size / 1024, 2)} KB)")

    # 3. Configure WOFF (with Zopfli if available)
    # Reload font to preserve original glyph data for WOFF compression
    font_for_woff = ttLib.TTFont(str(font_path))
    options_woff = subset.Options()
    options_woff.flavor = "woff"
    options_woff.hinting = False
    options_woff.desubroutinize = True
    if ZOPFLI_AVAILABLE:
        options_woff.with_zopfli = True

    subsetter_woff = subset.Subsetter(options=options_woff)
    subsetter_woff.populate(unicodes=unicodes)
    subsetter_woff.subset(font_for_woff)

    # Save WOFF
    subset.save_font(font_for_woff, str(output_woff), options_woff)
    woff_size = output_woff.stat().st_size
    print(f"    -> Generated {output_woff.name}: {woff_size} bytes ({round(woff_size / 1024, 2)} KB)")

    return woff2_size, woff_size

def process_weight(weight_name: str, math_ttf: Path, unicodes: set):
    """Merge weight with math font and produce optimized web fonts."""
    print(f"\nProcessing weight: {weight_name}")
    bvp_url = FONT_URLS[f"BeVietnamPro-{weight_name}"]
    bvp_ttf = download_font(f"BeVietnamPro-{weight_name}", bvp_url)

    # Merge Be Vietnam Pro with Noto Sans Math to include mathematical operators
    print(f"  [Merging] {bvp_ttf.name} + {math_ttf.name}...")
    merger = Merger()
    merged_font = merger.merge([str(bvp_ttf), str(math_ttf)])

    temp_merged_path = CACHE_DIR / f"Merged-{weight_name}.ttf"
    merged_font.save(str(temp_merged_path))

    # Subset merged font
    out_woff2 = OUTPUT_DIR / f"BeVietnamPro-{weight_name}.woff2"
    out_woff = OUTPUT_DIR / f"BeVietnamPro-{weight_name}.woff"
    print(f"  [Subsetting & Compressing] Target range: {len(unicodes)} glyphs...")
    w2_size, w_size = subset_and_save(temp_merged_path, out_woff2, out_woff, unicodes)

    # Clean up temporary merged file
    if temp_merged_path.exists():
        temp_merged_path.unlink()

    return out_woff2, out_woff

def main():
    print("=" * 65)
    print("  Algebra Knowledge Web: Font Subsetting & Compression Pipeline")
    print("=" * 65)

    unicodes = get_subset_unicodes()
    print(f"Total target Unicode codepoints: {len(unicodes)}")

    # 1. Download Math base font
    print("\n[Step 1/3] Downloading base math font...")
    math_ttf = download_font("NotoSansMath-Regular", FONT_URLS["NotoSansMath-Regular"])

    # 2. Process all 3 weights: Regular (400), SemiBold (600), Bold (700)
    print("\n[Step 2/3] Processing font weights (Regular 400, SemiBold 600, Bold 700)...")
    weights = ["Regular", "SemiBold", "Bold"]
    results = {}
    for weight in weights:
        w2, w = process_weight(weight, math_ttf, unicodes)
        results[weight] = {
            "woff2": w2,
            "woff2_size": w2.stat().st_size,
            "woff": w,
            "woff_size": w.stat().st_size,
        }

    # 3. Summary & Quality Verification
    print("\n[Step 3/3] Subsetting Summary:")
    print("-" * 65)
    for weight, res in results.items():
        w2_kb = round(res["woff2_size"] / 1024, 2)
        w_kb = round(res["woff_size"] / 1024, 2)
        status = "PASS" if 10 <= w2_kb <= 26 else "CHECK"
        print(f"  BeVietnamPro-{weight:8s} | WOFF2: {w2_kb:5.2f} KB | WOFF: {w_kb:5.2f} KB | [{status}]")
    print("-" * 65)
    print(f"Output directory: {OUTPUT_DIR.resolve()}")
    print("Subsetting pipeline completed successfully.")

if __name__ == "__main__":
    main()
