"""
Empirical Verification Harness - Challenger 2
Algebra Knowledge Web Mathematical Verification Suite
Covers:
1. Kronecker-Capelli conditions, Example 28 & Example 29 parameter m analysis.
2. Higher-Degree Viète theorem, alternating signs (-1)^k, substitution w = z^-1 (Examples 15-18).
3. Matrix algebra & trace properties, commutator AX - XA = I_n non-existence, odd-order skew-symmetric determinant.
4. 6-Tier Algebraic Hierarchy (semigroup -> field) & zero-divisor counterexamples.
"""

import sys
import math
import cmath
import numpy as np

def run_all_tests():
    passed = 0
    total = 0

    def assert_test(cond, name, msg=""):
        nonlocal passed, total
        total += 1
        if cond:
            passed += 1
            print(f"[PASS] {name}")
        else:
            print(f"[FAIL] {name}: {msg}")
            raise AssertionError(f"Test failed: {name} - {msg}")

    print("================================================================================")
    print("CHALLENGER 2: MATHEMATICAL VERIFICATION & ADVERSARIAL STRESS TEST SUITE")
    print("================================================================================")

    # -------------------------------------------------------------------------
    # TASK 1: Kronecker-Capelli Theorem & Examples 28, 29, 30
    # -------------------------------------------------------------------------
    print("\n--- TASK 1: Kronecker-Capelli Theorem & System Solvability ---")

    # Example 28: A = [[3, -2, 1, 2], [2, 1, 1, -1], [-1, 3, 0, m]]
    # Claim: rank(A) = 3 if m != -3; rank(A) = 2 if m = -3
    for m_val in [-5.0, -3.0001, -3.0, -2.9999, 0.0, 3.0, 100.0]:
        A_m = np.array([
            [3.0, -2.0, 1.0, 2.0],
            [2.0, 1.0, 1.0, -1.0],
            [-1.0, 3.0, 0.0, m_val]
        ])
        rank_computed = np.linalg.matrix_rank(A_m, tol=1e-9)
        expected_rank = 2 if abs(m_val - (-3.0)) < 1e-8 else 3
        assert_test(
            rank_computed == expected_rank,
            f"Example 28: rank(A) at m={m_val}",
            f"Expected rank {expected_rank}, got {rank_computed}"
        )

    # Verify linear dependency at m = -3:
    # h3 = -(h1 - h2) => h1 - h2 + h3 = (3-2-1, -2-1+3, 1-1+0, 2-(-1)+(-3)) = (0, 0, 0, 0)
    h1 = np.array([3, -2, 1, 2])
    h2 = np.array([2, 1, 1, -1])
    h3_minus3 = np.array([-1, 3, 0, -3])
    comb = h1 - h2 + h3_minus3
    assert_test(np.all(comb == 0), "Example 28: Exact row combination h1 - h2 + h3 == 0 at m=-3")

    # Example 29:
    # System:
    # m*x1 + 2*x2 + 2*x3 = m + 1
    # 2*x1 + m*x2 + 2*x3 = m + 2
    # 2*x1 + 2*x2 + m*x3 = m + 9
    # det(A) = (m + 4)(m - 2)^2
    for m in [-10, -4, -1, 0, 2, 5]:
        A_sym = np.array([
            [float(m), 2.0, 2.0],
            [2.0, float(m), 2.0],
            [2.0, 2.0, float(m)]
        ])
        det_exact = (m + 4) * (m - 2)**2
        det_num = np.linalg.det(A_sym)
        assert_test(
            abs(det_num - det_exact) < 1e-7,
            f"Example 29: det(A) formula at m={m}",
            f"Formula: {det_exact}, numpy det: {det_num}"
        )

    # Verify at m = 2:
    # A has rank 1, [A | b] has rank 2 => Inconsistent (vô nghiệm)
    A_m2 = np.array([
        [2.0, 2.0, 2.0],
        [2.0, 2.0, 2.0],
        [2.0, 2.0, 2.0]
    ])
    b_m2 = np.array([[3.0], [4.0], [11.0]])
    Ab_m2 = np.hstack([A_m2, b_m2])
    rank_A_m2 = np.linalg.matrix_rank(A_m2, tol=1e-9)
    rank_Ab_m2 = np.linalg.matrix_rank(Ab_m2, tol=1e-9)
    assert_test(
        rank_A_m2 == 1 and rank_Ab_m2 == 2,
        "Example 29: m = 2 is inconsistent (rank(A)=1 < rank(Ab)=2, VÔ NGHIỆM)",
        f"rank(A)={rank_A_m2}, rank(Ab)={rank_Ab_m2}"
    )

    # Verify at m = -4:
    # A has rank 2, [A | b] has rank 2 < 3 => Infinitely many solutions (VÔ SỐ NGHIỆM)
    A_mneg4 = np.array([
        [-4.0, 2.0, 2.0],
        [2.0, -4.0, 2.0],
        [2.0, 2.0, -4.0]
    ])
    b_mneg4 = np.array([[-3.0], [-2.0], [5.0]])
    Ab_mneg4 = np.hstack([A_mneg4, b_mneg4])
    rank_A_mneg4 = np.linalg.matrix_rank(A_mneg4, tol=1e-9)
    rank_Ab_mneg4 = np.linalg.matrix_rank(Ab_mneg4, tol=1e-9)
    assert_test(
        rank_A_mneg4 == 2 and rank_Ab_mneg4 == 2,
        "Example 29: m = -4 is consistent with infinitely many solutions (rank(A)=rank(Ab)=2 < 3)",
        f"rank(A)={rank_A_mneg4}, rank(Ab)={rank_Ab_mneg4}"
    )
    # Check that row 1 + row 2 + row 3 of Ab_mneg4 is exactly 0
    row_sum_Ab = Ab_mneg4[0] + Ab_mneg4[1] + Ab_mneg4[2]
    assert_test(
        np.all(np.abs(row_sum_Ab) < 1e-9),
        "Example 29: Exact linear relation row1 + row2 + row3 == 0 at m=-4"
    )

    # Example 30: Matrix equation [[1, 3], [5, m]] X = [[2, 5], [n, p]]
    # Infinitely many solutions iff row 2 = 5 * row 1 => m=15, n=10, p=25, S = m+n+p = 50
    m_30, n_30, p_30 = 15, 10, 25
    A_30 = np.array([[1.0, 3.0], [5.0, float(m_30)]])
    B_30 = np.array([[2.0, 5.0], [float(n_30), float(p_30)]])
    rank_A30 = np.linalg.matrix_rank(A_30)
    rank_AB30 = np.linalg.matrix_rank(np.hstack([A_30, B_30]))
    assert_test(
        rank_A30 == 1 and rank_AB30 == 1,
        "Example 30: rank(A)=rank([A|B])=1 < 2 => Infinitely many solutions",
        f"rank(A)={rank_A30}, rank(AB)={rank_AB30}"
    )
    assert_test(m_30 + n_30 + p_30 == 50, "Example 30: Sum m + n + p == 50")

    # -------------------------------------------------------------------------
    # TASK 2: Higher-Degree Viète & Substitution w = z^-1
    # -------------------------------------------------------------------------
    print("\n--- TASK 2: Higher-Degree Viète & Substitution w = z^-1 ---")

    # Example 15: z = (1 + i*sqrt(3))^3 / (1 - i)^4
    w1 = complex(1, math.sqrt(3))
    w2 = complex(1, -1)
    z15 = (w1**3) / (w2**4)
    assert_test(
        abs(z15.real - 2.0) < 1e-9 and abs(z15.imag - 0.0) < 1e-9,
        "Example 15: z = (1 + i*sqrt(3))^3 / (1 - i)^4 == 2 + 0i",
        f"Computed: {z15}"
    )

    # Example 16: (m + 3i)z + (3 - 4i)z_bar = m^2 - 6 + 10i
    # Has infinitely many solutions iff m = -4
    # Real system:
    # (m + 3)x - 7y = m^2 - 6
    # -x + (m - 3)y = 10
    # D = (m+3)(m-3) - (-7)(-1) = m^2 - 16
    for m_val in [-4.0, 4.0]:
        D_val = m_val**2 - 16.0
        assert_test(abs(D_val) < 1e-9, f"Example 16: D=0 at m={m_val}")
    # At m = 4: 7x - 7y = 10 => x - y = 10/7; -x + y = 10 => x - y = -10 (Inconsistent)
    # At m = -4: -x - 7y = 10 and -x - 7y = 10 (Consistent, infinitely many solutions)
    eq1_mneg4 = np.array([-4 + 3, -7, (-4)**2 - 6]) # [-1, -7, 10]
    eq2_mneg4 = np.array([-1, -4 - 3, 10])           # [-1, -7, 10]
    assert_test(np.all(eq1_mneg4 == eq2_mneg4), "Example 16: Both equations identical at m=-4")

    # Example 17: Viète degree 3 on C
    # P(z) = z^3 - (2-i)z^2 + (1+3i)z - (5-4i) = 0
    # sigma1 = 2-i, sigma2 = 1+3i, sigma3 = 5-4i
    # S3 = sigma1^3 - 3*sigma1*sigma2 + 3*sigma3
    s1 = complex(2, -1)
    s2 = complex(1, 3)
    s3 = complex(5, -4)
    term1 = s1**3
    term2 = -3 * s1 * s2
    term3 = 3 * s3
    S3_exact = term1 + term2 + term3
    assert_test(
        abs(term1 - complex(2, -11)) < 1e-9,
        "Example 17: (2-i)^3 == 2 - 11i",
        f"Got {term1}"
    )
    assert_test(
        abs(term2 - complex(-15, -15)) < 1e-9,
        "Example 17: -3*(2-i)*(1+3i) == -15 - 15i",
        f"Got {term2}"
    )
    assert_test(
        abs(term3 - complex(15, -12)) < 1e-9,
        "Example 17: 3*(5-4i) == 15 - 12i",
        f"Got {term3}"
    )
    assert_test(
        abs(S3_exact - complex(2, -38)) < 1e-9,
        "Example 17: S3 = sigma1^3 - 3*sigma1*sigma2 + 3*sigma3 == 2 - 38i",
        f"Got {S3_exact}"
    )
    # Verify empirically by finding roots of polynomial [1, -(2-i), 1+3i, -(5-4i)]
    coeffs_ex17 = [1.0, -complex(2, -1), complex(1, 3), -complex(5, -4)]
    roots_ex17 = np.roots(coeffs_ex17)
    sum_cubes = sum(r**3 for r in roots_ex17)
    assert_test(
        abs(sum_cubes - complex(2, -38)) < 1e-7,
        "Example 17: Empirical sum of cubes of roots equals 2 - 38i",
        f"Numerical sum: {sum_cubes}"
    )

    # Example 18: Reciprocal transformation w = z^-1
    # P(z) = 2z^4 - 3z^3 + 5z^2 - 4z + 1 = 0
    # Q(w) = w^4 - 4w^3 + 5w^2 - 3w + 2 = 0
    # Sum z_k^-2 = Sum w_k^2 = sigma1(w)^2 - 2*sigma2(w)
    # sigma1(w) = 4, sigma2(w) = 5 => 4^2 - 2*5 = 16 - 10 = 6
    coeffs_z = [2.0, -3.0, 5.0, -4.0, 1.0]
    roots_z = np.roots(coeffs_z)
    sum_inv_sq = sum(1.0 / (rz**2) for rz in roots_z)
    assert_test(
        abs(sum_inv_sq.real - 6.0) < 1e-9 and abs(sum_inv_sq.imag) < 1e-9,
        "Example 18: Empirical sum of z_k^-2 equals 6.0",
        f"Computed: {sum_inv_sq}"
    )

    # Example 19: Roots of unity product
    # P = Prod_{k=0}^{n-1} (2*eps_k + 1) with eps_k = e^(i*2*k*pi/n)
    # Formula: Prod (a*eps_k + b) = b^n - (-a)^n
    # For a=2, b=1, n=2021: 1^2021 - (-2)^2021 = 1 - (-2^2021) = 2^2021 + 1
    # Test for small n (n = 3, 5, 7)
    for n_test in [3, 5, 7]:
        eps = [cmath.exp(2j * math.pi * k / n_test) for k in range(n_test)]
        prod_val = 1.0
        for e in eps:
            prod_val *= (2.0 * e + 1.0)
        expected_prod = 1.0 - ((-2.0)**n_test)
        assert_test(
            abs(prod_val.real - expected_prod) < 1e-7 and abs(prod_val.imag) < 1e-7,
            f"Example 19: Product formula for n={n_test} (2^n + 1)",
            f"Expected {expected_prod}, got {prod_val}"
        )

    # Example 20: S = Sum_{k=0}^{n-1} 1/(2*eps_k - 1)
    # Formula: n / (2^n - 1)
    for n_test in [3, 5, 7]:
        eps = [cmath.exp(2j * math.pi * k / n_test) for k in range(n_test)]
        sum_val = sum(1.0 / (2.0 * e - 1.0) for e in eps)
        expected_sum = float(n_test) / (2.0**n_test - 1.0)
        assert_test(
            abs(sum_val.real - expected_sum) < 1e-7 and abs(sum_val.imag) < 1e-7,
            f"Example 20: Sum formula for n={n_test}",
            f"Expected {expected_sum}, got {sum_val}"
        )

    # -------------------------------------------------------------------------
    # TASK 3: Matrix Algebra, Trace & Skew-Symmetric Determinants
    # -------------------------------------------------------------------------
    print("\n--- TASK 3: Matrix Algebra, Trace & Skew-Symmetric Determinants ---")

    # Commutator theorem: tr(AX - XA) = 0 for all A, X
    # Prove non-existence of solution to AX - XA = I_n
    np.random.seed(42)
    for n in [2, 3, 4, 5, 10]:
        for _ in range(5):
            A_rand = np.random.randn(n, n)
            X_rand = np.random.randn(n, n)
            comm = A_rand @ X_rand - X_rand @ A_rand
            tr_comm = np.trace(comm)
            assert_test(
                abs(tr_comm) < 1e-9,
                f"Trace theorem: tr(AX - XA) == 0 for random {n}x{n} matrices",
                f"Trace was {tr_comm}"
            )
        # tr(I_n) == n != 0
        tr_I = np.trace(np.eye(n))
        assert_test(
            tr_I == n and tr_I > 0,
            f"tr(I_{n}) == {n} != 0 => AX - XA = I_{n} has NO solution in M_{n}"
        )

    # Example 22: A = [[1, 2], [3, 4]], B = [[2, m], [3, n]]
    # AX - XA = B => tr(B) = 0 => 2 + n = 0 => n = -2
    A_22 = np.array([[1.0, 2.0], [3.0, 4.0]])
    # Let X = [[x, y], [z, t]]
    # AX - XA = [[2z - 3y, 2t - 3x + 3y], [3x - 3t + 3z, 3y - 2z]]
    # tr(AX - XA) = (2z - 3y) + (3y - 2z) = 0
    # For AX - XA = [[2, m], [3, n]], we need:
    # 2z - 3y = 2
    # 3y - 2z = n => n = -2
    n_22 = -2.0
    assert_test(n_22 == -2.0, "Example 22: n == -2 determined instantly from tr(B) = 0")

    # Skew-Symmetric Matrix Theorem:
    # If A^T = -A and n is odd, then det(A) = 0
    for n_odd in [1, 3, 5, 7, 9]:
        for trial in range(5):
            M = np.random.randn(n_odd, n_odd)
            A_skew = M - M.T  # Always skew-symmetric: (M - M.T).T = M.T - M = -A_skew
            det_skew = np.linalg.det(A_skew)
            assert_test(
                abs(det_skew) < 1e-9,
                f"Skew-symmetric theorem: det(A) == 0 for odd order n={n_odd} (trial {trial+1})",
                f"det was {det_skew}"
            )

    # Note on even order skew-symmetric: det is a square of the Pfaffian, generally >= 0 and non-zero!
    for n_even in [2, 4]:
        M = np.random.randn(n_even, n_even)
        A_skew_even = M - M.T
        det_even = np.linalg.det(A_skew_even)
        assert_test(
            det_even >= -1e-9,
            f"Skew-symmetric property: det(A) >= 0 for even order n={n_even}",
            f"det was {det_even}"
        )

    # -------------------------------------------------------------------------
    # TASK 4: 6-Tier Algebraic Hierarchy & Counterexamples
    # -------------------------------------------------------------------------
    print("\n--- TASK 4: 6-Tier Algebraic Hierarchy & Counterexamples ---")

    # Tier 1: Semigroup (Nửa nhóm)
    # (N*, +) is associative, closed, but has no identity (0 not in N*)
    # Matrix multiplication on M_n(R) is associative and closed.
    A_semi = np.array([[1, 2], [3, 4]])
    B_semi = np.array([[0, 1], [-1, 2]])
    C_semi = np.array([[2, 0], [1, 3]])
    assert_test(
        np.array_equal((A_semi @ B_semi) @ C_semi, A_semi @ (B_semi @ C_semi)),
        "Tier 1: Associativity of matrix multiplication (Semigroup property)"
    )

    # Tier 2: Monoid (Vị nhóm)
    # (M_n(R), *) has two-sided identity I_n: A * I = I * A = A
    I2 = np.eye(2, dtype=int)
    assert_test(
        np.array_equal(A_semi @ I2, A_semi) and np.array_equal(I2 @ A_semi, A_semi),
        "Tier 2: Two-sided neutral element I_n (Monoid property)"
    )

    # Tier 3: Group (Nhóm) & Non-Abelian Property
    # GL_n(R) is a group, but NOT abelian: AB != BA
    assert_test(
        not np.array_equal(A_semi @ B_semi, B_semi @ A_semi),
        "Tier 3: GL_2(R) is non-abelian (AB != BA for general matrices)"
    )

    # Tier 4: Ring & Zero Divisors (Ước của không)
    # In M_2(R), zero divisors exist: non-zero A, B such that A * B = 0
    Z1 = np.array([[1, 0], [0, 0]])
    Z2 = np.array([[0, 0], [0, 1]])
    assert_test(
        not np.all(Z1 == 0) and not np.all(Z2 == 0) and np.all(Z1 @ Z2 == 0),
        "Tier 4: Zero divisors exist in M_2(R) (Z1 != 0, Z2 != 0, Z1 * Z2 == 0)"
    )
    # Nilpotent matrix: N != 0 but N^2 = 0
    N = np.array([[0, 1], [0, 0]])
    assert_test(
        not np.all(N == 0) and np.all(N @ N == 0),
        "Tier 4: Nilpotent zero divisor N != 0, N^2 == 0"
    )

    # Zero divisors in Z_12: 3 * 4 = 12 = 0 (mod 12), 2 * 6 = 12 = 0 (mod 12)
    zero_divisors_z12 = [x for x in range(1, 12) if math.gcd(x, 12) > 1]
    expected_zd_z12 = [2, 3, 4, 6, 8, 9, 10]
    assert_test(
        zero_divisors_z12 == expected_zd_z12,
        "Tier 4: Zero divisors in Z_12 match exactly {2, 3, 4, 6, 8, 9, 10}",
        f"Got {zero_divisors_z12}"
    )

    # Tier 5: Integral Domain (Miền nguyên)
    # Commutative ring with 1 != 0 and NO zero divisors.
    # Z[sqrt(2)] is an integral domain: (a + b*sqrt(2))(c + d*sqrt(2)) = 0 => (a,b)=(0,0) or (c,d)=(0,0)
    # But 2 has no inverse in Z[sqrt(2)], so it is NOT a field!
    # Norm in Z[sqrt(2)]: N(a + b*sqrt(2)) = a^2 - 2*b^2 in Z.
    # Element is invertible iff N(x) = +/- 1.
    # For x = 2 = 2 + 0*sqrt(2), N(2) = 4 != +/- 1 => not invertible in Z[sqrt(2)].
    assert_test(
        4 not in [1, -1],
        "Tier 5: Z[sqrt(2)] is an integral domain but NOT a field (2 is not invertible)"
    )

    # Tier 6: Field (Trường)
    # Q[sqrt(d)] is a field iff d is not a square in Q.
    # Formula for inverse: (a + b*sqrt(d))^-1 = (a / (a^2 - d*b^2)) - (b / (a^2 - d*b^2))*sqrt(d)
    # Test for d = 2:
    a, b, d = 3.0, 5.0, 2.0
    denom = a**2 - d * (b**2)  # 9 - 2*25 = 9 - 50 = -41 != 0
    inv_a = a / denom
    inv_b = -b / denom
    # Multiply (a + b*sqrt(2)) * (inv_a + inv_b*sqrt(2))
    prod_real = a * inv_a + d * b * inv_b
    prod_sqrt = a * inv_b + b * inv_a
    assert_test(
        abs(prod_real - 1.0) < 1e-9 and abs(prod_sqrt) < 1e-9,
        "Tier 6: Inverse formula in Q[sqrt(2)] exact: (3 + 5*sqrt(2)) * inv == 1",
        f"Real: {prod_real}, Sqrt: {prod_sqrt}"
    )

    # Counterexample when d = 4 (a square):
    # (2, 1) * (2, -1) in Q^2 with multiplication (ac + 4bd, ad + bc)
    # ac + 4bd = 2*2 + 4*(1)*(-1) = 4 - 4 = 0
    # ad + bc = 2*(-1) + 1*2 = -2 + 2 = 0
    # Both are non-zero but their product is (0, 0)!
    x1, y1 = 2, 1
    x2, y2 = 2, -1
    prod_x = x1 * x2 + 4 * y1 * y2
    prod_y = x1 * y2 + y1 * x2
    assert_test(
        prod_x == 0 and prod_y == 0,
        "Tier 6 Counterexample: When d=4 (square), (2,1)*(2,-1) = (0,0) => Zero divisors exist, NOT a field!"
    )

    print("\n================================================================================")
    print(f"ALL {total} MATHEMATICAL VERIFICATION TESTS PASSED SUCCESSFULLY ({passed}/{total})!")
    print("================================================================================")
    return True

if __name__ == "__main__":
    success = run_all_tests()
    sys.exit(0 if success else 1)
