/** @type {import('tailwindcss').Config} */
module.exports = {
  content: [
    './index.html',
    './src/**/*.{js,ts,jsx,tsx}',
  ],
  theme: {
    extend: {
      fontFamily: {
        sans: ['BeVietnamPro', 'Be Vietnam Pro', '-apple-system', 'BlinkMacSystemFont', 'Segoe UI', 'Roboto', 'sans-serif'],
        mono: ['JetBrains Mono', 'Consolas', 'Courier New', 'monospace'],
        math: ['KaTeX_Main', 'Cambria Math', 'Latin Modern Math', 'serif'],
      },
      lineHeight: {
        'diacritic': '1.7',
      },
    },
  },
  plugins: [],
};
