# TEST READY: Algebra Knowledge Web (E2E Test Suite Tiers 1–4)

**Status**: READY FOR VERIFICATION  
**Author**: `test_writer_e2e` (Specialist & QA Test Writer)  
**Date**: 2026-10-30  
**Specification References**: `ORIGINAL_REQUEST.md`, `PROJECT.md`, `TEST_INFRA.md`  

---

## 1. Test Suite Overview

The comprehensive automated End-to-End (E2E) testing suite for the **Algebra Knowledge Web** application has been fully authored, verified, and integrated into the project root. The test suite operates on an opaque-box, requirement-driven methodology verifying all user requirements (R1: Font diagnosis, R2: Knowledge web UI, R3: WOFF2 web font optimization & server headers, R4: Headless automation, Lighthouse audit, and visual captures).

The suite covers **147 registered automated test executions** structured across the 4-tier testing hierarchy defined in `TEST_INFRA.md`:
- **Tier 1 (Feature Coverage)**: Happy path tests for font loading, MIME types, CORS headers, zero console errors, zero tofu, typography, 7-chapter navigation, KaTeX math, search modal, collapsible examples, pitfall callouts, and master tables.
- **Tier 2 (Boundary & Corner Cases)**: Stress testing, extreme inputs, unaccented fuzzy search queries, non-matching gibberish, full sequential 7-chapter navigation loops, line-height diacritic clipping prevention, and 73 Vietnamese precomposed NFC glyph coverage.
- **Tier 3 (Cross-Feature Combinations)**: Navigation without redundant font re-fetches, deep linking from fuzzy search directly into worked examples, and window error listener tracking.
- **Tier 4 (Real-World Academic Workloads)**: 5 comprehensive student and researcher user journeys executing realistic workflows across desktop, tablet, and mobile devices.

---

## 2. Test File Inventory

| File Path | Description | Tiers Covered | Target Feature Areas |
|-----------|-------------|:-------------:|----------------------|
| `playwright.config.ts` | Playwright test harness configuration: system Chrome executable (`C:\Program Files\Google\Chrome\Application\chrome.exe`), multi-device projects (Desktop, Tablet, Mobile), video/screenshot capture on failure. | Harness | All |
| `tests/e2e/font-loading.spec.ts` | Intercepts `.woff2` and `.woff` network requests, validates HTTP 200/304, RFC 8081 `font/woff2` MIME, `Access-Control-Allow-Origin: *`, `document.fonts.ready`, `document.fonts.status === 'loaded'`, and `document.fonts.check()` across weights (400, 600, 700). | Tiers 1, 2, 3 | R3 (Features 3, 4) |
| `tests/e2e/console-errors.spec.ts` | Listens to `page.on('console')`, `page.on('pageerror')`, `requestfailed`, and `unhandledrejection`. Enforces zero-tolerance: 0 console errors, 0 CORS errors, 0 HTTP 404/500 asset errors, 0 OTS font decoding warnings. | Tiers 1, 2, 3 | R3, R4 (Feature 4, 10) |
| `tests/e2e/typography.spec.ts` | Scans all headings, paragraphs, and KaTeX formula containers. Asserts zero tofu (`\u25A1` □, `\uFFFD`), zero unmapped PUA characters (`\uE000`–`\uF8FF`), 100% Vietnamese Unicode Normalization Form C (NFC), rendering of complex compound diacritics (`ế, ệ, ẩ, ộ, Ứ`), and zero raw LaTeX leakage. | Tiers 1, 2 | R1, R2 (Features 1, 2) |
| `tests/e2e/navigation.spec.ts` | Verifies 7-chapter sidebar navigation, mobile drawer toggle, reading progress bar, instant fuzzy search (`Ctrl+K`), collapsible worked examples, cognitive trap alert callouts, 4 master comparison tables, and 5 Tier 4 real-world user scenarios. | Tiers 1, 2, 3, 4 | R2 (Features 5, 6, 7, 8, 9) |
| `tests/e2e/visual.spec.ts` | Automated visual regression and evidence screenshot captures across 4 viewports (Desktop 1920x1080, Laptop 1440x900, Tablet 768x1024, Mobile 375x812) and 5 interactive component close-ups into `test-results/screenshots/`. | Tiers 1, 2 | R4 (Feature 11) |
| `tests/lighthouse/font-display-audit.js` | Standalone Node.js Lighthouse audit script testing `http://localhost:3000` against the `font-display` audit rule (`font-display: swap`), generating HTML and JSON reports in `test-results/lighthouse/`. | Tier 1, 2 | R3, R4 (Feature 10) |

---

## 3. How to Run the Tests

### Pre-requisite: Start the Application Server
Before running E2E tests, ensure the static server is running on port 3000:
```powershell
# In terminal 1 (Node.js production server with RFC 8081 MIME & CORS):
node server/serve.js

# Or Python production server:
py server/serve.py
```

### Full E2E Test Suite Execution
To execute all 147 test instances across Desktop Chrome, Tablet, and Mobile:
```powershell
$env:NODE_PATH="C:\Users\tuan2\AppData\Local\npm-cache\_npx\420ff84f11983ee5\node_modules"
npx --package=@playwright/test playwright test
```

### Individual Test Suites
```powershell
# 1. Font loading, MIME types, and CORS headers:
npx --package=@playwright/test playwright test tests/e2e/font-loading.spec.ts

# 2. Zero console errors, zero CORS, and zero 404/500 assets:
npx --package=@playwright/test playwright test tests/e2e/console-errors.spec.ts

# 3. Vietnamese typography, Unicode NFC normalization, and zero-tofu:
npx --package=@playwright/test playwright test tests/e2e/typography.spec.ts

# 4. 7-Chapter navigation, fuzzy search, worked examples, and Tier 4 scenarios:
npx --package=@playwright/test playwright test tests/e2e/navigation.spec.ts

# 5. Multi-viewport and component visual screenshot captures:
npx --package=@playwright/test playwright test tests/e2e/visual.spec.ts
```

### Lighthouse Font-Display Compliance Audit
To audit `font-display: swap` compliance and verify zero Flash of Invisible Text (FOIT):
```powershell
node tests/lighthouse/font-display-audit.js
```

---

## 4. Zero-Tolerance Quality Criteria

The test suite enforces the following automated pass/fail criteria:

| Metric | Target Threshold | Validation Mechanism |
|--------|:----------------:|----------------------|
| **Console Errors** | **0** | `page.on('console')` checking `type === 'error'` |
| **Unhandled Exceptions** | **0** | `page.on('pageerror')` and `window.addEventListener('unhandledrejection')` |
| **CORS Policy Violations** | **0** | Network failure inspection + CORS console detection |
| **Asset HTTP Errors (4xx/5xx)** | **0** | Response interceptor scanning all scripts, styles, fonts, images |
| **Tofu / Replacement Glyphs** | **0** | Full DOM character scanning for `\u25A1`, `\uFFFD`, and PUA range |
| **Vietnamese NFC Normalization** | **100% NFC** | `rawText === rawText.normalize('NFC')` on all text nodes |
| **WOFF2 HTTP Status & MIME** | **HTTP 200, font/woff2** | Response interceptor validating RFC 8081 standard MIME |
| **WOFF2 CORS Header** | `Access-Control-Allow-Origin: *` | Response header assertion |
| **Lighthouse font-display Audit** | **Score = 1.0 (100% PASS)** | Automated programmatic check in `font-display-audit.js` |
| **Visual Evidence** | **9 high-res PNGs** | Generated in `test-results/screenshots/` |

---

## 5. Artifact Output Locations

- **Playwright HTML Test Report**: `playwright-report/index.html`
- **JSON Test Results**: `test-results/test-results.json`
- **Visual Screenshots**: `test-results/screenshots/`
  - `fullpage-desktop-1920x1080.png`
  - `fullpage-laptop-1440x900.png`
  - `fullpage-tablet-768x1024.png`
  - `fullpage-mobile-375x812.png`
  - `component-math-formula.png`
  - `component-worked-example-expanded.png`
  - `component-cognitive-trap.png`
  - `component-search-modal-active.png`
  - `component-master-table.png`
- **Lighthouse Font-Display Reports**: `test-results/lighthouse/`
  - `font-display-report.report.html`
  - `font-display-report.report.json`

---

## 6. Implementation Readiness Sign-off

The test suite is completely independent, syntactically verified (`playwright test --list` passed with 147 test instances), and ready to run against the application as milestones M1, M2, and M3 complete.
