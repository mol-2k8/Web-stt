import { defineConfig, devices } from '@playwright/test';
import fs from 'fs';

const defaultChromePath = 'C:\\Program Files\\Google\\Chrome\\Application\\chrome.exe';
const chromePath = fs.existsSync(defaultChromePath)
  ? defaultChromePath
  : process.env.CHROME_PATH || undefined;

export default defineConfig({
  testDir: './tests/e2e',
  timeout: 60000,
  expect: {
    timeout: 10000,
  },
  fullyParallel: false,
  forbidOnly: !!process.env.CI,
  retries: process.env.CI ? 2 : 0,
  workers: 1,
  outputDir: 'test-results/',
  reporter: [
    ['list'],
    ['html', { outputFolder: 'playwright-report', open: 'never' }],
    ['json', { outputFile: 'test-results/test-results.json' }],
  ],
  use: {
    baseURL: process.env.BASE_URL || 'http://localhost:3000',
    trace: 'on-first-retry',
    screenshot: 'only-on-failure',
    video: 'retain-on-failure',
    actionTimeout: 10000,
    navigationTimeout: 30000,
    launchOptions: {
      executablePath: chromePath,
      args: [
        '--no-sandbox',
        '--disable-setuid-sandbox',
        '--disable-dev-shm-usage',
        '--disable-gpu',
      ],
    },
  },
  projects: [
    {
      name: 'Desktop-Chrome',
      use: {
        ...devices['Desktop Chrome'],
        channel: chromePath ? undefined : 'chromium',
      },
    },
    {
      name: 'Tablet-Safari',
      use: {
        ...devices['iPad (gen 7)'],
      },
    },
    {
      name: 'Mobile-Chrome',
      use: {
        ...devices['Pixel 5'],
      },
    },
  ],
  webServer: process.env.START_SERVER
    ? {
        command: 'node server/serve.js',
        url: 'http://localhost:3000',
        reuseExistingServer: true,
        timeout: 30000,
      }
    : undefined,
});
